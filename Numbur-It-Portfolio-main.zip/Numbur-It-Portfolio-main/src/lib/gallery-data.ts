export interface GalleryItemData {
  id: string;
  title: string;
  category: string;
  url: string;
}

export const INITIAL_GALLERY: GalleryItemData[] = [
  {
    id: 'g1',
    title: 'Manthali Storefront & Showroom',
    category: 'Store',
    url: '',
  },
  {
    id: 'g2',
    title: 'Hardware & Laptop Testing Workbench',
    category: 'Workplace',
    url: '',
  },
  {
    id: 'g3',
    title: 'Customer Reception & Consultation Desk',
    category: 'Store',
    url: '',
  },
  {
    id: 'g4',
    title: 'CCTV Surveillance & Network Rack Setup',
    category: 'Installations',
    url: '',
  },
  {
    id: 'g5',
    title: 'Laser Printers & Copier Service Counter',
    category: 'Equipment',
    url: '',
  },
  {
    id: 'g6',
    title: 'Networking & Structured Fiber Infrastructure',
    category: 'Networking',
    url: '',
  },
];
