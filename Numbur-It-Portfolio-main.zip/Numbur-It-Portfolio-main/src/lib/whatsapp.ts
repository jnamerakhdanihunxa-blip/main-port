import { Order, OrderItem } from '@/types';

export interface WhatsAppOrderData {
  orderNumber: string;
  customerName: string;
  customerPhone: string;
  deliveryMethod: string;
  deliveryAddress: string;
  municipalityArea: string;
  items: Array<{
    name: string;
    sku: string;
    quantity: number;
    price: number;
    total: number;
  }>;
  subtotal: number;
  specialInstructions?: string | null;
}

/**
 * Format WhatsApp order message according to business specifications
 */
export function generateWhatsAppMessage(
  data: WhatsAppOrderData,
  businessName: string = 'NUMBUR iT SOLUTION PVT. LTD.'
): string {
  const methodLabel =
    data.deliveryMethod === 'store_pickup'
      ? 'Store Pickup (Showroom: Manthali-1, Devkota Chowk, Ramechhap)'
      : 'All Nepal Delivery (Courier / Transport / Doorstep Delivery across Nepal)';

  let message = `*${businessName}*\n`;
  message += `*NEW ORDER: #${data.orderNumber}*\n`;
  message += `----------------------------------------\n`;
  message += `*Customer:* ${data.customerName}\n`;
  message += `*Phone:* ${data.customerPhone}\n`;
  message += `*Delivery Method:* ${methodLabel}\n`;
  message += `*Address / Landmark:* ${data.deliveryAddress}, ${data.municipalityArea}\n`;
  message += `*Store Location:* Manthali-1, Devkota Chowk, Ramechhap\n`;
  message += `*(Delivery available All Over Nepal | Technical Services in Manthali-1 only)*\n`;

  if (data.specialInstructions) {
    message += `*Instructions:* ${data.specialInstructions}\n`;
  }

  message += `----------------------------------------\n`;
  message += `*ORDERED ITEMS:*\n`;

  data.items.forEach((item, index) => {
    message += `${index + 1}. *${item.name}*\n`;
    message += `   SKU: ${item.sku}\n`;
    message += `   Qty: ${item.quantity} x Rs. ${item.price.toLocaleString('en-IN')} = Rs. ${item.total.toLocaleString('en-IN')}\n`;
  });

  message += `----------------------------------------\n`;
  message += `*ORDER SUBTOTAL:* Rs. ${data.subtotal.toLocaleString('en-IN')}\n`;
  message += `----------------------------------------\n`;
  message += `*NEXT STEPS & PAYMENT:*\n`;
  message += `1. Please confirm product availability and courier/delivery dispatch with our representative.\n`;
  message += `2. If required, advance payment can be sent via Fonepay / eSewa / Bank Transfer.\n`;
  message += `3. Share your payment screenshot here for immediate order processing.\n\n`;
  message += `_Thank you for choosing Numbur iT Solution, Devkota Chowk, Manthali-1, Ramechhap!_`;

  return message;
}

/**
 * Generate full wa.me direct URL with encoded message
 */
export function buildWhatsAppOrderUrl(
  whatsappNumber: string,
  data: WhatsAppOrderData,
  businessName?: string
): string {
  // Clean phone number (strip spaces, +, -, etc.)
  let cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  // Default Nepal country code 977 if 10-digit mobile is passed
  if (cleanNumber.length === 10 && cleanNumber.startsWith('9')) {
    cleanNumber = `977${cleanNumber}`;
  }

  const message = generateWhatsAppMessage(data, businessName);
  const encodedText = encodeURIComponent(message);

  return `https://wa.me/${cleanNumber}?text=${encodedText}`;
}
