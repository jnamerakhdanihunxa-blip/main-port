import { NextRequest, NextResponse } from 'next/server';
import { createClientServer } from '@/lib/supabase/server';
import { createAdminClient } from '@/lib/supabase/admin';

export interface AdminAuthResult {
  authorized: boolean;
  user?: any;
  role?: string;
  error?: string;
  status?: number;
}

/**
 * Server-side guard to ensure the incoming request has valid Staff or Admin authorization.
 * Supports:
 * 1. Supabase SSR session cookies (standard browser fetch)
 * 2. Authorization: Bearer <jwt_access_token>
 * 3. x-admin-key: <key> matching server environment secrets
 */
export async function verifyAdminOrStaff(req?: NextRequest): Promise<AdminAuthResult> {
  try {
    const adminKeyHeader = req?.headers.get('x-admin-key');
    const authHeader = req?.headers.get('authorization');
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const adminApiKey = process.env.ADMIN_API_KEY;

    // 1. Check API Key header
    if (adminKeyHeader) {
      if ((serviceRoleKey && adminKeyHeader === serviceRoleKey) || (adminApiKey && adminKeyHeader === adminApiKey)) {
        return { authorized: true, role: 'super_admin' };
      }
    }

    const adminClient = createAdminClient();

    // 2. Check Bearer Token in Authorization header
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7).trim();
      if (token) {
        // If Bearer token matches service role key
        if ((serviceRoleKey && token === serviceRoleKey) || (adminApiKey && token === adminApiKey)) {
          return { authorized: true, role: 'super_admin' };
        }

        const { data: { user }, error: tokenErr } = await adminClient.auth.getUser(token);
        if (!tokenErr && user) {
          const { data: profile } = await adminClient
            .from('profiles')
            .select('role, is_active')
            .eq('id', user.id)
            .maybeSingle();

          if (!profile || profile.is_active === false) {
            return { authorized: false, error: 'User account is inactive or missing profile.', status: 403 };
          }

          if (!['super_admin', 'admin', 'staff'].includes(profile.role)) {
            return { authorized: false, error: 'Forbidden: Insufficient privileges.', status: 403 };
          }

          return { authorized: true, user, role: profile.role };
        }
      }
    }

    // 3. Check Supabase SSR session cookies (from browser fetch)
    try {
      const supabaseServer = createClientServer();
      const { data: { user }, error: userError } = await supabaseServer.auth.getUser();

      if (!userError && user) {
        const { data: profile } = await adminClient
          .from('profiles')
          .select('role, is_active')
          .eq('id', user.id)
          .maybeSingle();

        if (!profile || profile.is_active === false) {
          return { authorized: false, error: 'User account is inactive.', status: 403 };
        }

        if (!['super_admin', 'admin', 'staff'].includes(profile.role)) {
          return { authorized: false, error: 'Forbidden: Insufficient administrative privileges.', status: 403 };
        }

        return { authorized: true, user, role: profile.role };
      }
    } catch (cookieErr) {
      // Cookie reading in non-cookie request contexts
    }

    // If no credentials or session found
    return {
      authorized: false,
      error: 'Unauthorized: Valid administrative session or credentials required.',
      status: 401,
    };
  } catch (err: any) {
    console.error('verifyAdminOrStaff guard exception:', err);
    return {
      authorized: false,
      error: 'Internal authentication verification error.',
      status: 500,
    };
  }
}
