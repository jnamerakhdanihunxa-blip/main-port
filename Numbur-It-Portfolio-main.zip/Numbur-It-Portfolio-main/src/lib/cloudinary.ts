import crypto from 'crypto';

export function isCloudinaryConfigured() {
  const cloudName = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME;
  return Boolean(
    cloudName &&
    !cloudName.includes('your_cloud_name') &&
    !cloudName.includes('placeholder')
  );
}

/**
 * Generate secure signed upload parameters on the server
 */
export function generateCloudinarySignature(paramsToSign: Record<string, string | number>) {
  const apiSecret = process.env.CLOUDINARY_API_SECRET;
  if (!apiSecret) {
    throw new Error('CLOUDINARY_API_SECRET is not configured on the server');
  }

  // Sort parameters alphabetically
  const sortedKeys = Object.keys(paramsToSign).sort();
  const stringToSign = sortedKeys
    .map((key) => `${key}=${paramsToSign[key]}`)
    .join('&');

  const signature = crypto
    .createHash('sha1')
    .update(stringToSign + apiSecret)
    .digest('hex');

  return {
    signature,
    timestamp: paramsToSign.timestamp,
    apiKey: process.env.NEXT_PUBLIC_CLOUDINARY_API_KEY || process.env.CLOUDINARY_API_KEY,
    cloudName: process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME,
  };
}

/**
 * Upload an image directly from the server to Cloudinary
 * Accepts a data URI (data:image/...;base64,...) or remote URL
 */
export async function uploadToCloudinaryServer(
  fileData: string,
  folder: string = 'numbur-it/uploads'
): Promise<{ url: string; public_id: string; secure_url: string; width: number; height: number }> {
  const cloudName = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME;
  const apiKey = process.env.CLOUDINARY_API_KEY || process.env.NEXT_PUBLIC_CLOUDINARY_API_KEY;
  const apiSecret = process.env.CLOUDINARY_API_SECRET;

  if (!cloudName) {
    throw new Error('Cloudinary Cloud Name is not configured (NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME)');
  }

  const timestamp = Math.floor(Date.now() / 1000);
  const formData = new FormData();
  formData.append('file', fileData);
  formData.append('folder', folder);

  if (apiKey && apiSecret) {
    // Authenticated upload with SHA-1 signature
    const signatureData = generateCloudinarySignature({ folder, timestamp });
    formData.append('api_key', apiKey);
    formData.append('timestamp', timestamp.toString());
    formData.append('signature', signatureData.signature);
  } else if (process.env.NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET) {
    // Unsigned upload with preset
    formData.append('upload_preset', process.env.NEXT_PUBLIC_CLOUDINARY_UPLOAD_PRESET);
  } else {
    throw new Error(
      'Missing Cloudinary credentials. Please define CLOUDINARY_API_KEY & CLOUDINARY_API_SECRET in .env.local'
    );
  }

  const response = await fetch(
    `https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,
    {
      method: 'POST',
      body: formData,
    }
  );

  const rawText = await response.text();
  let data: any;
  try {
    data = JSON.parse(rawText);
  } catch (err) {
    throw new Error(
      `Cloudinary response error (${response.status}): ${rawText.slice(0, 150) || 'Empty response'}`
    );
  }

  if (!response.ok) {
    throw new Error(data.error?.message || 'Failed to upload image to Cloudinary');
  }

  return {
    url: data.secure_url || data.url,
    secure_url: data.secure_url,
    public_id: data.public_id,
    width: data.width,
    height: data.height,
  };
}

/**
 * Generate optimized Cloudinary transformation URLs
 */
export function getOptimizedImageUrl(
  publicIdOrUrl?: string | null,
  options: {
    width?: number;
    height?: number;
    crop?: 'fill' | 'fit' | 'thumb' | 'scale';
    quality?: string | number;
  } = {}
): string {
  if (!publicIdOrUrl) return '';
  if (!publicIdOrUrl.includes('res.cloudinary.com')) {
    return publicIdOrUrl;
  }

  const cloudName = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME;
  if (!cloudName) return publicIdOrUrl;

  const { width = 800, height, crop = 'fill', quality = 'auto' } = options;

  let transformations = `f_auto,q_${quality},c_${crop},w_${width}`;
  if (height) {
    transformations += `,h_${height}`;
  }

  // Inject transformation into Cloudinary URL
  return publicIdOrUrl.replace('/upload/', `/upload/${transformations}/`);
}
