import { z } from 'zod';

export const productSchema = z.object({
  name_en: z.string().min(2, 'Product name is required'),
  name_ne: z.string().optional(),
  slug: z.string().min(2, 'Valid slug is required'),
  sku: z.string().min(2, 'SKU is required'),
  category_id: z.string().uuid('Please select a valid category'),
  brand_id: z.string().uuid().optional().nullable(),
  selling_price: z.number().min(0, 'Selling price must be 0 or greater'),
  cost_price: z.number().min(0).optional().nullable(),
  discount_price: z.number().min(0).optional().nullable(),
  primary_image_url: z.string().min(1, 'Primary product image is required'),
  primary_image_public_id: z.string().optional().nullable(),
  short_desc_en: z.string().optional().nullable(),
  short_desc_ne: z.string().optional().nullable(),
  full_desc_en: z.string().optional().nullable(),
  full_desc_ne: z.string().optional().nullable(),
  specifications: z.record(z.string()).default({}),
  warranty_info_en: z.string().optional().nullable(),
  warranty_info_ne: z.string().optional().nullable(),
  is_featured: z.boolean().default(false),
  is_bestseller: z.boolean().default(false),
  is_new_arrival: z.boolean().default(false),
  is_active: z.boolean().default(true),
  seo_title: z.string().optional().nullable(),
  seo_description: z.string().optional().nullable(),
});

export const categorySchema = z.object({
  name_en: z.string().min(2, 'Category name (English) is required'),
  name_ne: z.string().optional().nullable(),
  slug: z.string().min(2, 'Slug is required'),
  description_en: z.string().optional().nullable(),
  description_ne: z.string().optional().nullable(),
  image_url: z.string().optional().nullable(),
  display_order: z.number().int().default(0),
  is_active: z.boolean().default(true),
});

export const checkoutSchema = z.object({
  customer_name: z.string().min(2, 'Customer name is required'),
  customer_phone: z
    .string()
    .min(9, 'Please provide a valid phone number')
    .max(15, 'Phone number is too long'),
  delivery_method: z.enum(['all_nepal_delivery', 'ramechhap_delivery', 'store_pickup']),
  delivery_address: z.string().min(3, 'Delivery address is required'),
  municipality_area: z.string().min(2, 'Municipality / Area is required'),
  delivery_instructions: z.string().optional().nullable(),
  items: z
    .array(
      z.object({
        product_id: z.string(),
        quantity: z.number().int().positive('Quantity must be at least 1'),
      })
    )
    .min(1, 'Cart cannot be empty'),
});

export const advancePaymentSchema = z.object({
  order_id: z.string().uuid(),
  amount: z.number().positive('Payment amount must be greater than 0'),
  payment_method: z.enum(['cash', 'bank_transfer', 'fonepay_qr', 'esewa', 'khalti']),
  payment_reference: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

export const staffProfileSchema = z.object({
  name: z.string().min(2, 'Staff name is required'),
  designation: z.string().min(2, 'Designation is required'),
  department: z.string().optional().nullable(),
  bio_en: z.string().optional().nullable(),
  bio_ne: z.string().optional().nullable(),
  photo_url: z.string().min(1, 'Profile photo is required'),
  photo_public_id: z.string().optional().nullable(),
  public_contact_phone: z.string().optional().nullable(),
  public_contact_email: z.string().email().optional().nullable().or(z.literal('')),
  public_address: z.string().optional().nullable(),
  display_order: z.number().int().default(0),
  is_public: z.boolean().default(true),
});

export const stockMovementSchema = z.object({
  product_id: z.string().uuid('Valid product ID is required'),
  quantity_change: z.number().int(),
  movement_type: z.enum(['purchase', 'sale', 'damaged', 'adjustment', 'return']),
  reason: z.string().min(3, 'A clear reason for the stock adjustment is required'),
});
