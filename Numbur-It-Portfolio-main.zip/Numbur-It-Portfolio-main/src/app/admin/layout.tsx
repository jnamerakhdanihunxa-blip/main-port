'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  LayoutDashboard,
  Package,
  Layers,
  Archive,
  ShoppingCart,
  Users,
  UserCheck,
  FileText,
  Settings,
  ShieldAlert,
  Menu,
  X,
  ExternalLink,
  Image as ImageIcon,
  Share2,
  Palette,
  LogOut,
} from 'lucide-react';
import { createClient } from '@/lib/supabase/client';

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [isVerifying, setIsVerifying] = useState(true);
  const [userProfile, setUserProfile] = useState<{ email?: string; role?: string; name?: string } | null>(null);

  React.useEffect(() => {
    // Skip guard for login page
    if (pathname === '/admin/login') {
      setIsVerifying(false);
      return;
    }

    let isMounted = true;
    const supabase = createClient();

    async function verifyAuth() {
      try {
        const { data: { user }, error: userError } = await supabase.auth.getUser();

        if (userError || !user) {
          router.replace('/admin/login');
          return;
        }

        const { data: profile, error: profError } = await supabase
          .from('profiles')
          .select('full_name, role, is_active')
          .eq('id', user.id)
          .maybeSingle();

        if (profError || !profile || profile.is_active === false || !['super_admin', 'admin', 'staff'].includes(profile.role)) {
          await supabase.auth.signOut();
          router.replace('/admin/login');
          return;
        }

        if (isMounted) {
          setUserProfile({
            email: user.email,
            role: profile.role,
            name: profile.full_name,
          });
          setIsVerifying(false);
        }
      } catch (err) {
        console.error('Admin layout auth verification error:', err);
        router.replace('/admin/login');
      }
    }

    verifyAuth();

    const { data: authSub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_OUT' || !session) {
        router.replace('/admin/login');
      }
    });

    return () => {
      isMounted = false;
      authSub?.subscription?.unsubscribe();
    };
  }, [pathname, router]);

  const handleSignOut = async () => {
    setIsLoggingOut(true);
    try {
      const supabase = createClient();
      await supabase.auth.signOut();
    } catch (err) {
      console.warn('Signout warning:', err);
    } finally {
      router.push('/admin/login');
      setIsLoggingOut(false);
    }
  };

  // If on login page, render children cleanly without admin shell
  if (pathname === '/admin/login') {
    return <>{children}</>;
  }

  // If verifying authentication, show full-page secure loading state
  if (isVerifying) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white p-4">
        <div className="w-12 h-12 rounded-2xl bg-brand-600 flex items-center justify-center text-xl font-black mb-4 shadow-lg animate-pulse">
          N
        </div>
        <div className="animate-spin w-6 h-6 border-2 border-brand-500 border-t-transparent rounded-full mb-3" />
        <p className="text-xs font-semibold text-slate-400">Verifying administrative access...</p>
      </div>
    );
  }

  const navItems = [
    { name: 'Dashboard Overview', href: '/admin', icon: LayoutDashboard },
    { name: 'Products Catalog', href: '/admin/products', icon: Package },
    { name: 'Categories & Brands', href: '/admin/categories', icon: Layers },
    { name: 'Inventory Ledger', href: '/admin/inventory', icon: Archive },
    { name: 'Orders & Quotes', href: '/admin/orders', icon: ShoppingCart },
    { name: 'Staff Management', href: '/admin/staff', icon: UserCheck },
    { name: 'Hero Carousel', href: '/admin/hero', icon: ImageIcon },
    { name: 'Logo & Branding', href: '/admin/branding', icon: Palette },
    { name: 'Social Media Links', href: '/admin/social', icon: Share2 },
    { name: 'Website Content', href: '/admin/content', icon: FileText },
    { name: 'System Settings', href: '/admin/settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col md:flex-row text-slate-900 font-sans">
      {/* Mobile Top Bar */}
      <div className="md:hidden bg-slate-900 text-white p-4 flex justify-between items-center sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded bg-brand-600 text-white font-bold flex items-center justify-center text-sm">
            N
          </div>
          <span className="font-extrabold text-sm">Numbur iT Admin</span>
        </div>
        <button
          type="button"
          onClick={() => setMobileOpen(!mobileOpen)}
          className="p-1 rounded text-slate-300 hover:text-white"
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Sidebar Navigation */}
      <aside
        className={`${
          mobileOpen ? 'block' : 'hidden'
        } md:block w-full md:w-64 bg-slate-900 text-slate-300 flex-shrink-0 flex flex-col justify-between p-4 sticky top-0 h-auto md:h-screen z-30 overflow-y-auto`}
      >
        <div className="space-y-5">
          {/* Logo Header */}
          <div className="hidden md:flex items-center gap-3 px-2 py-3 border-b border-slate-800">
            <div className="w-9 h-9 rounded-xl bg-brand-600 text-white font-extrabold flex items-center justify-center text-lg shadow">
              N
            </div>
            <div>
              <span className="font-bold text-sm text-white block">
                Numbur iT Admin
              </span>
              <span className="text-[10px] text-brand-400 font-mono block">
                Control Center
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileOpen(false)}
                  className={`flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition ${
                    isActive
                      ? 'bg-brand-600 text-white shadow-sm'
                      : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Footer Actions */}
        <div className="pt-4 mt-4 border-t border-slate-800 space-y-2.5">
          <div className="px-3 py-2 rounded-xl bg-slate-800/80 text-xs flex items-center justify-between">
            <div>
              <span className="text-slate-400 block text-[9px] uppercase tracking-wider font-semibold truncate max-w-[120px]">
                {userProfile?.name || userProfile?.email || 'Logged In'}
              </span>
              <span className="font-bold text-emerald-400 flex items-center gap-1.5 mt-0.5 text-[11px] uppercase">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {userProfile?.role ? userProfile.role.replace('_', ' ') : 'Authenticated'}
              </span>
            </div>
            <button
              onClick={handleSignOut}
              disabled={isLoggingOut}
              title="Sign Out"
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-850 transition"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <Link
              href="/"
              target="_blank"
              className="flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium py-2 px-2 rounded-xl transition text-center"
            >
              <span>Store</span>
              <ExternalLink className="w-3 h-3 text-slate-400" />
            </Link>
            <button
              onClick={handleSignOut}
              disabled={isLoggingOut}
              className="flex items-center justify-center gap-1.5 bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 text-xs font-medium py-2 px-2 rounded-xl transition text-center"
            >
              <LogOut className="w-3 h-3" />
              <span>{isLoggingOut ? '...' : 'Logout'}</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto w-full max-w-[1700px]">
        {children}
      </main>
    </div>
  );
}
