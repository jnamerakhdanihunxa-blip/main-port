'use client';

import React, { useState, useEffect } from 'react';
import SafeImage from '@/components/ui/SafeImage';
import ImageUploader from '@/components/admin/ImageUploader';
import { AUDITED_SERVICES_FALLBACK } from '@/components/public/ServicesSection';
import { FALLBACK_BANNERS } from '@/components/public/HeroSection';
import { INITIAL_GALLERY } from '@/lib/gallery-data';
import { ServiceItem, SiteBanner } from '@/types';
import { createClient, isSupabaseConfigured } from '@/lib/supabase/client';
import {
  FileText,
  Image as ImageIcon,
  Wrench,
  Globe,
  Plus,
  Edit,
  Trash2,
  CheckCircle2,
  X,
  Database,
  Cloud,
  Layers,
  Camera,
} from 'lucide-react';

interface GalleryItem {
  id: string;
  title: string;
  category: string;
  url: string;
  caption?: string;
}

export default function AdminContentPage() {
  const [activeTab, setActiveTab] = useState<'services' | 'banners' | 'gallery'>('services');
  const [isDbConnected, setIsDbConnected] = useState(false);

  // Lists
  const [services, setServices] = useState<ServiceItem[]>(AUDITED_SERVICES_FALLBACK);
  const [banners, setBanners] = useState<SiteBanner[]>(FALLBACK_BANNERS);
  const [gallery, setGallery] = useState<GalleryItem[]>(INITIAL_GALLERY);

  // Modals
  const [isServiceModalOpen, setIsServiceModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<ServiceItem | null>(null);

  const [isBannerModalOpen, setIsBannerModalOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<SiteBanner | null>(null);

  const [isGalleryModalOpen, setIsGalleryModalOpen] = useState(false);
  const [editingGallery, setEditingGallery] = useState<GalleryItem | null>(null);

  // Service form state
  const [svcTitleEn, setSvcTitleEn] = useState('');
  const [svcTitleNe, setSvcTitleNe] = useState('');
  const [svcDescEn, setSvcDescEn] = useState('');
  const [svcIcon, setSvcIcon] = useState('cctv');
  const [svcOrder, setSvcOrder] = useState(1);

  // Banner form state
  const [bnrTitleEn, setBnrTitleEn] = useState('');
  const [bnrTitleNe, setBnrTitleNe] = useState('');
  const [bnrSubEn, setBnrSubEn] = useState('');
  const [bnrSubNe, setBnrSubNe] = useState('');
  const [bnrCtaText, setBnrCtaText] = useState('Explore Catalog');
  const [bnrCtaLink, setBnrCtaLink] = useState('/products');
  const [bnrImageUrl, setBnrImageUrl] = useState('');
  const [bnrOrder, setBnrOrder] = useState(1);
  const [bnrActive, setBnrActive] = useState(true);

  // Gallery form state
  const [galTitle, setGalTitle] = useState('');
  const [galCategory, setGalCategory] = useState('Store');
  const [galUrl, setGalUrl] = useState('');

  // Fetch from database via secure server APIs
  useEffect(() => {
    async function loadData() {
      try {
        const res = await fetch('/api/admin/content');
        if (res.ok) {
          const data = await res.json();
          if (data.services && data.services.length > 0) {
            setServices(data.services as ServiceItem[]);
          }
          if (data.banners && data.banners.length > 0) {
            setBanners(data.banners as SiteBanner[]);
          }
          if (data.gallery && data.gallery.length > 0) {
            setGallery(data.gallery);
          }
          setIsDbConnected(true);
        }
      } catch (e) {
        console.warn('Content fetch warning:', e);
      }
    }
    loadData();
  }, []);

  // Services Actions
  const openCreateService = () => {
    setEditingService(null);
    setSvcTitleEn('');
    setSvcTitleNe('');
    setSvcDescEn('');
    setSvcIcon('cctv');
    setSvcOrder(services.length + 1);
    setIsServiceModalOpen(true);
  };

  const openEditService = (svc: ServiceItem) => {
    setEditingService(svc);
    setSvcTitleEn(svc.title_en);
    setSvcTitleNe(svc.title_ne || '');
    setSvcDescEn(svc.short_desc_en || '');
    setSvcIcon(svc.icon_name || 'cctv');
    setSvcOrder(svc.display_order);
    setIsServiceModalOpen(true);
  };

  const handleSaveService = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!svcTitleEn.trim()) return;

    const generatedSlug = svcTitleEn.toLowerCase().replace(/[^a-z0-9]+/g, '-');

    try {
      const payload = {
        type: 'service',
        action: editingService ? 'update' : 'create',
        id: editingService?.id,
        data: {
          title_en: svcTitleEn.trim(),
          title_ne: svcTitleNe.trim() || null,
          slug: generatedSlug,
          short_desc_en: svcDescEn.trim() || null,
          icon_name: svcIcon,
          display_order: Number(svcOrder),
          is_active: true,
        },
      };

      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const resData = await res.json();
      if (!res.ok || resData.error) {
        alert(resData.error || 'Failed to save service');
        return;
      }

      if (editingService) {
        setServices((prev) =>
          prev.map((s) =>
            s.id === editingService.id
              ? {
                  ...s,
                  title_en: svcTitleEn,
                  title_ne: svcTitleNe || null,
                  short_desc_en: svcDescEn,
                  icon_name: svcIcon,
                  display_order: Number(svcOrder),
                }
              : s
          )
        );
      } else {
        const newSvc: ServiceItem = resData.item || {
          id: `svc-${Date.now()}`,
          slug: generatedSlug,
          title_en: svcTitleEn,
          title_ne: svcTitleNe || null,
          short_desc_en: svcDescEn,
          icon_name: svcIcon,
          display_order: Number(svcOrder),
          is_active: true,
          created_at: new Date().toISOString(),
        };
        setServices((prev) => [...prev, newSvc]);
      }

      setIsServiceModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Error occurred while saving service');
    }
  };

  const handleDeleteService = async (id: string) => {
    if (!confirm('Are you sure you want to remove this service?')) {
      return;
    }

    try {
      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'service', action: 'delete', id }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to delete service');
        return;
      }

      setServices((prev) => prev.filter((s) => s.id !== id));
    } catch (err: any) {
      alert(err.message || 'Error deleting service');
    }
  };

  // Banner Actions
  const openCreateBanner = () => {
    setEditingBanner(null);
    setBnrTitleEn('');
    setBnrTitleNe('');
    setBnrSubEn('');
    setBnrSubNe('');
    setBnrCtaText('Explore Catalog');
    setBnrCtaLink('/products');
    setBnrImageUrl('');
    setBnrOrder(banners.length + 1);
    setBnrActive(true);
    setIsBannerModalOpen(true);
  };

  const openEditBanner = (bnr: SiteBanner) => {
    setEditingBanner(bnr);
    setBnrTitleEn(bnr.title_en);
    setBnrTitleNe(bnr.title_ne || '');
    setBnrSubEn(bnr.subtitle_en || '');
    setBnrSubNe(bnr.subtitle_ne || '');
    setBnrCtaText(bnr.cta_text_en || 'Explore Catalog');
    setBnrCtaLink(bnr.cta_link || '/products');
    setBnrImageUrl(bnr.image_url || '');
    setBnrOrder(bnr.display_order);
    setBnrActive(bnr.is_active);
    setIsBannerModalOpen(true);
  };

  const handleSaveBanner = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bnrTitleEn.trim()) return;

    try {
      const payload = {
        type: 'banner',
        action: editingBanner ? 'update' : 'create',
        id: editingBanner?.id,
        data: {
          title_en: bnrTitleEn.trim(),
          title_ne: bnrTitleNe.trim() || null,
          subtitle_en: bnrSubEn.trim() || null,
          subtitle_ne: bnrSubNe.trim() || null,
          cta_text_en: bnrCtaText.trim(),
          cta_link: bnrCtaLink.trim(),
          image_url: bnrImageUrl.trim() || null,
          banner_type: 'hero',
          display_order: Number(bnrOrder),
          is_active: bnrActive,
        },
      };

      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const resData = await res.json();
      if (!res.ok || resData.error) {
        alert(resData.error || 'Failed to save banner');
        return;
      }

      if (editingBanner) {
        setBanners((prev) =>
          prev.map((b) =>
            b.id === editingBanner.id
              ? {
                  ...b,
                  title_en: bnrTitleEn,
                  title_ne: bnrTitleNe || null,
                  subtitle_en: bnrSubEn,
                  subtitle_ne: bnrSubNe || null,
                  cta_text_en: bnrCtaText,
                  cta_link: bnrCtaLink,
                  image_url: bnrImageUrl,
                  display_order: Number(bnrOrder),
                  is_active: bnrActive,
                }
              : b
          )
        );
      } else {
        const newBnr: SiteBanner = resData.item || {
          id: `bnr-${Date.now()}`,
          title_en: bnrTitleEn,
          title_ne: bnrTitleNe || null,
          subtitle_en: bnrSubEn,
          subtitle_ne: bnrSubNe || null,
          cta_text_en: bnrCtaText,
          cta_link: bnrCtaLink,
          image_url: bnrImageUrl,
          banner_type: 'hero',
          display_order: Number(bnrOrder),
          is_active: bnrActive,
        };
        setBanners((prev) => [...prev, newBnr]);
      }

      setIsBannerModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Error occurred while saving banner');
    }
  };

  const handleDeleteBanner = async (id: string) => {
    if (!confirm('Are you sure you want to remove this banner?')) {
      return;
    }

    try {
      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'banner', action: 'delete', id }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to delete banner');
        return;
      }

      setBanners((prev) => prev.filter((b) => b.id !== id));
    } catch (err: any) {
      alert(err.message || 'Error deleting banner');
    }
  };

  // Gallery Actions
  const openCreateGallery = () => {
    setEditingGallery(null);
    setGalTitle('');
    setGalCategory('Store');
    setGalUrl('');
    setIsGalleryModalOpen(true);
  };

  const openEditGallery = (item: GalleryItem) => {
    setEditingGallery(item);
    setGalTitle(item.title);
    setGalCategory(item.category);
    setGalUrl(item.url);
    setIsGalleryModalOpen(true);
  };

  const handleSaveGallery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!galTitle.trim()) return;

    try {
      const payload = {
        type: 'gallery',
        action: editingGallery ? 'update' : 'create',
        id: editingGallery?.id,
        data: {
          title_en: galTitle.trim(),
          category: galCategory.trim(),
          image_url: galUrl.trim() || null,
        },
      };

      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const resData = await res.json();
      if (!res.ok || resData.error) {
        alert(resData.error || 'Failed to save gallery item');
        return;
      }

      if (editingGallery) {
        setGallery((prev) =>
          prev.map((g) =>
            g.id === editingGallery.id
              ? { ...g, title: galTitle, category: galCategory, url: galUrl }
              : g
          )
        );
      } else {
        const newGal: GalleryItem = resData.item
          ? {
              id: resData.item.id,
              title: resData.item.title_en || galTitle,
              category: resData.item.category || galCategory,
              url: resData.item.image_url || galUrl,
            }
          : {
              id: `gal-${Date.now()}`,
              title: galTitle,
              category: galCategory,
              url: galUrl,
            };
        setGallery((prev) => [...prev, newGal]);
      }

      setIsGalleryModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Error occurred while saving gallery photo');
    }
  };

  const handleDeleteGallery = async (id: string) => {
    if (!confirm('Are you sure you want to remove this gallery photo?')) {
      return;
    }

    try {
      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'gallery', action: 'delete', id }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to delete gallery item');
        return;
      }

      setGallery((prev) => prev.filter((g) => g.id !== id));
    } catch (err: any) {
      alert(err.message || 'Error deleting gallery photo');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold text-slate-900">
              Website Content & CMS Editor
            </h1>
            {isDbConnected ? (
              <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                <Database className="w-3 h-3 text-emerald-600" /> Supabase Live
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                <Cloud className="w-3 h-3 text-amber-600" /> Local Memory
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Dynamically update hero sliders, services catalog, and gallery photos with Cloudinary CDN.
          </p>
        </div>

        {/* Tab Buttons */}
        <div className="flex bg-slate-100 p-1 rounded-2xl border border-slate-200 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('services')}
            className={`px-4 py-2 rounded-xl transition ${
              activeTab === 'services'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Services ({services.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('banners')}
            className={`px-4 py-2 rounded-xl transition ${
              activeTab === 'banners'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Hero Banners ({banners.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('gallery')}
            className={`px-4 py-2 rounded-xl transition ${
              activeTab === 'gallery'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Gallery Items ({gallery.length})
          </button>
        </div>
      </div>

      {/* Services Tab View */}
      {activeTab === 'services' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden space-y-4">
          <div className="p-4 sm:p-6 border-b border-slate-100 flex justify-between items-center">
            <div>
              <h2 className="font-bold text-sm text-slate-900">
                IT & CCTV Surveillance Services
              </h2>
              <p className="text-xs text-slate-500">
                Manage service offerings displayed on the public services page and homepage.
              </p>
            </div>
            <button
              type="button"
              onClick={openCreateService}
              className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-2 px-3.5 rounded-xl shadow transition"
            >
              <Plus className="w-4 h-4" />
              <span>Add Service</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Service Title (EN)</th>
                  <th className="py-3 px-4">Nepali Title</th>
                  <th className="py-3 px-4">Icon Token</th>
                  <th className="py-3 px-4">Display Order</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {services.map((svc) => (
                  <tr key={svc.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {svc.title_en}
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {svc.title_ne || '—'}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-500">
                      {svc.icon_name}
                    </td>
                    <td className="py-3 px-4 font-mono">{svc.display_order}</td>
                    <td className="py-3 px-4">
                      <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full text-[10px] font-bold">
                        Active
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => openEditService(svc)}
                          className="p-1.5 text-slate-500 hover:text-brand-600 hover:bg-slate-100 rounded-lg transition"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteService(svc.id)}
                          className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-slate-100 rounded-lg transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Banners Tab View */}
      {activeTab === 'banners' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex justify-between items-center border-b border-slate-100 pb-4">
            <div>
              <h2 className="font-bold text-sm text-slate-900">
                Configured Hero Slider Banners
              </h2>
              <p className="text-xs text-slate-500">
                Upload custom background banners and configure headline copy.
              </p>
            </div>
            <button
              type="button"
              onClick={openCreateBanner}
              className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-2 px-3.5 rounded-xl shadow transition"
            >
              <Plus className="w-4 h-4" />
              <span>Add Banner</span>
            </button>
          </div>

          <div className="space-y-4">
            {banners.map((bnr) => (
              <div
                key={bnr.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs"
              >
                <div className="flex items-center gap-4">
                  <div className="relative w-24 h-14 rounded-xl overflow-hidden bg-slate-900 shrink-0 border border-slate-200">
                    <SafeImage
                      src={bnr.image_url}
                      alt={bnr.title_en}
                      fill
                      type="banner"
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 text-sm block">
                      {bnr.title_en}
                    </span>
                    <span className="text-slate-500 text-[11px] block mt-0.5">
                      Target Link: {bnr.cta_link} • Priority: #{bnr.display_order} • CTA: {bnr.cta_text_en}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end sm:self-center">
                  <span
                    className={`font-bold px-2 py-0.5 rounded-full text-[10px] ${
                      bnr.is_active
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {bnr.is_active ? 'Live' : 'Hidden'}
                  </span>
                  <button
                    type="button"
                    onClick={() => openEditBanner(bnr)}
                    className="p-1.5 text-slate-500 hover:text-brand-600 hover:bg-slate-200 rounded-lg transition"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteBanner(bnr.id)}
                    className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-slate-200 rounded-lg transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Gallery Tab View */}
      {activeTab === 'gallery' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <div className="flex justify-between items-center border-b border-slate-100 pb-4">
            <div>
              <h2 className="font-bold text-sm text-slate-900">
                Active Gallery Showcase
              </h2>
              <p className="text-xs text-slate-500">
                Upload and manage photography from the store, installations, and laboratory.
              </p>
            </div>
            <button
              type="button"
              onClick={openCreateGallery}
              className="flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-2 px-3.5 rounded-xl shadow transition"
            >
              <Plus className="w-4 h-4" />
              <span>Add Photo</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {gallery.map((item) => (
              <div
                key={item.id}
                className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between"
              >
                <div>
                  <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-slate-100 mb-2 border border-slate-200">
                    <SafeImage
                      src={item.url}
                      alt={item.title}
                      fill
                      type="gallery"
                      className="object-cover"
                    />
                  </div>
                  <span className="font-bold text-slate-900 block truncate">
                    {item.title}
                  </span>
                  <span className="text-slate-500 text-[10px] uppercase font-semibold">
                    Category: {item.category}
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-100 mt-2 flex justify-end gap-1">
                  <button
                    type="button"
                    onClick={() => openEditGallery(item)}
                    className="p-1.5 text-slate-500 hover:text-brand-600 hover:bg-slate-200 rounded-lg transition"
                  >
                    <Edit className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteGallery(item.id)}
                    className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-slate-200 rounded-lg transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Service Modal */}
      {isServiceModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h2 className="font-bold text-base text-slate-900">
                {editingService ? 'Edit Service' : 'Add New Service'}
              </h2>
              <button
                type="button"
                onClick={() => setIsServiceModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveService} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Service Title (English) *
                </label>
                <input
                  type="text"
                  required
                  value={svcTitleEn}
                  onChange={(e) => setSvcTitleEn(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Service Title (Nepali)
                </label>
                <input
                  type="text"
                  value={svcTitleNe}
                  onChange={(e) => setSvcTitleNe(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Icon Identifier
                </label>
                <select
                  value={svcIcon}
                  onChange={(e) => setSvcIcon(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                >
                  <option value="cctv">CCTV & Security</option>
                  <option value="laptop">Laptop & Computer Repair</option>
                  <option value="printer">Printer & Cartridge</option>
                  <option value="network">Networking & Cabling</option>
                  <option value="software">Software & Accounting</option>
                  <option value="power">UPS & Power Backup</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={svcDescEn}
                  onChange={(e) => setSvcDescEn(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Display Order
                </label>
                <input
                  type="number"
                  value={svcOrder}
                  onChange={(e) => setSvcOrder(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsServiceModalOpen(false)}
                  className="bg-slate-100 text-slate-700 font-bold px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-brand-600 text-white font-bold px-5 py-2 rounded-xl shadow"
                >
                  Save Service
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Banner Modal */}
      {isBannerModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl my-8">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h2 className="font-bold text-base text-slate-900">
                {editingBanner ? 'Edit Hero Banner' : 'Add Hero Banner'}
              </h2>
              <button
                type="button"
                onClick={() => setIsBannerModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBanner} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Headline (English) *
                </label>
                <input
                  type="text"
                  required
                  value={bnrTitleEn}
                  onChange={(e) => setBnrTitleEn(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Headline (Nepali)
                </label>
                <input
                  type="text"
                  value={bnrTitleNe}
                  onChange={(e) => setBnrTitleNe(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Subtitle (English)
                </label>
                <textarea
                  rows={2}
                  value={bnrSubEn}
                  onChange={(e) => setBnrSubEn(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              {/* Direct Cloudinary Banner Image Uploader */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                <ImageUploader
                  label="Banner Background Image (Cloudinary)"
                  folder="numbur-it/banners"
                  aspectRatio="video"
                  value={bnrImageUrl}
                  onChange={setBnrImageUrl}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    CTA Button Text
                  </label>
                  <input
                    type="text"
                    value={bnrCtaText}
                    onChange={(e) => setBnrCtaText(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    CTA Target Link
                  </label>
                  <input
                    type="text"
                    value={bnrCtaLink}
                    onChange={(e) => setBnrCtaLink(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Display Priority
                  </label>
                  <input
                    type="number"
                    value={bnrOrder}
                    onChange={(e) => setBnrOrder(Number(e.target.value))}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                    <input
                      type="checkbox"
                      checked={bnrActive}
                      onChange={(e) => setBnrActive(e.target.checked)}
                      className="rounded text-brand-600"
                    />
                    <span>Active in Slider</span>
                  </label>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsBannerModalOpen(false)}
                  className="bg-slate-100 text-slate-700 font-bold px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-brand-600 text-white font-bold px-5 py-2 rounded-xl shadow"
                >
                  Save Banner
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Gallery Modal */}
      {isGalleryModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl my-8">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h2 className="font-bold text-base text-slate-900">
                {editingGallery ? 'Edit Gallery Photo' : 'Add Gallery Photo'}
              </h2>
              <button
                type="button"
                onClick={() => setIsGalleryModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveGallery} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Photo Title / Description *
                </label>
                <input
                  type="text"
                  required
                  value={galTitle}
                  onChange={(e) => setGalTitle(e.target.value)}
                  placeholder="e.g. CCTV Field Deployment at Hospital"
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Showcase Category
                </label>
                <select
                  value={galCategory}
                  onChange={(e) => setGalCategory(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                >
                  <option value="Store">Store & Showroom</option>
                  <option value="Workplace">Workplace & Laboratory</option>
                  <option value="Installations">CCTV & Field Installations</option>
                  <option value="Equipment">Printers & Hardware Inventory</option>
                  <option value="Networking">Fiber & Networking</option>
                </select>
              </div>

              {/* Direct Cloudinary Image Uploader */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                <ImageUploader
                  label="Showcase Photo (Cloudinary)"
                  folder="numbur-it/gallery"
                  value={galUrl}
                  onChange={setGalUrl}
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsGalleryModalOpen(false)}
                  className="bg-slate-100 text-slate-700 font-bold px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-brand-600 text-white font-bold px-5 py-2 rounded-xl shadow"
                >
                  Save Photo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
