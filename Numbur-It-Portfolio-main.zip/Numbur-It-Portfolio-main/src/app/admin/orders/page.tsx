'use client';

import React, { useState, useEffect } from 'react';
import { Order, OrderStatus, PaymentStatus, PaymentMethod } from '@/types';
import {
  ShoppingCart,
  MessageSquare,
  DollarSign,
  CheckCircle2,
  XCircle,
  Eye,
  Phone,
  Clock,
  ShieldCheck,
  AlertCircle,
  X,
} from 'lucide-react';

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<any | null>(null);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('fonepay_qr');
  const [paymentRef, setPaymentRef] = useState('');
  const [paymentNotes, setPaymentNotes] = useState('');
  const [paymentError, setPaymentError] = useState('');

  useEffect(() => {
    async function loadOrders() {
      try {
        const res = await fetch('/api/admin/orders', { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data.orders && data.orders.length > 0) {
            setOrders(data.orders);
            localStorage.setItem('numbur_orders', JSON.stringify(data.orders));
            return;
          }
        }
      } catch (err) {
        console.warn('Could not load orders from API, checking local storage:', err);
      }

      const stored = JSON.parse(localStorage.getItem('numbur_orders') || '[]');
      if (stored.length > 0) {
        setOrders(stored);
      } else {
        // Seed default demo order if none exists
        const demoOrders = [
          {
            order_number: 'NIS-2026-1042',
            customer_name: 'Niraz Sapkota',
            customer_phone: '9854040821',
            delivery_address: 'Khimti-7, Ramechhap',
            municipality_area: 'Manthali Municipality',
            delivery_method: 'ramechhap_delivery',
            delivery_instructions: 'Deliver via Bolero vehicle near Khimti bazaar',
            subtotal_amount: 4499,
            total_amount: 4499,
            advance_payment_amount: 1000,
            remaining_balance: 3499,
            order_status: 'confirmed',
            payment_status: 'advance_paid',
            internal_notes: 'Advance verified via Fonepay QR. Ready to dispatch.',
            created_at: new Date(Date.now() - 3600000 * 4).toISOString(),
            items: [
              {
                name: 'EZVIZ H8c 2MP Smart WiFi Outdoor Camera',
                sku: 'CAM-EZ-H8C-2MP',
                quantity: 1,
                price: 4499,
                total: 4499,
              },
            ],
          },
        ];
        setOrders(demoOrders);
        localStorage.setItem('numbur_orders', JSON.stringify(demoOrders));
      }
    }

    loadOrders();
  }, []);

  const saveOrdersState = (updated: any[]) => {
    setOrders(updated);
    localStorage.setItem('numbur_orders', JSON.stringify(updated));
  };

  const updateOrderStatus = async (orderNumber: string, newStatus: OrderStatus) => {
    const updated = orders.map((o) =>
      o.order_number === orderNumber
        ? {
            ...o,
            order_status: newStatus,
            updated_at: new Date().toISOString(),
          }
        : o
    );
    saveOrdersState(updated);
    if (selectedOrder && selectedOrder.order_number === orderNumber) {
      setSelectedOrder({ ...selectedOrder, order_status: newStatus });
    }

    try {
      await fetch('/api/admin/orders', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_number: orderNumber, order_status: newStatus }),
      });
    } catch (e) {
      console.warn('Failed to sync order status update with DB:', e);
    }
  };

  const openPaymentModal = (ord: any) => {
    setSelectedOrder(ord);
    setPaymentAmount(Math.min(1000, ord.remaining_balance));
    setPaymentMethod('fonepay_qr');
    setPaymentRef('');
    setPaymentNotes('');
    setPaymentError('');
    setIsPaymentModalOpen(true);
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentError('');

    if (!selectedOrder) return;
    if (paymentAmount <= 0) {
      setPaymentError('Payment amount must be greater than 0.');
      return;
    }

    // VALIDATION: Payment cannot exceed outstanding balance
    if (paymentAmount > selectedOrder.remaining_balance) {
      setPaymentError(
        `Validation Error: Payment amount (Rs. ${paymentAmount}) exceeds the outstanding remaining balance (Rs. ${selectedOrder.remaining_balance}).`
      );
      return;
    }

    const newAdvance = (selectedOrder.advance_payment_amount || 0) + paymentAmount;
    const newRemaining = (selectedOrder.remaining_balance || selectedOrder.total_amount) - paymentAmount;
    const newPaymentStatus: PaymentStatus =
      newRemaining === 0 ? 'paid' : 'partially_paid';

    const recordedNotes = `${selectedOrder.internal_notes || ''}\n[Payment Recorded: Rs. ${paymentAmount} via ${paymentMethod}, Ref: ${paymentRef || 'N/A'}]`.trim();

    const updated = orders.map((o) =>
      o.order_number === selectedOrder.order_number
        ? {
            ...o,
            advance_payment_amount: newAdvance,
            remaining_balance: newRemaining,
            payment_status: newPaymentStatus,
            internal_notes: recordedNotes,
          }
        : o
    );

    saveOrdersState(updated);
    setSelectedOrder({
      ...selectedOrder,
      advance_payment_amount: newAdvance,
      remaining_balance: newRemaining,
      payment_status: newPaymentStatus,
      internal_notes: recordedNotes,
    });
    setIsPaymentModalOpen(false);

    try {
      await fetch('/api/admin/orders', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          order_number: selectedOrder.order_number,
          payment_status: newPaymentStatus,
          advance_payment_amount: newAdvance,
          remaining_balance: newRemaining,
          internal_notes: recordedNotes,
        }),
      });
    } catch (e) {
      console.warn('Failed to sync payment with DB:', e);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900">
            Order Management & Advance Payments
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Review incoming WhatsApp orders, confirm dispatch, and record payments.
          </p>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4">Order ID & Date</th>
              <th className="py-3 px-4">Customer & Phone</th>
              <th className="py-3 px-4">Delivery Method</th>
              <th className="py-3 px-4">Total Amount</th>
              <th className="py-3 px-4">Advance Paid</th>
              <th className="py-3 px-4">Remaining Balance</th>
              <th className="py-3 px-4">Order Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {orders.map((ord) => (
              <tr key={ord.order_number} className="hover:bg-slate-50/80 transition">
                <td className="py-3 px-4">
                  <span className="font-mono font-bold text-slate-900 block">
                    #{ord.order_number}
                  </span>
                  <span className="text-[10px] text-slate-400">
                    {new Date(ord.created_at).toLocaleDateString()}
                  </span>
                </td>
                <td className="py-3 px-4">
                  <span className="font-bold text-slate-900 block">
                    {ord.customer_name}
                  </span>
                  <a
                    href={`tel:${ord.customer_phone}`}
                    className="text-[11px] text-brand-600 hover:underline"
                  >
                    {ord.customer_phone}
                  </a>
                </td>
                <td className="py-3 px-4">
                  <span className="text-[11px] text-slate-600">
                    {ord.delivery_method === 'ramechhap_delivery'
                      ? 'Ramechhap Road'
                      : 'Store Pickup'}
                  </span>
                </td>
                <td className="py-3 px-4 font-bold text-slate-900">
                  Rs. {ord.total_amount.toLocaleString('en-IN')}
                </td>
                <td className="py-3 px-4 font-bold text-emerald-600">
                  Rs. {ord.advance_payment_amount.toLocaleString('en-IN')}
                </td>
                <td className="py-3 px-4 font-bold text-red-600">
                  Rs. {ord.remaining_balance.toLocaleString('en-IN')}
                </td>
                <td className="py-3 px-4">
                  <select
                    value={ord.order_status}
                    onChange={(e) =>
                      updateOrderStatus(
                        ord.order_number,
                        e.target.value as OrderStatus
                      )
                    }
                    className="text-[11px] font-bold rounded-lg p-1.5 border border-slate-200 bg-slate-50 focus:outline-none"
                  >
                    <option value="pending">Pending</option>
                    <option value="contacted">Contacted</option>
                    <option value="confirmed">Confirmed</option>
                    <option value="processing">Processing</option>
                    <option value="ready_for_pickup">Ready for Pickup</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-1.5">
                    {/* Record Advance Payment */}
                    <button
                      type="button"
                      onClick={() => openPaymentModal(ord)}
                      className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-1 rounded"
                    >
                      + Payment
                    </button>

                    {/* WhatsApp Customer Direct */}
                    <a
                      href={`https://wa.me/977${ord.customer_phone.replace(/[^0-9]/g, '')}?text=Namaste%20${encodeURIComponent(ord.customer_name)},%20Numbur%20iT%20Solution%20here%20regarding%20your%20Order%20%23${ord.order_number}.`}
                      target="_blank"
                      rel="noreferrer"
                      className="p-1.5 bg-emerald-600 text-white rounded hover:bg-emerald-700"
                      title="Chat on WhatsApp"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Payment Recording Modal */}
      {isPaymentModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h2 className="font-bold text-base text-slate-900">
                Record Payment for Order #{selectedOrder.order_number}
              </h2>
              <button
                type="button"
                onClick={() => setIsPaymentModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Total Order Amount:</span>
                <span className="font-bold">
                  Rs. {selectedOrder.total_amount.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between text-emerald-600">
                <span>Already Paid:</span>
                <span className="font-bold">
                  Rs. {selectedOrder.advance_payment_amount.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between text-red-600 font-bold pt-1 border-t border-slate-200">
                <span>Outstanding Remaining Balance:</span>
                <span>Rs. {selectedOrder.remaining_balance.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {paymentError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{paymentError}</span>
              </div>
            )}

            <form onSubmit={handleRecordPayment} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Payment Amount (Rs.) *
                </label>
                <input
                  type="number"
                  min="1"
                  max={selectedOrder.remaining_balance}
                  required
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 font-bold focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Payment Method *
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) =>
                    setPaymentMethod(e.target.value as PaymentMethod)
                  }
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 font-semibold focus:bg-white"
                >
                  <option value="fonepay_qr">Fonepay QR Code</option>
                  <option value="esewa">eSewa Mobile Wallet</option>
                  <option value="bank_transfer">Bank Transfer (Nabil / Global IME)</option>
                  <option value="cash">Cash upon Store Pickup / Delivery</option>
                  <option value="khalti">Khalti Wallet</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Payment Reference / Transaction ID
                </label>
                <input
                  type="text"
                  value={paymentRef}
                  onChange={(e) => setPaymentRef(e.target.value)}
                  placeholder="e.g. TXN-94829103"
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white font-mono"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsPaymentModalOpen(false)}
                  className="bg-slate-100 text-slate-700 font-bold px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-5 py-2 rounded-xl shadow"
                >
                  Record Payment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
