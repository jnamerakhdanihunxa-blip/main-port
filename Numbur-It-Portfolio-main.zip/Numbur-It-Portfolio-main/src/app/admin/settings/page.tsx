'use client';

import React, { useState, useEffect } from 'react';
import {
  Settings,
  Save,
  Check,
  Phone,
  MessageSquare,
  MapPin,
  Database,
  Cloud,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Sparkles,
  Server,
} from 'lucide-react';

interface HealthStatus {
  supabase: {
    configured: boolean;
    hasUrl: boolean;
    hasAnonKey: boolean;
    hasServiceKey: boolean;
  };
  cloudinary: {
    configured: boolean;
    hasCloudName: boolean;
    hasApiKey: boolean;
    hasApiSecret: boolean;
  };
}

export default function AdminSettingsPage() {
  const [whatsappNumber, setWhatsappNumber] = useState('9779854040821');
  const [storePhone, setStorePhone] = useState('048540314');
  const [storeEmail, setStoreEmail] = useState('numburitsolution1@gmail.com');
  const [storeAddressEn, setStoreAddressEn] = useState('Manthali-1, Ramechhap, Bagmati Province, Nepal');
  const [businessHoursEn, setBusinessHoursEn] = useState('Sun - Fri: 9:00 AM - 6:00 PM | Sat: Closed');
  const [advancePaymentInfo, setAdvancePaymentInfo] = useState('Nabil Bank / Global IME Bank / eSewa: 9854040821');
  const [saved, setSaved] = useState(false);

  // Cloud & Supabase Diagnostics
  const [health, setHealth] = useState<HealthStatus | null>(null);
  const [isCheckingHealth, setIsCheckingHealth] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);
  const [seedResult, setSeedResult] = useState<{ message: string; isError?: boolean } | null>(null);

  const checkHealth = async () => {
    setIsCheckingHealth(true);
    try {
      const res = await fetch('/api/health');
      const data = await res.json();
      setHealth(data);
    } catch (e) {
      console.warn('Health check failed:', e);
    } finally {
      setIsCheckingHealth(false);
    }
  };

  useEffect(() => {
    checkHealth();
  }, []);

  const handleSeedDatabase = async () => {
    if (!confirm('This will seed the initial catalog, services, staff, and banners into your Supabase database. Proceed?')) {
      return;
    }

    setIsSeeding(true);
    setSeedResult(null);

    try {
      const res = await fetch('/api/seed-supabase', { method: 'POST' });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to seed database.');
      }

      setSeedResult({
        message: `Success! Seeded ${data.counts.categories} categories, ${data.counts.products} products, ${data.counts.services} services, ${data.counts.staff} staff members, and ${data.counts.banners} banners.`,
      });
    } catch (err: any) {
      setSeedResult({
        message: err.message || 'Error executing Supabase seed.',
        isError: true,
      });
    } finally {
      setIsSeeding(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem(
      'numbur_site_settings',
      JSON.stringify({
        whatsapp_number: whatsappNumber,
        store_phone: storePhone,
        store_email: storeEmail,
        store_address_en: storeAddressEn,
        business_hours_en: businessHoursEn,
        advance_payment_info: advancePaymentInfo,
      })
    );
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="space-y-8 max-w-4xl">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <h1 className="text-2xl font-extrabold text-slate-900">
          System Diagnostics & Business Settings
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Monitor your Supabase & Cloudinary integrations, manage database tables, and configure business contact details.
        </p>
      </div>

      {/* CLOUD CONNECTIONS DIAGNOSTIC CARD */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
        <div className="flex justify-between items-center border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-brand-50 border border-brand-200 flex items-center justify-center text-brand-600">
              <Server className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-bold text-base text-slate-900">
                Cloud Integrations Status
              </h2>
              <p className="text-xs text-slate-500">
                Live verification of Supabase PostgreSQL and Cloudinary Media CDN.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={checkHealth}
            disabled={isCheckingHealth}
            className="flex items-center gap-1.5 text-xs text-brand-600 hover:text-brand-800 font-semibold bg-brand-50 hover:bg-brand-100 px-3 py-1.5 rounded-xl transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isCheckingHealth ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Supabase Status Box */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-3 text-xs">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2 font-bold text-slate-900">
                <Database className="w-4 h-4 text-emerald-600" />
                <span>Supabase Database</span>
              </div>
              {health?.supabase.configured ? (
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Connected
                </span>
              ) : (
                <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> Needs Configuration
                </span>
              )}
            </div>

            <div className="space-y-1.5 text-[11px] text-slate-600 font-mono">
              <div className="flex justify-between">
                <span>URL:</span>
                <span>{health?.supabase.hasUrl ? '✓ Configured' : '✗ Missing'}</span>
              </div>
              <div className="flex justify-between">
                <span>Anon Key:</span>
                <span>{health?.supabase.hasAnonKey ? '✓ Configured' : '✗ Missing'}</span>
              </div>
              <div className="flex justify-between">
                <span>Service Role Key:</span>
                <span>{health?.supabase.hasServiceKey ? '✓ Configured' : '✗ Optional'}</span>
              </div>
            </div>

            {/* Seed Database Button */}
            <div className="pt-2 border-t border-slate-200/80">
              <button
                type="button"
                onClick={handleSeedDatabase}
                disabled={isSeeding || !health?.supabase.configured}
                className={`w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl font-bold text-xs transition ${
                  health?.supabase.configured
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isSeeding ? 'Seeding Database...' : 'Initialize Supabase Catalog'}</span>
              </button>
            </div>
          </div>

          {/* Cloudinary Status Box */}
          <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-3 text-xs">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2 font-bold text-slate-900">
                <Cloud className="w-4 h-4 text-cyan-600" />
                <span>Cloudinary CDN</span>
              </div>
              {health?.cloudinary.configured ? (
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Ready for Uploads
                </span>
              ) : (
                <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> Credentials Needed
                </span>
              )}
            </div>

            <div className="space-y-1.5 text-[11px] text-slate-600 font-mono">
              <div className="flex justify-between">
                <span>Cloud Name:</span>
                <span>{health?.cloudinary.hasCloudName ? '✓ Configured' : '✗ Missing'}</span>
              </div>
              <div className="flex justify-between">
                <span>API Key:</span>
                <span>{health?.cloudinary.hasApiKey ? '✓ Configured' : '✗ Missing'}</span>
              </div>
              <div className="flex justify-between">
                <span>API Secret:</span>
                <span>{health?.cloudinary.hasApiSecret ? '✓ Configured' : '✗ Missing'}</span>
              </div>
            </div>

            <p className="text-[10px] text-slate-500 pt-1 leading-relaxed">
              When configured, admins can drag and drop photos from desktop straight into Cloudinary.
            </p>
          </div>
        </div>

        {seedResult && (
          <div
            className={`p-3.5 rounded-2xl text-xs flex items-start gap-2.5 ${
              seedResult.isError
                ? 'bg-red-50 border border-red-200 text-red-800'
                : 'bg-emerald-50 border border-emerald-200 text-emerald-800'
            }`}
          >
            {seedResult.isError ? (
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
            ) : (
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
            )}
            <span className="leading-relaxed">{seedResult.message}</span>
          </div>
        )}

        {/* Configuration Guide */}
        <div className="p-4 rounded-2xl bg-brand-50/50 border border-brand-200 text-xs text-slate-700 space-y-2">
          <span className="font-bold text-slate-900 block">
            Connecting Your Credentials (.env.local):
          </span>
          <p className="text-[11px] text-slate-600 leading-relaxed">
            Create or edit <code className="bg-white px-1.5 py-0.5 rounded border border-slate-200 font-mono">.env.local</code> in the project root with your credentials:
          </p>
          <pre className="p-3 bg-slate-900 text-slate-100 rounded-xl text-[10px] font-mono overflow-x-auto leading-relaxed">
{`# Supabase (Project Settings -> API)
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGci...

# Cloudinary (Cloudinary Dashboard)
NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=your_cloud_name
NEXT_PUBLIC_CLOUDINARY_API_KEY=123456789
CLOUDINARY_API_SECRET=your_api_secret`}
          </pre>
        </div>
      </div>

      {/* STORE SETTINGS FORM */}
      <form onSubmit={handleSave} className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6 text-xs">
        <div className="border-b border-slate-100 pb-3">
          <h2 className="font-bold text-base text-slate-900">
            Store Contact & Payment Parameters
          </h2>
          <p className="text-xs text-slate-500">
            Business contact coordinates and customer checkout payment instructions.
          </p>
        </div>

        {saved && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>Settings saved successfully!</span>
          </div>
        )}

        {/* WhatsApp Configuration */}
        <div className="space-y-2 bg-emerald-50/50 p-4 rounded-2xl border border-emerald-200">
          <label className="block font-bold text-slate-900 flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-emerald-600" />
            <span>Configured WhatsApp Business Number *</span>
          </label>
          <input
            type="text"
            required
            value={whatsappNumber}
            onChange={(e) => setWhatsappNumber(e.target.value)}
            placeholder="e.g. 9779854040821"
            className="w-full rounded-xl border border-emerald-300 p-2.5 bg-white font-mono text-xs focus:ring-2 focus:ring-emerald-500"
          />
          <span className="text-[11px] text-slate-500 block">
            Used across the entire platform for order dispatch, cart checkout, and customer support. Format: country code + number (977...).
          </span>
        </div>

        {/* Contact Coordinates */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Store Landline Phone *
            </label>
            <input
              type="text"
              required
              value={storePhone}
              onChange={(e) => setStorePhone(e.target.value)}
              className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Official Business Email *
            </label>
            <input
              type="email"
              required
              value={storeEmail}
              onChange={(e) => setStoreEmail(e.target.value)}
              className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
            />
          </div>
        </div>

        <div>
          <label className="block font-bold text-slate-700 mb-1">
            Physical Store Address
          </label>
          <input
            type="text"
            required
            value={storeAddressEn}
            onChange={(e) => setStoreAddressEn(e.target.value)}
            className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
          />
        </div>

        <div>
          <label className="block font-bold text-slate-700 mb-1">
            Store Business Hours
          </label>
          <input
            type="text"
            required
            value={businessHoursEn}
            onChange={(e) => setBusinessHoursEn(e.target.value)}
            className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
          />
        </div>

        <div>
          <label className="block font-bold text-slate-700 mb-1">
            Advance Payment Account Details (Shown on checkout instructions)
          </label>
          <textarea
            rows={2}
            value={advancePaymentInfo}
            onChange={(e) => setAdvancePaymentInfo(e.target.value)}
            className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
          />
        </div>

        <div className="pt-4 border-t border-slate-100 flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-3 px-6 rounded-xl transition shadow"
          >
            <Save className="w-4 h-4" />
            <span>Save Settings</span>
          </button>
        </div>
      </form>
    </div>
  );
}
