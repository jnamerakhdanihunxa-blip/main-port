'use client';

import React, { useState, useEffect } from 'react';
import SafeImage from '@/components/ui/SafeImage';
import ImageUploader from '@/components/admin/ImageUploader';
import {
  Sparkles,
  Save,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Eye,
  Layers,
  Palette,
  Database,
} from 'lucide-react';

export default function AdminBrandingPage() {
  const [logoUrl, setLogoUrl] = useState('');
  const [aboutImageUrl, setAboutImageUrl] = useState('');
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const loadSettings = async () => {
    try {
      const res = await fetch('/api/admin/settings', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.settings?.site_logo_url) {
          setLogoUrl(data.settings.site_logo_url);
        }
        if (data.settings?.about_image_url) {
          setAboutImageUrl(data.settings.about_image_url);
        }
      }
    } catch (err) {
      console.warn('Failed to load branding settings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSettings();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSuccessMsg('');
    setErrorMsg('');

    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: {
            site_logo_url: logoUrl.trim(),
            about_image_url: aboutImageUrl.trim(),
          },
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to save brand settings.');
      }

      setSuccessMsg('Brand settings updated successfully! Changes are live across the website.');
      setTimeout(() => setSuccessMsg(''), 4000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error updating brand settings.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetToDefault = async () => {
    if (!confirm('Reset to the default Numbur iT brand mark?')) return;

    setLogoUrl('');
    setIsSubmitting(true);

    try {
      await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: {
            site_logo_url: '',
          },
        }),
      });
      setSuccessMsg('Reset to default typography logo.');
      setTimeout(() => setSuccessMsg(''), 3000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Error resetting logo.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8 max-w-5xl">
      {/* Header Bar */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
              Logo & Brand Identity Management
            </h1>
            <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
              <Database className="w-3 h-3 text-emerald-600" /> Supabase Live
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
            Upload your company logo to Cloudinary. It will dynamically render across the public navigation header, mobile menu, footer, and administrative login screens.
          </p>
        </div>

        <button
          type="button"
          onClick={handleResetToDefault}
          className="flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-red-600 px-4 py-2.5 rounded-xl border border-slate-200 hover:bg-red-50 transition"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to Default</span>
        </button>
      </div>

      {successMsg && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-2xl flex items-center gap-2.5">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-800 text-xs rounded-2xl flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Upload Form Box */}
        <div className="lg:col-span-6 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <h2 className="font-extrabold text-base text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <Palette className="w-4 h-4 text-brand-600" />
            <span>Upload Custom Logo</span>
          </h2>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">
              Logo Graphic File (PNG with transparent background recommended)
            </label>
            <ImageUploader
              value={logoUrl}
              onChange={(url) => setLogoUrl(url)}
              folder="numbur-it/branding"
              label="Upload Company Logo"
              aspectRatio="square"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Direct Logo URL
            </label>
            <input
              type="url"
              value={logoUrl}
              onChange={(e) => setLogoUrl(e.target.value)}
              placeholder="https://res.cloudinary.com/..."
              className="w-full text-xs font-mono rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              You can upload directly above or paste an existing Cloudinary secure image URL.
            </p>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-3 px-6 rounded-xl shadow-md transition disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{isSubmitting ? 'Saving...' : 'Save All Branding Changes'}</span>
          </button>
        </div>

        {/* Live Multi-Surface Preview */}
        <div className="lg:col-span-6 space-y-5">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <h3 className="font-extrabold text-sm text-slate-900 border-b border-slate-100 pb-2.5 flex items-center gap-2">
              <Eye className="w-4 h-4 text-slate-500" />
              <span>Surface Previews</span>
            </h3>

            {/* Light Navbar Preview */}
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                1. Light Header Bar Preview
              </span>
              <div className="p-4 bg-white rounded-2xl border border-slate-200 flex items-center gap-3 shadow-xs">
                {logoUrl ? (
                  <div className="relative w-11 h-11 rounded-xl overflow-hidden shrink-0 border border-slate-200 bg-white p-0.5">
                    <SafeImage src={logoUrl} alt="Logo preview" fill className="object-contain" />
                  </div>
                ) : (
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-brand-700 to-blue-500 flex items-center justify-center text-white font-black text-2xl shadow">
                    N
                  </div>
                )}
                <div>
                  <span className="font-extrabold text-lg text-slate-900 block leading-tight">
                    Numbur <span className="text-brand-600">iT</span>
                  </span>
                  <span className="text-[10px] uppercase text-slate-500 font-semibold block">
                    Solution Pvt. Ltd.
                  </span>
                </div>
              </div>
            </div>

            {/* Dark Footer Preview */}
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                2. Dark Footer Preview
              </span>
              <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 flex items-center gap-3 text-white">
                {logoUrl ? (
                  <div className="relative w-11 h-11 rounded-xl overflow-hidden shrink-0 border border-slate-800 bg-white/5 p-0.5">
                    <SafeImage src={logoUrl} alt="Logo preview" fill className="object-contain" />
                  </div>
                ) : (
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-brand-600 to-blue-500 flex items-center justify-center text-white font-black text-xl shadow">
                    N
                  </div>
                )}
                <div>
                  <span className="font-extrabold text-lg text-white block leading-tight">
                    Numbur <span className="text-brand-400">iT</span> Solution
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium block">
                    Pvt. Ltd. • Regd. 2069 BS
                  </span>
                </div>
              </div>
            </div>

            {/* Portal Login Preview */}
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-1.5">
                3. Secure Portal Badge Preview
              </span>
              <div className="p-5 bg-slate-900 rounded-2xl border border-slate-800 flex flex-col items-center justify-center text-center">
                {logoUrl ? (
                  <div className="relative w-14 h-14 rounded-2xl overflow-hidden mb-2 border border-slate-700 bg-white/10 p-1">
                    <SafeImage src={logoUrl} alt="Portal preview" fill className="object-contain" />
                  </div>
                ) : (
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-brand-600 to-blue-500 flex items-center justify-center text-white font-black text-2xl shadow-xl mb-2">
                    N
                  </div>
                )}
                <span className="text-white font-black text-base">Numbur iT Portal</span>
                <span className="text-[10px] text-brand-400 font-mono">CRM & Stock Ledger</span>
              </div>
            </div>
          </div>
        </div>

        {/* About Us Photo Management Box */}
        <div className="lg:col-span-12 bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-slate-100 pb-3">
            <h2 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-brand-600" />
              <span>About Us Storefront / Office Photo</span>
            </h2>
            <span className="text-xs text-slate-400">
              Live photo displayed on the /about company profile page
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">
                  Storefront / Team Photo (Landscape Recommended)
                </label>
                <ImageUploader
                  value={aboutImageUrl}
                  onChange={(url) => setAboutImageUrl(url)}
                  folder="numbur-it/about"
                  label="Upload Storefront / Office Photo"
                  aspectRatio="video"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Direct Image URL
                </label>
                <input
                  type="url"
                  value={aboutImageUrl}
                  onChange={(e) => setAboutImageUrl(e.target.value)}
                  placeholder="https://res.cloudinary.com/..."
                  className="w-full text-xs font-mono rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>
            </div>

            {/* About Page Photo Preview */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                Live Preview (About Page Display)
              </label>
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 shadow-inner">
                {aboutImageUrl ? (
                  <SafeImage
                    src={aboutImageUrl}
                    alt="About page storefront preview"
                    fill
                    className="object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center text-slate-400 p-6 text-center">
                    <Sparkles className="w-8 h-8 mb-2 text-slate-300" />
                    <p className="text-xs font-medium">No custom storefront photo uploaded yet.</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Upload an authentic photo of your Manthali storefront or office above.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-3 px-8 rounded-xl shadow-md transition disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving All Settings...' : 'Save All Brand Settings'}</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
