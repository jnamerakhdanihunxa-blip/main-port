'use client';

import React, { useState, useEffect } from 'react';
import { FALLBACK_SOCIAL_LINKS } from '@/lib/site-defaults';
import {
  Share2,
  Plus,
  Edit,
  Trash2,
  ExternalLink,
  CheckCircle2,
  X,
  Eye,
  EyeOff,
  Globe,
  Facebook,
  Youtube,
  Instagram,
  Linkedin,
  MessageCircle,
  Video,
} from 'lucide-react';

interface SocialLink {
  id: string;
  platform: string;
  platform_name: string;
  url: string;
  icon_name?: string;
  display_order: number;
  is_active: boolean;
}

export default function AdminSocialPage() {
  const [links, setLinks] = useState<SocialLink[]>(FALLBACK_SOCIAL_LINKS);
  const [loading, setLoading] = useState(true);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingLink, setEditingLink] = useState<SocialLink | null>(null);

  // Form Fields
  const [platform, setPlatform] = useState('facebook');
  const [platformName, setPlatformName] = useState('Facebook');
  const [url, setUrl] = useState('');
  const [displayOrder, setDisplayOrder] = useState(1);
  const [isActive, setIsActive] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const loadLinks = async () => {
    try {
      const res = await fetch('/api/admin/social', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.links && data.links.length > 0) {
          setLinks(data.links);
        }
      }
    } catch (err) {
      console.warn('Failed to load social links:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLinks();
  }, []);

  const openCreateModal = () => {
    setEditingLink(null);
    setPlatform('facebook');
    setPlatformName('Facebook');
    setUrl('https://www.facebook.com/');
    setDisplayOrder(links.length + 1);
    setIsActive(true);
    setIsModalOpen(true);
  };

  const openEditModal = (item: SocialLink) => {
    setEditingLink(item);
    setPlatform(item.platform);
    setPlatformName(item.platform_name);
    setUrl(item.url);
    setDisplayOrder(item.display_order);
    setIsActive(item.is_active);
    setIsModalOpen(true);
  };

  const handlePlatformChange = (p: string) => {
    setPlatform(p);
    const names: Record<string, string> = {
      facebook: 'Facebook',
      whatsapp: 'WhatsApp Support',
      youtube: 'YouTube Channel',
      instagram: 'Instagram',
      tiktok: 'TikTok',
      linkedin: 'LinkedIn',
      twitter: 'Twitter / X',
      other: 'Official Website',
    };
    setPlatformName(names[p] || p);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) {
      alert('URL is required.');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        action: editingLink ? 'update' : 'create',
        id: editingLink?.id,
        platform,
        platform_name: platformName.trim(),
        url: url.trim(),
        display_order: Number(displayOrder),
        is_active: isActive,
      };

      const res = await fetch('/api/admin/social', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to save social link.');
        return;
      }

      await loadLinks();
      setIsModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Error saving social link.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to remove this social link?')) {
      return;
    }

    try {
      const res = await fetch('/api/admin/social', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', id }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to delete link.');
        return;
      }

      setLinks((prev) => prev.filter((l) => l.id !== id));
    } catch (err: any) {
      alert(err.message || 'Error deleting link.');
    }
  };

  const toggleActive = async (link: SocialLink) => {
    try {
      const res = await fetch('/api/admin/social', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update',
          id: link.id,
          is_active: !link.is_active,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to toggle status.');
        return;
      }

      setLinks((prev) =>
        prev.map((l) => (l.id === link.id ? { ...l, is_active: !l.is_active } : l))
      );
    } catch (err: any) {
      alert(err.message || 'Error toggling status.');
    }
  };

  const getPlatformIcon = (plat: string) => {
    switch (plat.toLowerCase()) {
      case 'facebook':
        return <Facebook className="w-5 h-5 text-blue-600" />;
      case 'whatsapp':
        return <MessageCircle className="w-5 h-5 text-emerald-600" />;
      case 'youtube':
        return <Youtube className="w-5 h-5 text-red-600" />;
      case 'instagram':
        return <Instagram className="w-5 h-5 text-pink-600" />;
      case 'tiktok':
        return <Video className="w-5 h-5 text-slate-800" />;
      case 'linkedin':
        return <Linkedin className="w-5 h-5 text-blue-700" />;
      default:
        return <Globe className="w-5 h-5 text-brand-600" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Bar */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
            Social Media & Communication Links
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
            Manage public social profiles displayed in the website footer and contact channels. Enable or disable platforms anytime.
          </p>
        </div>

        <button
          type="button"
          onClick={openCreateModal}
          className="flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-3 px-5 rounded-xl shadow-md transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Social Link</span>
        </button>
      </div>

      {/* Social Links List */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50 text-[11px] font-bold uppercase tracking-wider text-slate-500">
                <th className="py-3.5 px-6">Platform</th>
                <th className="py-3.5 px-6">Target URL</th>
                <th className="py-3.5 px-6">Order</th>
                <th className="py-3.5 px-6">Status</th>
                <th className="py-3.5 px-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {links
                .sort((a, b) => a.display_order - b.display_order)
                .map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-4 px-6 flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center shrink-0">
                        {getPlatformIcon(item.platform)}
                      </div>
                      <div>
                        <span className="font-bold text-slate-900 block">{item.platform_name}</span>
                        <span className="text-[10px] text-slate-400 capitalize">{item.platform}</span>
                      </div>
                    </td>

                    <td className="py-4 px-6">
                      <a
                        href={item.url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-brand-600 hover:underline flex items-center gap-1 font-mono text-[11px] truncate max-w-xs"
                      >
                        <span className="truncate">{item.url}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    </td>

                    <td className="py-4 px-6 font-mono text-slate-600">
                      #{item.display_order}
                    </td>

                    <td className="py-4 px-6">
                      <button
                        type="button"
                        onClick={() => toggleActive(item)}
                        className={`px-2.5 py-1 rounded-full text-[11px] font-bold inline-flex items-center gap-1 transition ${
                          item.is_active
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-500 border border-slate-200'
                        }`}
                      >
                        {item.is_active ? (
                          <>
                            <Eye className="w-3 h-3 text-emerald-600" />
                            <span>Public</span>
                          </>
                        ) : (
                          <>
                            <EyeOff className="w-3 h-3" />
                            <span>Hidden</span>
                          </>
                        )}
                      </button>
                    </td>

                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => openEditModal(item)}
                          className="p-1.5 text-slate-600 hover:text-brand-600 hover:bg-brand-50 rounded-lg transition"
                          title="Edit Link"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(item.id)}
                          className="p-1.5 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                          title="Delete Link"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Create / Edit Link */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-md overflow-hidden my-auto flex flex-col">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h2 className="font-black text-base text-slate-900">
                {editingLink ? 'Edit Social Link' : 'Add Social Platform'}
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Select Platform *
                </label>
                <select
                  value={platform}
                  onChange={(e) => handlePlatformChange(e.target.value)}
                  className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                >
                  <option value="facebook">Facebook</option>
                  <option value="whatsapp">WhatsApp Support</option>
                  <option value="youtube">YouTube</option>
                  <option value="instagram">Instagram</option>
                  <option value="tiktok">TikTok</option>
                  <option value="linkedin">LinkedIn</option>
                  <option value="twitter">Twitter / X</option>
                  <option value="other">Other / Custom Website</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Display Label *
                </label>
                <input
                  type="text"
                  required
                  value={platformName}
                  onChange={(e) => setPlatformName(e.target.value)}
                  placeholder="e.g. Official Facebook Page"
                  className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Full Destination URL *
                </label>
                <input
                  type="url"
                  required
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://facebook.com/..."
                  className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 items-center pt-2">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Display Sequence
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={displayOrder}
                    onChange={(e) => setDisplayOrder(Number(e.target.value))}
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 font-mono"
                  />
                </div>

                <div className="flex items-center gap-2 pt-4">
                  <input
                    type="checkbox"
                    id="isActiveSocial"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="w-4 h-4 text-brand-600 rounded"
                  />
                  <label htmlFor="isActiveSocial" className="text-xs font-bold text-slate-800">
                    Active (Public)
                  </label>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 px-4 py-2.5 rounded-xl border border-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow transition disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : editingLink ? 'Update Link' : 'Add Link'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
