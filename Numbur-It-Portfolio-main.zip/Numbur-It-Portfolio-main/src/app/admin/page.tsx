'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import { FALLBACK_CATEGORIES } from '@/components/public/CategoryGrid';
import {
  Package,
  ShoppingCart,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  DollarSign,
  ArrowRight,
  ShieldCheck,
  Clock,
} from 'lucide-react';

export default function AdminDashboardPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>(INITIAL_PRODUCTS);

  useEffect(() => {
    async function loadDashboardData() {
      try {
        const [ordersRes, prodsRes] = await Promise.all([
          fetch(`/api/admin/orders?t=${Date.now()}`, { cache: 'no-store' }),
          fetch(`/api/admin/products?t=${Date.now()}`, { cache: 'no-store' }),
        ]);

        if (ordersRes.ok) {
          const oData = await ordersRes.json();
          if (oData.orders && oData.orders.length > 0) {
            setOrders(oData.orders);
            localStorage.setItem('numbur_orders', JSON.stringify(oData.orders));
          }
        }

        if (prodsRes.ok) {
          const pData = await prodsRes.json();
          if (pData.products && pData.products.length > 0) {
            setProducts(pData.products);
          }
        }
      } catch (err) {
        console.warn('Dashboard live data fetch warning:', err);
        const stored = JSON.parse(localStorage.getItem('numbur_orders') || '[]');
        setOrders(stored);
      }
    }

    loadDashboardData();
  }, []);

  // Compute live aggregates from database catalog
  const totalProducts = products.length;
  const lowStockThreshold = 4;
  const lowStockCount = products.filter(
    (p) =>
      p.inventory &&
      p.inventory.available_quantity > 0 &&
      p.inventory.available_quantity <= lowStockThreshold
  ).length;

  const outOfStockCount = products.filter(
    (p) => p.inventory && p.inventory.available_quantity === 0
  ).length;

  const pendingOrders = orders.filter((o) => o.order_status === 'pending');
  const confirmedOrders = orders.filter((o) => o.order_status === 'confirmed');

  const totalInventoryUnits = products.reduce(
    (sum, p) => sum + (p.inventory?.available_quantity || 0),
    0
  );

  const totalCatalogValue = products.reduce(
    (sum, p) => sum + (p.cost_price || p.selling_price) * (p.inventory?.available_quantity || 0),
    0
  );

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/90 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-xs font-mono font-bold text-brand-600 bg-brand-50 border border-brand-200 px-2.5 py-0.5 rounded-full uppercase">
            Admin CRM • Manthali-1 Ramechhap
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
            Operations & Inventory Overview
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Real-time aggregate data from local inventory ledger and customer orders.
          </p>
        </div>

        <div className="flex gap-2">
          <Link
            href="/admin/products"
            className="bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold py-2.5 px-4 rounded-xl transition shadow"
          >
            + New Product
          </Link>
          <Link
            href="/admin/inventory"
            className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-2.5 px-4 rounded-xl transition shadow"
          >
            Adjust Stock
          </Link>
        </div>
      </div>

      {/* 4 Primary Metric Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500">Total Products</span>
            <p className="text-2xl font-black text-slate-900 mt-1">{totalProducts}</p>
            <span className="text-[11px] text-brand-600 font-semibold">
              Across {FALLBACK_CATEGORIES.length} categories
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Package className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500">Pending Orders</span>
            <p className="text-2xl font-black text-amber-600 mt-1">
              {pendingOrders.length}
            </p>
            <span className="text-[11px] text-amber-700 font-semibold">
              Awaiting WhatsApp confirmation
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500">Low Stock Alerts</span>
            <p className="text-2xl font-black text-red-600 mt-1">{lowStockCount}</p>
            <span className="text-[11px] text-red-600 font-semibold">
              ≤ {lowStockThreshold} units remaining
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-500">Available Stock Units</span>
            <p className="text-2xl font-black text-emerald-600 mt-1">
              {totalInventoryUnits}
            </p>
            <span className="text-[11px] text-emerald-600 font-semibold">
              Total internal valuation: Rs. {totalCatalogValue.toLocaleString('en-IN')}
            </span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Grid: Recent Orders & Stock Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Recent WhatsApp Orders (7 cols) */}
        <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <h2 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <ShoppingCart className="w-4 h-4 text-brand-600" />
              <span>Recent Order Activity</span>
            </h2>
            <Link
              href="/admin/orders"
              className="text-xs font-semibold text-brand-600 hover:text-brand-800"
            >
              View All Orders →
            </Link>
          </div>

          {orders.length > 0 ? (
            <div className="space-y-3">
              {orders.slice(0, 5).map((ord, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl border border-slate-100 bg-slate-50 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-900">
                        #{ord.order_number}
                      </span>
                      <span className="font-semibold text-slate-700">
                        {ord.customer_name}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Phone: {ord.customer_phone} • {ord.delivery_method}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="font-bold text-slate-900 block">
                      Rs. {ord.total_amount?.toLocaleString('en-IN')}
                    </span>
                    <span className="text-[10px] uppercase font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                      {ord.order_status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-xs text-slate-400">
              No orders recorded yet. As customers check out on WhatsApp, orders will appear here.
            </div>
          )}
        </div>

        {/* Right: Low Stock Warnings (5 cols) */}
        <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <h2 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <span>Low Stock Ledger Alerts</span>
            </h2>
            <Link
              href="/admin/inventory"
              className="text-xs font-semibold text-brand-600 hover:text-brand-800"
            >
              Manage →
            </Link>
          </div>

          <div className="space-y-3">
            {products.map((prod) => {
              const qty = prod.inventory?.available_quantity || 0;
              const isLow = qty <= lowStockThreshold;

              return (
                <div
                  key={prod.id}
                  className="flex items-center justify-between text-xs py-2 border-b border-slate-50 last:border-0"
                >
                  <div className="min-w-0 pr-3">
                    <p className="font-bold text-slate-900 truncate">
                      {prod.name_en}
                    </p>
                    <span className="text-[10px] text-slate-400 font-mono">
                      SKU: {prod.sku}
                    </span>
                  </div>

                  <span
                    className={`shrink-0 font-bold px-2 py-0.5 rounded text-[11px] ${
                      isLow
                        ? 'bg-red-100 text-red-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {qty} in stock
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
