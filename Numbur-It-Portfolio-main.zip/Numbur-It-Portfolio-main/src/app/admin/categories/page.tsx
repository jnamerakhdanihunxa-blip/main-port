'use client';

import React, { useState, useEffect } from 'react';
import SafeImage from '@/components/ui/SafeImage';
import ImageUploader from '@/components/admin/ImageUploader';
import { Category } from '@/types';
import { FALLBACK_CATEGORIES } from '@/components/public/CategoryGrid';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import { createClient, isSupabaseConfigured } from '@/lib/supabase/client';
import {
  Layers,
  Plus,
  Edit,
  Trash2,
  AlertTriangle,
  X,
  CheckCircle2,
  Database,
  Cloud,
} from 'lucide-react';

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState<Category[]>(FALLBACK_CATEGORIES);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [isDbConnected, setIsDbConnected] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load from database via secure server APIs
  useEffect(() => {
    async function loadCategories() {
      try {
        const res = await fetch('/api/admin/categories');
        if (res.ok) {
          const data = await res.json();
          if (data.categories && data.categories.length > 0) {
            setCategories(data.categories as Category[]);
            setIsDbConnected(true);
          }
        }
      } catch (err) {
        console.warn('Categories fetch error:', err);
      }
    }
    loadCategories();
  }, []);

  const [nameEn, setNameEn] = useState('');
  const [nameNe, setNameNe] = useState('');
  const [slug, setSlug] = useState('');
  const [descEn, setDescEn] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [displayOrder, setDisplayOrder] = useState(1);
  const [isActive, setIsActive] = useState(true);
  const [errorMessage, setErrorMessage] = useState('');

  const openCreateModal = () => {
    setEditingCategory(null);
    setNameEn('');
    setNameNe('');
    setSlug('');
    setDescEn('');
    setImageUrl('');
    setDisplayOrder(categories.length + 1);
    setIsActive(true);
    setErrorMessage('');
    setIsModalOpen(true);
  };

  const openEditModal = (cat: Category) => {
    setEditingCategory(cat);
    setNameEn(cat.name_en);
    setNameNe(cat.name_ne || '');
    setSlug(cat.slug);
    setDescEn(cat.description_en || '');
    setImageUrl(cat.image_url || '');
    setDisplayOrder(cat.display_order);
    setIsActive(cat.is_active);
    setErrorMessage('');
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameEn.trim()) return;
    setErrorMessage('');

    const generatedSlug =
      slug.trim() ||
      nameEn.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

    setIsSubmitting(true);

    try {
      const payload = {
        action: editingCategory ? 'update' : 'create',
        id: editingCategory?.id,
        name_en: nameEn.trim(),
        name_ne: nameNe.trim() || null,
        slug: generatedSlug,
        description_en: descEn.trim() || null,
        image_url: imageUrl.trim() || null,
        display_order: Number(displayOrder),
        is_active: isActive,
      };

      const res = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setErrorMessage(data.error || 'Failed to save category');
        setIsSubmitting(false);
        return;
      }

      if (editingCategory) {
        setCategories((prev) =>
          prev.map((c) =>
            c.id === editingCategory.id
              ? {
                  ...c,
                  name_en: nameEn,
                  name_ne: nameNe || null,
                  slug: generatedSlug,
                  description_en: descEn,
                  image_url: imageUrl,
                  display_order: Number(displayOrder),
                  is_active: isActive,
                }
              : c
          )
        );
      } else {
        const createdCat = data.category || {
          id: `c-${Date.now()}`,
          name_en: nameEn,
          name_ne: nameNe || null,
          slug: generatedSlug,
          description_en: descEn,
          image_url: imageUrl,
          display_order: Number(displayOrder),
          is_active: isActive,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        setCategories((prev) => [...prev, createdCat]);
      }

      setIsModalOpen(false);
    } catch (err: any) {
      setErrorMessage(err.message || 'Error occurred while saving category');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (categoryId: string) => {
    if (!confirm('Are you sure you want to delete this category?')) {
      return;
    }

    try {
      const res = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', id: categoryId }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to delete category');
        return;
      }

      setCategories((prev) => prev.filter((c) => c.id !== categoryId));
    } catch (err: any) {
      alert(err.message || 'Error deleting category');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold text-slate-900">
              Category & Classification Management
            </h1>
            {isDbConnected ? (
              <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                <Database className="w-3 h-3 text-emerald-600" /> Supabase Live
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                <Cloud className="w-3 h-3 text-amber-600" /> Local Memory
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Organize catalog categories with relational safety guards and Cloudinary icons.
          </p>
        </div>

        <button
          type="button"
          onClick={openCreateModal}
          className="flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>New Category</span>
        </button>
      </div>

      {/* Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4">Icon / Image</th>
              <th className="py-3 px-4">Category Name</th>
              <th className="py-3 px-4">Slug</th>
              <th className="py-3 px-4">Display Order</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {categories.map((cat) => (
              <tr key={cat.id} className="hover:bg-slate-50/80 transition">
                <td className="py-3 px-4">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 relative overflow-hidden border border-slate-200 flex items-center justify-center">
                    <SafeImage
                      src={cat.image_url}
                      alt={cat.name_en}
                      fill
                      type="category"
                      className="object-contain p-1"
                    />
                  </div>
                </td>
                <td className="py-3 px-4 font-bold text-slate-900">
                  {cat.name_en}
                  {cat.name_ne && (
                    <span className="block text-[11px] text-slate-500 font-normal">
                      {cat.name_ne}
                    </span>
                  )}
                </td>
                <td className="py-3 px-4 font-mono text-slate-500">
                  {cat.slug}
                </td>
                <td className="py-3 px-4 font-mono">{cat.display_order}</td>
                <td className="py-3 px-4">
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      cat.is_active
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {cat.is_active ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => openEditModal(cat)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-brand-600 hover:bg-slate-100"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(cat.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-slate-100"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl my-8">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h2 className="font-bold text-base text-slate-900">
                {editingCategory ? 'Edit Category' : 'New Category'}
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Category Name (English) *
                </label>
                <input
                  type="text"
                  required
                  value={nameEn}
                  onChange={(e) => setNameEn(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Category Name (Nepali)
                </label>
                <input
                  type="text"
                  value={nameNe}
                  onChange={(e) => setNameNe(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Slug
                </label>
                <input
                  type="text"
                  value={slug}
                  onChange={(e) => setSlug(e.target.value)}
                  placeholder="auto-generated if empty"
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white font-mono"
                />
              </div>

              {/* Direct Cloudinary Image Uploader */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                <ImageUploader
                  label="Category Icon / Thumbnail"
                  folder="numbur-it/categories"
                  value={imageUrl}
                  onChange={setImageUrl}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Display Order
                  </label>
                  <input
                    type="number"
                    value={displayOrder}
                    onChange={(e) => setDisplayOrder(Number(e.target.value))}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                    <input
                      type="checkbox"
                      checked={isActive}
                      onChange={(e) => setIsActive(e.target.checked)}
                      className="rounded text-brand-600"
                    />
                    <span>Active Status</span>
                  </label>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-100 text-slate-700 font-bold px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-brand-600 text-white font-bold px-5 py-2 rounded-xl shadow"
                >
                  Save Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
