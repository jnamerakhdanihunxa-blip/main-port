'use client';

import React, { useState, useEffect } from 'react';
import { Users, Phone, MapPin, Mail, ShoppingBag } from 'lucide-react';

export default function AdminCustomersPage() {
  const [customers, setCustomers] = useState<any[]>([]);

  useEffect(() => {
    async function loadCustomers() {
      let orders: any[] = [];
      try {
        const res = await fetch('/api/admin/orders', { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data.orders && data.orders.length > 0) {
            orders = data.orders;
          }
        }
      } catch (e) {
        console.warn('Customer directory order fetch warning:', e);
      }

      if (orders.length === 0) {
        orders = JSON.parse(localStorage.getItem('numbur_orders') || '[]');
      }

      const customerMap = new Map<string, any>();

      // Seed default customer from legacy
      customerMap.set('9854040821', {
        name: 'Niraz Sapkota',
        phone: '9854040821',
        address: 'Khimti-7, Ramechhap',
        ordersCount: 1,
      });

      orders.forEach((o) => {
        if (o.customer_phone) {
          const existing = customerMap.get(o.customer_phone);
          if (existing) {
            existing.ordersCount += 1;
          } else {
            customerMap.set(o.customer_phone, {
              name: o.customer_name,
              phone: o.customer_phone,
              address: `${o.delivery_address}, ${o.municipality_area || ''}`,
              ordersCount: 1,
            });
          }
        }
      });

      setCustomers(Array.from(customerMap.values()));
    }

    loadCustomers();
  }, []);

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <h1 className="text-2xl font-extrabold text-slate-900">
          Customer Directory & CRM
        </h1>
        <p className="text-xs text-slate-500 mt-1">
          Registered customer contact records for order fulfillment and verified support.
        </p>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4">Customer Name</th>
              <th className="py-3 px-4">Phone Number</th>
              <th className="py-3 px-4">Verified Delivery Area</th>
              <th className="py-3 px-4">Total Orders</th>
              <th className="py-3 px-4 text-right">Quick Contact</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {customers.map((c, idx) => (
              <tr key={idx} className="hover:bg-slate-50/80 transition">
                <td className="py-3 px-4 font-bold text-slate-900">{c.name}</td>
                <td className="py-3 px-4 font-mono text-brand-600">
                  <a href={`tel:${c.phone}`} className="hover:underline">
                    {c.phone}
                  </a>
                </td>
                <td className="py-3 px-4 text-slate-600">{c.address}</td>
                <td className="py-3 px-4 font-bold text-slate-800">
                  {c.ordersCount} order(s)
                </td>
                <td className="py-3 px-4 text-right">
                  <a
                    href={`https://wa.me/977${c.phone.replace(/[^0-9]/g, '')}`}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-block bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 font-bold px-3 py-1 rounded text-[11px]"
                  >
                    WhatsApp
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
