'use client';

import React, { useState, useEffect } from 'react';
import { Product, InventoryMovement, InventoryMovementType } from '@/types';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import {
  Archive,
  Plus,
  Minus,
  AlertTriangle,
  History,
  CheckCircle2,
  X,
  FileText,
} from 'lucide-react';

const INITIAL_MOVEMENTS: InventoryMovement[] = [
  {
    id: 'm1',
    product_id: 'd1000000-0000-0000-0000-000000000001',
    quantity_change: 15,
    movement_type: 'purchase',
    reason: 'Initial batch purchase from official distributor',
    staff_id: 'a1000000-0000-0000-0000-000000000001',
    created_at: new Date(Date.now() - 86400000 * 5).toISOString(),
    product: {
      name_en: 'EZVIZ H8c 2MP Smart WiFi Pan/Tilt Outdoor Camera',
      sku: 'CAM-EZ-H8C-2MP',
    },
    staff: { full_name: 'Mr. Niraz Sapkota' },
  },
  {
    id: 'm2',
    product_id: 'd1000000-0000-0000-0000-000000000001',
    quantity_change: -3,
    movement_type: 'sale',
    reason: 'Order fulfillment (Manthali School CCTV project)',
    staff_id: 'a1000000-0000-0000-0000-000000000003',
    created_at: new Date(Date.now() - 86400000 * 2).toISOString(),
    product: {
      name_en: 'EZVIZ H8c 2MP Smart WiFi Pan/Tilt Outdoor Camera',
      sku: 'CAM-EZ-H8C-2MP',
    },
    staff: { full_name: 'Mr. Rohit Prasad Adhikari' },
  },
  {
    id: 'm3',
    product_id: 'd1000000-0000-0000-0000-000000000002',
    quantity_change: 8,
    movement_type: 'purchase',
    reason: 'Stock purchase Dell laptops',
    staff_id: 'a1000000-0000-0000-0000-000000000001',
    created_at: new Date(Date.now() - 86400000 * 10).toISOString(),
    product: {
      name_en: 'Dell Vostro 3501 15.6" FHD Core i5 11th Gen',
      sku: 'LAP-DEL-V3501-I5',
    },
    staff: { full_name: 'Mr. Niraz Sapkota' },
  },
];

export default function AdminInventoryPage() {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [movements, setMovements] = useState<InventoryMovement[]>(INITIAL_MOVEMENTS);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load live stock and movements from Supabase
  useEffect(() => {
    async function loadInventory() {
      try {
        const res = await fetch('/api/admin/inventory');
        if (res.ok) {
          const data = await res.json();
          if (data.products && data.products.length > 0) {
            setProducts(
              data.products.map((p: any) => ({
                ...p,
                inventory: p.inventory
                  ? {
                      available_quantity: p.inventory.available_quantity,
                      in_stock: p.inventory.available_quantity > 0,
                    }
                  : { available_quantity: 0, in_stock: false },
              }))
            );
          }
          if (data.movements && data.movements.length > 0) {
            setMovements(data.movements);
          }
        }
      } catch (err) {
        console.warn('Failed to load inventory data:', err);
      }
    }
    loadInventory();
  }, []);

  // Form states
  const [quantityChange, setQuantityChange] = useState<number>(1);
  const [movementType, setMovementType] =
    useState<InventoryMovementType>('purchase');
  const [reason, setReason] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const openAdjustModal = (prod: Product) => {
    setSelectedProduct(prod);
    setQuantityChange(1);
    setMovementType('purchase');
    setReason('');
    setErrorMsg('');
    setIsModalOpen(true);
  };

  const handleRecordMovement = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!selectedProduct) return;
    if (!reason.trim()) {
      setErrorMsg('A valid explanation/reason is required for every ledger movement.');
      return;
    }

    const currentQty = selectedProduct.inventory?.available_quantity || 0;
    const delta =
      movementType === 'purchase' || movementType === 'return'
        ? Math.abs(quantityChange)
        : -Math.abs(quantityChange);

    // PREVENT NEGATIVE STOCK RULE
    if (currentQty + delta < 0) {
      setErrorMsg(
        `Atomic Rule Violation: Cannot deduct ${Math.abs(
          quantityChange
        )} units. Available stock is only ${currentQty}. Negative stock is strictly disallowed.`
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await fetch('/api/admin/inventory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: selectedProduct.id,
          quantityChange: Math.abs(quantityChange),
          movementType,
          reason: reason.trim(),
          staffName: 'Admin',
        }),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        setErrorMsg(data.error || 'Failed to record movement in database.');
        setIsSubmitting(false);
        return;
      }

      const newQty = data.newQuantity !== undefined ? data.newQuantity : currentQty + delta;

      // 1. Update product stock in local state
      setProducts((prev) =>
        prev.map((p) =>
          p.id === selectedProduct.id
            ? {
                ...p,
                inventory: {
                  available_quantity: newQty,
                  in_stock: newQty > 0,
                },
              }
            : p
        )
      );

      // 2. Append to immutable movements ledger
      if (data.movement) {
        setMovements((prev) => [data.movement, ...prev]);
      }

      setIsModalOpen(false);
    } catch (err: any) {
      setErrorMsg(err.message || 'Network error occurred while updating inventory.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-xs font-mono font-bold text-red-600 bg-red-50 border border-red-200 px-2.5 py-0.5 rounded-full uppercase">
            Privileged Admin / Staff Ledger
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 mt-2">
            Inventory & Stock Movement Ledger
          </h1>
          <p className="text-xs text-slate-500 mt-1">
            Atomic tracking of purchased, sold, and damaged quantities with responsible staff audit logging.
          </p>
        </div>
      </div>

      {/* Current Stock Levels Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex justify-between items-center">
          <h2 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <Archive className="w-4 h-4 text-brand-600" />
            <span>Product Inventory Levels</span>
          </h2>
        </div>

        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4">Product Name & SKU</th>
              <th className="py-3 px-4">Available Quantity</th>
              <th className="py-3 px-4">Public Status</th>
              <th className="py-3 px-4 text-right">Stock Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {products.map((prod) => {
              const qty = prod.inventory?.available_quantity || 0;
              const isLow = qty <= 3;

              return (
                <tr key={prod.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-4">
                    <p className="font-bold text-slate-900">{prod.name_en}</p>
                    <span className="font-mono text-[10px] text-slate-400">
                      SKU: {prod.sku}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`font-black text-sm ${
                        isLow ? 'text-red-600' : 'text-emerald-700'
                      }`}
                    >
                      {qty} units
                    </span>
                    {isLow && (
                      <span className="ml-2 bg-red-100 text-red-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                        Low Stock Warning
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                        qty > 0
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-red-50 text-red-700 border border-red-200'
                      }`}
                    >
                      {qty > 0 ? 'Public: In Stock' : 'Public: Out of Stock'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      type="button"
                      onClick={() => openAdjustModal(prod)}
                      className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-[11px] py-1.5 px-3 rounded-lg shadow-sm transition"
                    >
                      Record Movement
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Immutable Stock Movements History */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex justify-between items-center">
          <h2 className="font-bold text-sm text-slate-900 flex items-center gap-2">
            <History className="w-4 h-4 text-brand-600" />
            <span>Audit History: Stock Movement Ledger</span>
          </h2>
          <span className="text-[11px] text-slate-400">
            Immutable Historical Log
          </span>
        </div>

        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4">Timestamp</th>
              <th className="py-3 px-4">Product</th>
              <th className="py-3 px-4">Type</th>
              <th className="py-3 px-4">Quantity Change</th>
              <th className="py-3 px-4">Reason / Notes</th>
              <th className="py-3 px-4">Responsible User</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {movements.map((m) => (
              <tr key={m.id} className="hover:bg-slate-50/80 transition">
                <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                  {new Date(m.created_at).toLocaleString()}
                </td>
                <td className="py-3 px-4 font-bold text-slate-900">
                  {m.product?.name_en}
                </td>
                <td className="py-3 px-4">
                  <span className="uppercase text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                    {m.movement_type}
                  </span>
                </td>
                <td className="py-3 px-4 font-mono font-bold">
                  <span
                    className={
                      m.quantity_change > 0 ? 'text-emerald-600' : 'text-red-600'
                    }
                  >
                    {m.quantity_change > 0
                      ? `+${m.quantity_change}`
                      : m.quantity_change}
                  </span>
                </td>
                <td className="py-3 px-4 text-slate-600 max-w-xs">{m.reason}</td>
                <td className="py-3 px-4 text-slate-700 font-semibold">
                  {m.staff?.full_name || 'Admin'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Movement Recording Modal */}
      {isModalOpen && selectedProduct && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h2 className="font-bold text-base text-slate-900">
                Record Stock Adjustment
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-xs">
              <span className="font-bold text-slate-900 block">
                {selectedProduct.name_en}
              </span>
              <span className="text-[11px] text-slate-500 font-mono">
                SKU: {selectedProduct.sku} • Current Stock:{' '}
                {selectedProduct.inventory?.available_quantity || 0} units
              </span>
            </div>

            {errorMsg && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleRecordMovement} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Movement Type *
                </label>
                <select
                  value={movementType}
                  onChange={(e) =>
                    setMovementType(e.target.value as InventoryMovementType)
                  }
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 font-semibold focus:bg-white"
                >
                  <option value="purchase">Purchase (New Stock In +)</option>
                  <option value="sale">Manual Sale / Dispatch (Stock Out -)</option>
                  <option value="damaged">Damaged / Defective (Stock Out -)</option>
                  <option value="adjustment">Inventory Reconciliation Adjustment</option>
                  <option value="return">Customer Return (Stock In +)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Quantity Units *
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={quantityChange}
                  onChange={(e) => setQuantityChange(Math.max(1, Number(e.target.value)))}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white font-bold"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Reason / Reference Note *
                </label>
                <textarea
                  rows={3}
                  required
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="e.g. Received shipment from Dell Nepal distributor, Invoice #9842"
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-100 text-slate-700 font-bold px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-brand-600 disabled:opacity-50 text-white font-bold px-5 py-2 rounded-xl shadow"
                >
                  {isSubmitting ? 'Recording Ledger...' : 'Record into Ledger'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
