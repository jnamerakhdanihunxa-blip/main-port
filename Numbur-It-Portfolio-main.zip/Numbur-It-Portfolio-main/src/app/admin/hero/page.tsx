'use client';

import React, { useState, useEffect } from 'react';
import SafeImage from '@/components/ui/SafeImage';
import ImageUploader from '@/components/admin/ImageUploader';
import { FALLBACK_BANNERS } from '@/components/public/HeroSection';
import { SiteBanner } from '@/types';
import {
  Sparkles,
  Plus,
  Edit,
  Trash2,
  CheckCircle2,
  X,
  Eye,
  EyeOff,
  ArrowRight,
  Database,
  ExternalLink,
} from 'lucide-react';

export default function AdminHeroPage() {
  const [banners, setBanners] = useState<SiteBanner[]>(FALLBACK_BANNERS);
  const [loading, setLoading] = useState(true);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<SiteBanner | null>(null);

  // Form Fields
  const [titleEn, setTitleEn] = useState('');
  const [titleNe, setTitleNe] = useState('');
  const [subtitleEn, setSubtitleEn] = useState('');
  const [subtitleNe, setSubtitleNe] = useState('');
  const [ctaTextEn, setCtaTextEn] = useState('Explore Catalog');
  const [ctaTextNe, setCtaTextNe] = useState('सामानहरू हेर्नुहोस्');
  const [ctaLink, setCtaLink] = useState('/products');
  const [imageUrl, setImageUrl] = useState('');
  const [displayOrder, setDisplayOrder] = useState(1);
  const [isActive, setIsActive] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch Banners from API
  const loadBanners = async () => {
    try {
      const res = await fetch('/api/admin/content', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.banners && data.banners.length > 0) {
          setBanners(data.banners);
        }
      }
    } catch (err) {
      console.warn('Failed to load banners:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBanners();
  }, []);

  const openCreateModal = () => {
    setEditingBanner(null);
    setTitleEn('');
    setTitleNe('');
    setSubtitleEn('');
    setSubtitleNe('');
    setCtaTextEn('Explore Catalog');
    setCtaTextNe('सामानहरू हेर्नुहोस्');
    setCtaLink('/products');
    setImageUrl('');
    setDisplayOrder(banners.length + 1);
    setIsActive(true);
    setIsModalOpen(true);
  };

  const openEditModal = (banner: SiteBanner) => {
    setEditingBanner(banner);
    setTitleEn(banner.title_en || '');
    setTitleNe(banner.title_ne || '');
    setSubtitleEn(banner.subtitle_en || '');
    setSubtitleNe(banner.subtitle_ne || '');
    setCtaTextEn(banner.cta_text_en || 'Explore Catalog');
    setCtaTextNe(banner.cta_text_ne || 'सामानहरू हेर्नुहोस्');
    setCtaLink(banner.cta_link || '/products');
    setImageUrl(banner.image_url || '');
    setDisplayOrder(banner.display_order || 1);
    setIsActive(banner.is_active);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!titleEn.trim()) {
      alert('English Title is required.');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        action: editingBanner ? 'update' : 'create',
        type: 'banner',
        id: editingBanner?.id,
        title_en: titleEn.trim(),
        title_ne: titleNe.trim() || null,
        subtitle_en: subtitleEn.trim() || null,
        subtitle_ne: subtitleNe.trim() || null,
        cta_text_en: ctaTextEn.trim() || null,
        cta_text_ne: ctaTextNe.trim() || null,
        cta_link: ctaLink.trim() || '/products',
        image_url: imageUrl.trim() || null,
        display_order: Number(displayOrder),
        is_active: isActive,
      };

      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to save hero banner.');
        return;
      }

      await loadBanners();
      setIsModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Error saving hero banner.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to permanently delete this hero banner?')) {
      return;
    }

    try {
      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', type: 'banner', id }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to delete banner.');
        return;
      }

      setBanners((prev) => prev.filter((b) => b.id !== id));
    } catch (err: any) {
      alert(err.message || 'Error deleting banner.');
    }
  };

  const toggleActive = async (banner: SiteBanner) => {
    try {
      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update',
          type: 'banner',
          id: banner.id,
          is_active: !banner.is_active,
        }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to update status.');
        return;
      }

      setBanners((prev) =>
        prev.map((b) => (b.id === banner.id ? { ...b, is_active: !b.is_active } : b))
      );
    } catch (err: any) {
      alert(err.message || 'Error updating status.');
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Bar */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
              Homepage Hero & Banner Slider
            </h1>
            <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
              <Database className="w-3 h-3 text-emerald-600" /> Supabase Live
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
            Upload custom high-definition hero images to Cloudinary, configure titles, call-to-actions, and set the sliding sequence for the public website homepage.
          </p>
        </div>

        <button
          type="button"
          onClick={openCreateModal}
          className="flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-3 px-5 rounded-xl shadow-md transition shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Hero Banner</span>
        </button>
      </div>

      {/* Banners List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {banners
          .sort((a, b) => a.display_order - b.display_order)
          .map((banner) => (
            <div
              key={banner.id}
              className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col justify-between group hover:shadow-md transition"
            >
              {/* Image Preview Banner */}
              <div className="relative w-full h-52 bg-slate-950 overflow-hidden">
                {banner.image_url ? (
                  <SafeImage
                    src={banner.image_url}
                    alt={banner.title_en}
                    fill
                    type="banner"
                    className="object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-r from-slate-900 to-blue-950 text-white/50 p-4 text-center">
                    <Sparkles className="w-8 h-8 mb-1 opacity-50" />
                    <span className="text-xs font-mono">No Image Uploaded (Default Grid)</span>
                  </div>
                )}

                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent pointer-events-none" />

                {/* Status Badges */}
                <div className="absolute top-3 left-3 flex items-center gap-2">
                  <span className="bg-slate-900/90 text-white text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-lg border border-white/10">
                    Order #{banner.display_order}
                  </span>
                </div>

                <div className="absolute top-3 right-3 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => toggleActive(banner)}
                    className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 shadow backdrop-blur-sm transition ${
                      banner.is_active
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {banner.is_active ? (
                      <>
                        <Eye className="w-3.5 h-3.5" />
                        <span>Active</span>
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-3.5 h-3.5" />
                        <span>Hidden</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="absolute bottom-3 left-4 right-4 text-white">
                  <h3 className="font-black text-lg line-clamp-1">
                    {banner.title_en}
                  </h3>
                  {banner.subtitle_en && (
                    <p className="text-xs text-slate-300 line-clamp-1 mt-0.5">
                      {banner.subtitle_en}
                    </p>
                  )}
                </div>
              </div>

              {/* Details & Controls */}
              <div className="p-5 flex items-center justify-between border-t border-slate-100 bg-slate-50/50">
                <div className="text-xs text-slate-600 space-y-1">
                  <p>
                    <strong className="text-slate-800">CTA Button:</strong> {banner.cta_text_en || 'Explore'} &rarr;{' '}
                    <span className="font-mono text-slate-500">{banner.cta_link || '/products'}</span>
                  </p>
                  {banner.title_ne && (
                    <p className="text-slate-500">
                      <strong>नेपाली:</strong> {banner.title_ne}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => openEditModal(banner)}
                    className="p-2 bg-slate-100 hover:bg-brand-50 text-slate-600 hover:text-brand-600 rounded-xl transition"
                    title="Edit Banner"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(banner.id)}
                    className="p-2 bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-600 rounded-xl transition"
                    title="Delete Banner"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
      </div>

      {/* Modal: Create / Edit Banner */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <h2 className="font-black text-lg text-slate-900">
                {editingBanner ? 'Edit Hero Banner' : 'Create New Hero Banner'}
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-6 overflow-y-auto space-y-5 flex-1">
              {/* Image Uploader */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">
                  Hero Background Image (Cloudinary)
                </label>
                <ImageUploader
                  value={imageUrl}
                  onChange={(url) => setImageUrl(url)}
                  folder="numbur-it/banners"
                  label="Upload Hero Photo"
                  aspectRatio="video"
                />
              </div>

              {/* Title Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Headline (English) *
                  </label>
                  <input
                    type="text"
                    required
                    value={titleEn}
                    onChange={(e) => setTitleEn(e.target.value)}
                    placeholder="e.g. The Ultimate iT Solution is Numbur iT"
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Headline (नेपाली)
                  </label>
                  <input
                    type="text"
                    value={titleNe}
                    onChange={(e) => setTitleNe(e.target.value)}
                    placeholder="e.g. अल्टिमेट आइटी सोलुसन"
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
              </div>

              {/* Subtitle Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Subtitle (English)
                  </label>
                  <textarea
                    rows={2}
                    value={subtitleEn}
                    onChange={(e) => setSubtitleEn(e.target.value)}
                    placeholder="Brief description of hardware or service offering"
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Subtitle (नेपाली)
                  </label>
                  <textarea
                    rows={2}
                    value={subtitleNe}
                    onChange={(e) => setSubtitleNe(e.target.value)}
                    placeholder="नेपाली भाषामा छोटो विवरण"
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
              </div>

              {/* CTA Button & Link */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Button Label (EN)
                  </label>
                  <input
                    type="text"
                    value={ctaTextEn}
                    onChange={(e) => setCtaTextEn(e.target.value)}
                    placeholder="Explore Catalog"
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Button Label (NE)
                  </label>
                  <input
                    type="text"
                    value={ctaTextNe}
                    onChange={(e) => setCtaTextNe(e.target.value)}
                    placeholder="सामानहरू हेर्नुहोस्"
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Destination Link
                  </label>
                  <input
                    type="text"
                    value={ctaLink}
                    onChange={(e) => setCtaLink(e.target.value)}
                    placeholder="/products or /categories/..."
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 font-mono"
                  />
                </div>
              </div>

              {/* Order & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center pt-2 border-t border-slate-100">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Slide Display Order
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={displayOrder}
                    onChange={(e) => setDisplayOrder(Number(e.target.value))}
                    className="w-full text-xs rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500 font-mono"
                  />
                </div>

                <div className="flex items-center gap-2 pt-4">
                  <input
                    type="checkbox"
                    id="isActiveBanner"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="w-4 h-4 text-brand-600 rounded"
                  />
                  <label htmlFor="isActiveBanner" className="text-xs font-bold text-slate-800">
                    Active (Show on public homepage)
                  </label>
                </div>
              </div>

              {/* Live Preview Box */}
              <div className="mt-4 pt-4 border-t border-slate-100">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                  Live Banner Preview
                </span>
                <div className="relative w-full h-44 rounded-2xl overflow-hidden bg-slate-950 p-5 flex flex-col justify-end text-white border border-slate-800">
                  {imageUrl && (
                    <SafeImage
                      src={imageUrl}
                      alt="Preview"
                      fill
                      type="banner"
                      className="object-cover"
                    />
                  )}
                  <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-transparent pointer-events-none" />
                  <div className="relative z-10">
                    <h4 className="font-black text-lg line-clamp-1">{titleEn || 'Banner Title'}</h4>
                    <p className="text-xs text-slate-300 line-clamp-1 mt-0.5">{subtitleEn || 'Banner subtitle text preview'}</p>
                    <span className="inline-block mt-2 bg-brand-600 text-white text-[10px] font-bold px-3 py-1 rounded-lg">
                      {ctaTextEn || 'Button'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="text-xs font-semibold text-slate-500 hover:text-slate-800 px-4 py-2.5 rounded-xl border border-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs px-6 py-2.5 rounded-xl shadow transition disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving Banner...' : editingBanner ? 'Update Banner' : 'Create Banner'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
