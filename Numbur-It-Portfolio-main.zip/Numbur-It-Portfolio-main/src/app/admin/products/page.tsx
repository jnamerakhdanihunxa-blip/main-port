'use client';

import React, { useState, useEffect } from 'react';
import SafeImage from '@/components/ui/SafeImage';
import ImageUploader from '@/components/admin/ImageUploader';
import { Product, Category } from '@/types';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import { FALLBACK_CATEGORIES } from '@/components/public/CategoryGrid';
import { createClient, isSupabaseConfigured } from '@/lib/supabase/client';
import {
  Package,
  Plus,
  Edit,
  Trash2,
  Check,
  AlertCircle,
  X,
  Upload,
  Search,
  Database,
  Cloud,
  CheckCircle2,
} from 'lucide-react';

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<Category[]>(FALLBACK_CATEGORIES);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDbConnected, setIsDbConnected] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load from database via secure server APIs
  useEffect(() => {
    async function loadData() {
      try {
        const [prodRes, catRes] = await Promise.all([
          fetch(`/api/admin/products?t=${Date.now()}`),
          fetch(`/api/admin/categories?t=${Date.now()}`),
        ]);

        if (prodRes.ok) {
          const prodData = await prodRes.json();
          if (prodData.products && prodData.products.length > 0) {
            setProducts(prodData.products as Product[]);
            setIsDbConnected(true);
          }
        }
        if (catRes.ok) {
          const catData = await catRes.json();
          if (catData.categories && catData.categories.length > 0) {
            setCategories(catData.categories as Category[]);
          }
        }
      } catch (err) {
        console.warn('Admin products fetch warning:', err);
      }
    }
    loadData();
  }, []);

  // Form states
  const [nameEn, setNameEn] = useState('');
  const [nameNe, setNameNe] = useState('');
  const [sku, setSku] = useState('');
  const [slug, setSlug] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [brandName, setBrandName] = useState('');
  const [sellingPrice, setSellingPrice] = useState<number>(0);
  const [costPrice, setCostPrice] = useState<number | undefined>(undefined);
  const [discountPrice, setDiscountPrice] = useState<number | undefined>(undefined);
  const [stockQuantity, setStockQuantity] = useState<number>(10);
  const [primaryImageUrl, setPrimaryImageUrl] = useState('');
  const [shortDescEn, setShortDescEn] = useState('');
  const [fullDescEn, setFullDescEn] = useState('');
  const [warrantyInfoEn, setWarrantyInfoEn] = useState('');
  const [isFeatured, setIsFeatured] = useState(false);
  const [isBestseller, setIsBestseller] = useState(false);
  const [isNewArrival, setIsNewArrival] = useState(false);
  const [isActive, setIsActive] = useState(true);

  // Dynamic specifications key-values
  const [specs, setSpecs] = useState<Array<{ key: string; value: string }>>([
    { key: 'Processor', value: '' },
    { key: 'RAM', value: '' },
  ]);

  const [formError, setFormError] = useState('');

  const openCreateModal = () => {
    setEditingProduct(null);
    setNameEn('');
    setNameNe('');
    setSku(`SKU-${Math.floor(1000 + Math.random() * 9000)}`);
    setSlug('');
    setCategoryId('');
    setBrandName('');
    setSellingPrice(0);
    setCostPrice(undefined);
    setDiscountPrice(undefined);
    setStockQuantity(10);
    setPrimaryImageUrl('');
    setShortDescEn('');
    setFullDescEn('');
    setWarrantyInfoEn('');
    setIsFeatured(false);
    setIsBestseller(false);
    setIsNewArrival(true);
    setIsActive(true);
    setSpecs([
      { key: 'Resolution', value: '' },
      { key: 'Storage', value: '' },
    ]);
    setFormError('');
    setIsModalOpen(true);
  };

  const openEditModal = (p: Product) => {
    setEditingProduct(p);
    setNameEn(p.name_en);
    setNameNe(p.name_ne || '');
    setSku(p.sku);
    setSlug(p.slug);
    setCategoryId(p.category_id);
    setBrandName(p.brand?.name || '');
    setSellingPrice(p.selling_price);
    setCostPrice(p.cost_price || undefined);
    setDiscountPrice(p.discount_price || undefined);
    setStockQuantity(p.inventory?.available_quantity ?? 10);
    setPrimaryImageUrl(p.primary_image_url);
    setShortDescEn(p.short_desc_en || '');
    setFullDescEn(p.full_desc_en || '');
    setWarrantyInfoEn(p.warranty_info_en || '');
    setIsFeatured(p.is_featured);
    setIsBestseller(p.is_bestseller);
    setIsNewArrival(p.is_new_arrival);
    setIsActive(p.is_active);

    const specEntries = Object.entries(p.specifications || {}).map(
      ([key, value]) => ({ key, value })
    );
    setSpecs(specEntries.length > 0 ? specEntries : [{ key: '', value: '' }]);
    setFormError('');
    setIsModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    // STRICT VALIDATION: Product creation MUST be blocked until a valid category is selected
    if (!categoryId || categoryId.trim() === '') {
      setFormError('CRITICAL: A valid category must be selected before saving.');
      return;
    }

    if (!nameEn.trim()) {
      setFormError('Product name is required.');
      return;
    }

    if (sellingPrice < 0) {
      setFormError('Selling price must be 0 or greater.');
      return;
    }

    // Convert specs array to Record<string, string>
    const specificationsRecord: Record<string, string> = {};
    specs.forEach((s) => {
      if (s.key.trim() && s.value.trim()) {
        specificationsRecord[s.key.trim()] = s.value.trim();
      }
    });

    const categoryObj = categories.find((c) => c.id === categoryId);

    const generatedSlug =
      slug.trim() ||
      nameEn.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

    setIsSubmitting(true);

    try {
      const payload = {
        action: editingProduct ? 'update' : 'create',
        id: editingProduct?.id,
        name_en: nameEn.trim(),
        name_ne: nameNe.trim() || null,
        sku: sku.trim(),
        slug: generatedSlug,
        category_id: categoryId,
        selling_price: Number(sellingPrice),
        cost_price: costPrice !== undefined && costPrice !== null ? Number(costPrice) : null,
        discount_price: discountPrice !== undefined && discountPrice !== null ? Number(discountPrice) : null,
        primary_image_url: primaryImageUrl.trim() || null,
        short_desc_en: shortDescEn.trim() || null,
        full_desc_en: fullDescEn.trim() || null,
        warranty_info_en: warrantyInfoEn.trim() || null,
        specifications: specificationsRecord,
        is_featured: isFeatured,
        is_bestseller: isBestseller,
        is_new_arrival: isNewArrival,
        is_active: isActive,
        initial_stock: Number(stockQuantity) >= 0 ? Number(stockQuantity) : 10,
        available_quantity: Number(stockQuantity) >= 0 ? Number(stockQuantity) : 10,
      };

      const res = await fetch('/api/admin/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const resData = await res.json();

      if (!res.ok || resData.error) {
        setFormError(resData.error || 'Failed to save product in database.');
        setIsSubmitting(false);
        return;
      }

      const savedProduct: Product = {
        ...(resData.product || {}),
        category: categoryObj || resData.product?.category,
        brand: brandName
          ? {
              id: 'b-custom',
              name: brandName,
              slug: brandName.toLowerCase(),
              is_active: true,
              created_at: '',
              updated_at: '',
            }
          : resData.product?.brand,
        inventory: {
          available_quantity: Number(stockQuantity),
          in_stock: Number(stockQuantity) > 0,
        },
      };

      if (editingProduct) {
        setProducts((prev) =>
          prev.map((p) => (p.id === editingProduct.id ? { ...p, ...savedProduct } : p))
        );
      } else {
        setProducts((prev) => [savedProduct, ...prev]);
      }

      setIsModalOpen(false);
    } catch (err: any) {
      setFormError(err.message || 'Network error occurred while saving product.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    if (!confirm('Are you sure you want to delete this product? This will also remove associated inventory.')) {
      return;
    }

    try {
      const res = await fetch('/api/admin/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', id: productId }),
      });

      const resData = await res.json();
      if (!res.ok || resData.error) {
        alert(resData.error || 'Failed to delete product.');
        return;
      }

      setProducts((prev) => prev.filter((p) => p.id !== productId));
    } catch (err: any) {
      alert(err.message || 'Error deleting product.');
    }
  };

  const filtered = products.filter((p) => {
    if (!searchQuery.trim()) return true;
    const rawQuery = searchQuery.toLowerCase().trim();
    const tokens = rawQuery.split(/\s+/).filter(Boolean);

    const normalize = (str: string) => str.toLowerCase().replace(/[-_/\\.,]/g, ' ');
    const stripPunct = (str: string) => str.toLowerCase().replace(/[-_/\\.,\s]/g, '');

    const specsText = Object.entries(p.specifications || {})
      .map(([k, v]) => `${k} ${v}`)
      .join(' ');

    const combinedHaystack = [
      p.name_en || '',
      p.name_ne || '',
      p.sku || '',
      p.slug || '',
      p.brand?.name || '',
      p.category?.name_en || '',
      p.category?.name_ne || '',
      p.category?.slug || '',
      p.short_desc_en || '',
      p.full_desc_en || '',
      specsText,
    ].join(' ');

    const lower = combinedHaystack.toLowerCase();
    const normalized = normalize(combinedHaystack);
    const stripped = stripPunct(combinedHaystack);

    return tokens.every((token) => {
      const tokenNorm = normalize(token);
      const tokenStrip = stripPunct(token);
      return (
        lower.includes(token) ||
        normalized.includes(tokenNorm) ||
        stripped.includes(tokenStrip)
      );
    });
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold text-slate-900">
              Product Catalog Management
            </h1>
            {isDbConnected ? (
              <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                <Database className="w-3 h-3 text-emerald-600" /> Supabase Live
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                <Cloud className="w-3 h-3 text-amber-600" /> Local Memory
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Create, edit, and organize dynamic hardware catalog items with Cloudinary media.
          </p>
        </div>

        <button
          type="button"
          onClick={openCreateModal}
          className="flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Product</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-3">
        <Search className="w-4 h-4 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search products by name or SKU..."
          className="w-full text-xs bg-transparent focus:outline-none"
        />
      </div>

      {/* Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Image</th>
                <th className="py-3 px-4">Name & SKU</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Selling Price</th>
                <th className="py-3 px-4">Cost Price (Admin)</th>
                <th className="py-3 px-4">Stock</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((prod) => (
                <tr key={prod.id} className="hover:bg-slate-50/80 transition">
                  <td className="py-3 px-4">
                    <div className="w-12 h-12 rounded-lg bg-slate-100 relative overflow-hidden border border-slate-200">
                      <SafeImage
                        src={prod.primary_image_url}
                        alt={prod.name_en}
                        fill
                        type="product"
                        className="object-contain p-1"
                      />
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <p className="font-bold text-slate-900">{prod.name_en}</p>
                    <span className="font-mono text-[10px] text-slate-400">
                      SKU: {prod.sku}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px]">
                      {prod.category?.name_en || 'Assigned'}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-bold text-slate-900">
                    Rs. {prod.selling_price.toLocaleString('en-IN')}
                    {prod.discount_price && (
                      <span className="block text-[10px] text-emerald-600">
                        Sale: Rs. {prod.discount_price.toLocaleString('en-IN')}
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-500">
                    {prod.cost_price
                      ? `Rs. ${prod.cost_price.toLocaleString('en-IN')}`
                      : '—'}
                  </td>
                  <td className="py-3 px-4">
                    <span className="font-bold text-emerald-600">
                      {prod.inventory?.available_quantity || 0} units
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        prod.is_active
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {prod.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => openEditModal(prod)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-brand-600 hover:bg-slate-100"
                        aria-label="Edit product"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDeleteProduct(prod.id)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-slate-100"
                        aria-label="Delete product"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-5 my-8 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h2 className="font-bold text-lg text-slate-900">
                {editingProduct ? 'Edit Product' : 'Add New Product'}
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSaveProduct} className="space-y-4 text-xs">
              {/* Category (MANDATORY REQUIREMENT) */}
              <div className="bg-brand-50/50 p-4 rounded-2xl border border-brand-200 space-y-1">
                <label className="block font-bold text-slate-900">
                  Select Category (Required) *
                </label>
                <select
                  required
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full text-xs rounded-xl border border-brand-300 p-2.5 bg-white font-semibold focus:ring-2 focus:ring-brand-500"
                >
                  <option value="">-- Choose Category --</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name_en}
                    </option>
                  ))}
                </select>
                <span className="text-[10px] text-slate-500 block">
                  Product creation is blocked unless an existing category is selected.
                </span>
              </div>

              {/* Basic Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Product Name (English) *
                  </label>
                  <input
                    type="text"
                    required
                    value={nameEn}
                    onChange={(e) => setNameEn(e.target.value)}
                    placeholder="e.g. Dell Vostro 3501 Core i5"
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Product Name (Nepali)
                  </label>
                  <input
                    type="text"
                    value={nameNe}
                    onChange={(e) => setNameNe(e.target.value)}
                    placeholder="e.g. डेल भोस्ट्रो ल्यापटप"
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    SKU / Product Code *
                  </label>
                  <input
                    type="text"
                    required
                    value={sku}
                    onChange={(e) => setSku(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Brand Name
                  </label>
                  <input
                    type="text"
                    value={brandName}
                    onChange={(e) => setBrandName(e.target.value)}
                    placeholder="e.g. Dell, EZVIZ"
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
              </div>

              {/* Direct Cloudinary Image Uploader */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl">
                <ImageUploader
                  label="Primary Product Photo"
                  folder="numbur-it/products"
                  value={primaryImageUrl}
                  onChange={setPrimaryImageUrl}
                />
              </div>

              {/* Pricing & Stock */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Selling Price (Rs.) *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={sellingPrice}
                    onChange={(e) => setSellingPrice(Number(e.target.value))}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Cost Price (Admin Only)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={costPrice ?? ''}
                    onChange={(e) =>
                      setCostPrice(e.target.value ? Number(e.target.value) : undefined)
                    }
                    placeholder="Purchase cost"
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Discount Price (Optional)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={discountPrice ?? ''}
                    onChange={(e) =>
                      setDiscountPrice(
                        e.target.value ? Number(e.target.value) : undefined
                      )
                    }
                    placeholder="Sale price"
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Available Stock *
                  </label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={stockQuantity}
                    onChange={(e) => setStockQuantity(Number(e.target.value))}
                    className="w-full rounded-xl border border-brand-300 p-2.5 bg-brand-50/40 focus:bg-white font-bold"
                  />
                </div>
              </div>

              {/* Warranty (Optional) */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Warranty Information (Optional - leaves no empty placeholder if omitted)
                </label>
                <input
                  type="text"
                  value={warrantyInfoEn}
                  onChange={(e) => setWarrantyInfoEn(e.target.value)}
                  placeholder="e.g. 1 Year Brand Replacement Warranty"
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              {/* Dynamic Specifications */}
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="block font-bold text-slate-700">
                    Dynamic Specifications (Flexible Key-Value)
                  </label>
                  <button
                    type="button"
                    onClick={() => setSpecs([...specs, { key: '', value: '' }])}
                    className="text-[11px] font-bold text-brand-600 hover:underline"
                  >
                    + Add Attribute
                  </button>
                </div>
                <div className="space-y-2">
                  {specs.map((item, idx) => (
                    <div key={idx} className="flex gap-2">
                      <input
                        type="text"
                        placeholder="Feature (e.g. Storage)"
                        value={item.key}
                        onChange={(e) => {
                          const updated = [...specs];
                          updated[idx].key = e.target.value;
                          setSpecs(updated);
                        }}
                        className="w-1/2 rounded-xl border border-slate-200 p-2 bg-slate-50 focus:bg-white text-xs"
                      />
                      <input
                        type="text"
                        placeholder="Value (e.g. 512GB SSD)"
                        value={item.value}
                        onChange={(e) => {
                          const updated = [...specs];
                          updated[idx].value = e.target.value;
                          setSpecs(updated);
                        }}
                        className="w-1/2 rounded-xl border border-slate-200 p-2 bg-slate-50 focus:bg-white text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => setSpecs(specs.filter((_, i) => i !== idx))}
                        className="p-2 text-slate-400 hover:text-red-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Descriptions */}
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Short Description
                </label>
                <input
                  type="text"
                  value={shortDescEn}
                  onChange={(e) => setShortDescEn(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Full Description
                </label>
                <textarea
                  rows={3}
                  value={fullDescEn}
                  onChange={(e) => setFullDescEn(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              {/* Flags */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-slate-100">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isFeatured}
                    onChange={(e) => setIsFeatured(e.target.checked)}
                    className="rounded text-brand-600"
                  />
                  <span>Featured</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isBestseller}
                    onChange={(e) => setIsBestseller(e.target.checked)}
                    className="rounded text-brand-600"
                  />
                  <span>Best Seller</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isNewArrival}
                    onChange={(e) => setIsNewArrival(e.target.checked)}
                    className="rounded text-brand-600"
                  />
                  <span>New Arrival</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="rounded text-brand-600"
                  />
                  <span>Active</span>
                </label>
              </div>

              <div className="pt-4 border-t border-slate-100 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-100 text-slate-700 font-bold px-4 py-2.5 rounded-xl hover:bg-slate-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-brand-600 hover:bg-brand-700 disabled:opacity-50 text-white font-bold px-6 py-2.5 rounded-xl transition shadow flex items-center gap-2"
                >
                  {isSubmitting ? 'Saving to Database...' : 'Save Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
