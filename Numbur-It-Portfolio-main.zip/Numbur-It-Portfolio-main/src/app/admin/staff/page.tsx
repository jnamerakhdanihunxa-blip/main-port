'use client';

import React, { useState, useEffect } from 'react';
import SafeImage from '@/components/ui/SafeImage';
import ImageUploader from '@/components/admin/ImageUploader';
import { StaffProfile } from '@/types';
import { AUDITED_STAFF_FALLBACK } from '@/components/public/TeamSection';
import { createClient, isSupabaseConfigured } from '@/lib/supabase/client';
import {
  UserCheck,
  Plus,
  Edit,
  Trash2,
  Eye,
  EyeOff,
  Phone,
  Mail,
  MapPin,
  X,
  Database,
  Cloud,
} from 'lucide-react';

export default function AdminStaffPage() {
  const [staffList, setStaffList] = useState<StaffProfile[]>(AUDITED_STAFF_FALLBACK);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStaff, setEditingStaff] = useState<StaffProfile | null>(null);
  const [isDbConnected, setIsDbConnected] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load from database via secure server APIs
  useEffect(() => {
    async function loadStaff() {
      try {
        const res = await fetch('/api/admin/staff');
        if (res.ok) {
          const data = await res.json();
          if (data.staff && data.staff.length > 0) {
            setStaffList(data.staff as StaffProfile[]);
            setIsDbConnected(true);
          }
        }
      } catch (err) {
        console.warn('Staff fetch warning:', err);
      }
    }
    loadStaff();
  }, []);

  // Form states
  const [name, setName] = useState('');
  const [designation, setDesignation] = useState('');
  const [department, setDepartment] = useState('');
  const [bioEn, setBioEn] = useState('');
  const [bioNe, setBioNe] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [publicPhone, setPublicPhone] = useState('');
  const [publicEmail, setPublicEmail] = useState('');
  const [publicAddress, setPublicAddress] = useState('');
  const [displayOrder, setDisplayOrder] = useState(1);
  const [isPublic, setIsPublic] = useState(true);

  const openCreateModal = () => {
    setEditingStaff(null);
    setName('');
    setDesignation('');
    setDepartment('Management');
    setBioEn('');
    setBioNe('');
    setPhotoUrl('');
    setPublicPhone('');
    setPublicEmail('');
    setPublicAddress('');
    setDisplayOrder(staffList.length + 1);
    setIsPublic(true);
    setIsModalOpen(true);
  };

  const openEditModal = (staff: StaffProfile) => {
    setEditingStaff(staff);
    setName(staff.name);
    setDesignation(staff.designation);
    setDepartment(staff.department || '');
    setBioEn(staff.bio_en || '');
    setBioNe(staff.bio_ne || '');
    setPhotoUrl(staff.photo_url || '');
    setPublicPhone(staff.public_contact_phone || '');
    setPublicEmail(staff.public_contact_email || '');
    setPublicAddress(staff.public_address || '');
    setDisplayOrder(staff.display_order);
    setIsPublic(staff.is_public);
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !designation.trim()) return;

    setIsSubmitting(true);

    try {
      const payload = {
        action: editingStaff ? 'update' : 'create',
        id: editingStaff?.id,
        name: name.trim(),
        designation: designation.trim(),
        department: department.trim() || 'Management',
        bio_en: bioEn.trim() || null,
        bio_ne: bioNe.trim() || null,
        photo_url: photoUrl.trim() || null,
        public_contact_phone: publicPhone.trim() || null,
        public_contact_email: publicEmail.trim() || null,
        public_address: publicAddress.trim() || null,
        display_order: Number(displayOrder),
        is_public: isPublic,
      };

      const res = await fetch('/api/admin/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to save staff profile');
        setIsSubmitting(false);
        return;
      }

      if (editingStaff) {
        setStaffList((prev) =>
          prev.map((s) =>
            s.id === editingStaff.id
              ? {
                  ...s,
                  name,
                  designation,
                  department,
                  bio_en: bioEn,
                  bio_ne: bioNe,
                  photo_url: photoUrl,
                  public_contact_phone: publicPhone || null,
                  public_contact_email: publicEmail || null,
                  public_address: publicAddress || null,
                  display_order: Number(displayOrder),
                  is_public: isPublic,
                  updated_at: new Date().toISOString(),
                }
              : s
          )
        );
      } else {
        const createdStaff = data.staff || {
          id: `s-${Date.now()}`,
          name,
          designation,
          department,
          bio_en: bioEn,
          bio_ne: bioNe,
          photo_url: photoUrl,
          public_contact_phone: publicPhone || null,
          public_contact_email: publicEmail || null,
          public_address: publicAddress || null,
          display_order: Number(displayOrder),
          is_public: isPublic,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        setStaffList((prev) => [...prev, createdStaff]);
      }

      setIsModalOpen(false);
    } catch (err: any) {
      alert(err.message || 'Error occurred while saving staff profile');
    } finally {
      setIsSubmitting(false);
    }
  };

  const togglePublicStatus = async (staffId: string) => {
    const target = staffList.find((s) => s.id === staffId);
    if (!target) return;
    const nextStatus = !target.is_public;

    setStaffList((prev) =>
      prev.map((s) => (s.id === staffId ? { ...s, is_public: nextStatus } : s))
    );

    try {
      await fetch('/api/admin/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update', id: staffId, is_public: nextStatus }),
      });
    } catch (err) {
      console.warn('Failed to update public status:', err);
    }
  };

  const handleDeleteStaff = async (staffId: string) => {
    if (!confirm('Are you sure you want to remove this staff profile?')) {
      return;
    }

    try {
      const res = await fetch('/api/admin/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', id: staffId }),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        alert(data.error || 'Failed to delete staff profile');
        return;
      }

      setStaffList((prev) => prev.filter((s) => s.id !== staffId));
    } catch (err: any) {
      alert(err.message || 'Error deleting staff profile');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-extrabold text-slate-900">
              Staff Directory & Public Team Management
            </h1>
            {isDbConnected ? (
              <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                <Database className="w-3 h-3 text-emerald-600" /> Supabase Live
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200 text-[10px] font-bold px-2 py-0.5 rounded-full">
                <Cloud className="w-3 h-3 text-amber-600" /> Local Memory
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Manage employee biographies, public visibility flags, and designations with Cloudinary portraits.
          </p>
        </div>

        <button
          type="button"
          onClick={openCreateModal}
          className="flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-2.5 px-4 rounded-xl shadow transition"
        >
          <Plus className="w-4 h-4" />
          <span>Add Staff Member</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {staffList.map((member) => {
          const initials = member.name
            .replace(/^(Mr\.|Mrs\.|Ms\.)\s*/i, '')
            .split(' ')
            .map((n) => n[0])
            .filter(Boolean)
            .slice(0, 2)
            .join('');

          return (
            <div
              key={member.id}
              className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col justify-between"
            >
              <div>
                <div className="relative w-full h-48 bg-slate-100">
                  <SafeImage
                    src={member.photo_url}
                    alt={member.name}
                    fill
                    type="avatar"
                    fallbackText={initials}
                    className="object-cover object-top"
                  />
                  <button
                    type="button"
                    onClick={() => togglePublicStatus(member.id)}
                    className={`absolute top-2 right-2 px-2.5 py-1 rounded-full text-[10px] font-bold flex items-center gap-1 shadow backdrop-blur-sm ${
                      member.is_public
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {member.is_public ? (
                      <>
                        <Eye className="w-3 h-3" />
                        <span>Public</span>
                      </>
                    ) : (
                      <>
                        <EyeOff className="w-3 h-3" />
                        <span>Hidden</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="p-4 space-y-2">
                  <h3 className="font-bold text-base text-slate-900">
                    {member.name}
                  </h3>
                  <p className="text-xs font-semibold text-brand-600">
                    {member.designation}
                  </p>
                  <span className="inline-block text-[10px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                    Order: #{member.display_order} • {member.department}
                  </span>

                  <div className="pt-2 text-[11px] text-slate-500 space-y-1">
                    {member.public_contact_phone && (
                      <p className="truncate">📞 {member.public_contact_phone}</p>
                    )}
                    {member.public_address && (
                      <p className="truncate">📍 {member.public_address}</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="p-4 pt-0 flex gap-2">
                <button
                  type="button"
                  onClick={() => openEditModal(member)}
                  className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-2 rounded-xl transition flex items-center justify-center gap-1.5"
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span>Edit</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDeleteStaff(member.id)}
                  className="p-2 bg-slate-100 hover:bg-red-50 text-slate-400 hover:text-red-600 rounded-xl transition"
                  title="Delete Member"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Staff Edit / Create Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl my-8">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h2 className="font-bold text-base text-slate-900">
                {editingStaff ? 'Edit Staff Profile' : 'Add Staff Member'}
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Designation *
                  </label>
                  <input
                    type="text"
                    required
                    value={designation}
                    onChange={(e) => setDesignation(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Department
                  </label>
                  <input
                    type="text"
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
              </div>

              {/* Direct Cloudinary Image Uploader */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl">
                <ImageUploader
                  label="Profile Photo (Cloudinary)"
                  folder="numbur-it/staff"
                  aspectRatio="portrait"
                  value={photoUrl}
                  onChange={setPhotoUrl}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Public Mobile Phone
                  </label>
                  <input
                    type="tel"
                    value={publicPhone}
                    onChange={(e) => setPublicPhone(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Public Address
                  </label>
                  <input
                    type="text"
                    value={publicAddress}
                    onChange={(e) => setPublicAddress(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Short Bio (English)
                </label>
                <textarea
                  rows={2}
                  value={bioEn}
                  onChange={(e) => setBioEn(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Display Order
                  </label>
                  <input
                    type="number"
                    value={displayOrder}
                    onChange={(e) => setDisplayOrder(Number(e.target.value))}
                    className="w-full rounded-xl border border-slate-200 p-2.5 bg-slate-50 focus:bg-white"
                  />
                </div>
                <div className="flex items-center pt-5">
                  <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                    <input
                      type="checkbox"
                      checked={isPublic}
                      onChange={(e) => setIsPublic(e.target.checked)}
                      className="rounded text-brand-600"
                    />
                    <span>Show on Website</span>
                  </label>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-100 text-slate-700 font-bold px-4 py-2 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-brand-600 text-white font-bold px-5 py-2 rounded-xl shadow"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
