import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { FALLBACK_CATEGORIES } from '@/components/public/CategoryGrid';
import { AUDITED_SERVICES_FALLBACK } from '@/components/public/ServicesSection';
import { AUDITED_STAFF_FALLBACK } from '@/components/public/TeamSection';
import { FALLBACK_BANNERS } from '@/components/public/HeroSection';
import { INITIAL_PRODUCTS } from '@/lib/products-data';

const AUDITED_BRANDS = [
  { id: 'b1000000-0000-0000-0000-000000000001', name: 'Dell', slug: 'dell', logo_url: null, is_active: true },
  { id: 'b1000000-0000-0000-0000-000000000002', name: 'HP', slug: 'hp', logo_url: null, is_active: true },
  { id: 'b1000000-0000-0000-0000-000000000003', name: 'EZVIZ', slug: 'ezviz', logo_url: null, is_active: true },
  { id: 'b1000000-0000-0000-0000-000000000004', name: 'Hikvision', slug: 'hikvision', logo_url: null, is_active: true },
  { id: 'b1000000-0000-0000-0000-000000000005', name: 'Dahua', slug: 'dahua', logo_url: null, is_active: true },
  { id: 'b1000000-0000-0000-0000-000000000006', name: 'Canon', slug: 'canon', logo_url: null, is_active: true },
  { id: 'b1000000-0000-0000-0000-000000000007', name: 'Epson', slug: 'epson', logo_url: null, is_active: true },
  { id: 'b1000000-0000-0000-0000-000000000008', name: 'TP-Link', slug: 'tp-link', logo_url: null, is_active: true },
];

export async function POST(req: NextRequest) {
  try {
    const supabase = createAdminClient();

    // Check basic connection
    const { error: testError } = await supabase.from('categories').select('count', { count: 'exact', head: true });
    if (testError && testError.code === '42P01') {
      return NextResponse.json(
        {
          error:
            'Supabase tables do not exist yet! Please open your Supabase SQL Editor and execute the schema file found at: supabase/migrations/01_schema.sql',
          needsMigration: true,
        },
        { status: 400 }
      );
    }

    const counts = {
      categories: 0,
      brands: 0,
      services: 0,
      staff: 0,
      banners: 0,
      products: 0,
      inventory: 0,
    };

    // 1. Seed Categories
    for (const cat of FALLBACK_CATEGORIES) {
      const { error } = await supabase.from('categories').upsert(
        {
          id: cat.id,
          name_en: cat.name_en,
          name_ne: cat.name_ne,
          slug: cat.slug,
          description_en: cat.description_en,
          image_url: cat.image_url || null,
          display_order: cat.display_order,
          is_active: cat.is_active,
        },
        { onConflict: 'id' }
      );
      if (!error) counts.categories++;
    }

    // 2. Seed Brands
    for (const brand of AUDITED_BRANDS) {
      const { error } = await supabase.from('brands').upsert(
        {
          id: brand.id,
          name: brand.name,
          slug: brand.slug,
          logo_url: brand.logo_url,
          is_active: brand.is_active,
        },
        { onConflict: 'id' }
      );
      if (!error) counts.brands++;
    }

    // 3. Seed Services
    for (const svc of AUDITED_SERVICES_FALLBACK) {
      const { error } = await supabase.from('services').upsert(
        {
          id: svc.id,
          slug: svc.slug,
          title_en: svc.title_en,
          title_ne: svc.title_ne,
          short_desc_en: svc.short_desc_en,
          icon_name: svc.icon_name,
          display_order: svc.display_order,
          is_active: svc.is_active,
        },
        { onConflict: 'id' }
      );
      if (!error) counts.services++;
    }

    // 4. Seed Staff (staff_profiles table)
    for (const member of AUDITED_STAFF_FALLBACK) {
      const { error } = await supabase.from('staff_profiles').upsert(
        {
          id: member.id,
          name: member.name,
          designation: member.designation,
          department: member.department,
          bio_en: member.bio_en,
          bio_ne: member.bio_ne,
          photo_url: member.photo_url || null,
          public_contact_phone: member.public_contact_phone,
          public_contact_email: member.public_contact_email,
          public_address: member.public_address,
          display_order: member.display_order,
          is_public: member.is_public,
        },
        { onConflict: 'id' }
      );
      if (!error) counts.staff++;
    }

    // 5. Seed Banners (site_banners table)
    for (const bnr of FALLBACK_BANNERS) {
      const { error } = await supabase.from('site_banners').upsert(
        {
          id: bnr.id,
          title_en: bnr.title_en,
          title_ne: bnr.title_ne,
          subtitle_en: bnr.subtitle_en,
          subtitle_ne: bnr.subtitle_ne,
          cta_text_en: bnr.cta_text_en,
          cta_link: bnr.cta_link,
          image_url: bnr.image_url || null,
          banner_type: bnr.banner_type,
          display_order: bnr.display_order,
          is_active: bnr.is_active,
        },
        { onConflict: 'id' }
      );
      if (!error) counts.banners++;
    }

    // 6. Seed Initial Products
    for (const prod of INITIAL_PRODUCTS) {
      const { error } = await supabase.from('products').upsert(
        {
          id: prod.id,
          name_en: prod.name_en,
          name_ne: prod.name_ne,
          slug: prod.slug,
          sku: prod.sku,
          category_id: prod.category_id,
          brand_id: prod.brand_id || null,
          selling_price: prod.selling_price,
          cost_price: prod.cost_price,
          discount_price: prod.discount_price,
          primary_image_url: prod.primary_image_url || null,
          short_desc_en: prod.short_desc_en,
          full_desc_en: prod.full_desc_en,
          warranty_info_en: prod.warranty_info_en,
          specifications: prod.specifications,
          is_featured: prod.is_featured,
          is_bestseller: prod.is_bestseller,
          is_new_arrival: prod.is_new_arrival,
          is_active: prod.is_active,
        },
        { onConflict: 'id' }
      );
      if (!error) {
        counts.products++;

        // 7. Seed corresponding inventory
        if (prod.inventory) {
          const { error: invErr } = await supabase.from('inventory').upsert(
            {
              product_id: prod.id,
              total_purchased: (prod.inventory.available_quantity || 0) + 5,
              available_quantity: prod.inventory.available_quantity || 0,
              sold_quantity: 5,
              damaged_quantity: 0,
              low_stock_threshold: 3,
            },
            { onConflict: 'product_id' }
          );
          if (!invErr) counts.inventory++;
        }
      }
    }

    return NextResponse.json({
      success: true,
      message: 'Supabase database initialized with official business records.',
      counts,
    });
  } catch (err: any) {
    console.error('Supabase seeding error:', err);
    return NextResponse.json(
      {
        error: err.message || 'Failed to seed Supabase database',
      },
      { status: 500 }
    );
  }
}
