import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { FALLBACK_BANNERS } from '@/components/public/HeroSection';
import { AUDITED_SERVICES_FALLBACK } from '@/components/public/ServicesSection';
import { AUDITED_STAFF_FALLBACK } from '@/components/public/TeamSection';
import { INITIAL_GALLERY } from '@/lib/gallery-data';

export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

export async function GET() {
  try {
    const supabase = createAdminClient();

    const [bannersRes, servicesRes, staffRes, galleryRes] = await Promise.all([
      supabase
        .from('site_banners')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true }),
      supabase
        .from('services')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true }),
      supabase
        .from('staff_profiles')
        .select('*')
        .eq('is_public', true)
        .order('display_order', { ascending: true }),
      supabase
        .from('gallery_items')
        .select('*')
        .eq('is_active', true)
        .order('display_order', { ascending: true }),
    ]);

    const banners =
      !bannersRes.error && bannersRes.data && bannersRes.data.length > 0
        ? bannersRes.data
        : FALLBACK_BANNERS;

    const services =
      !servicesRes.error && servicesRes.data && servicesRes.data.length > 0
        ? servicesRes.data
        : AUDITED_SERVICES_FALLBACK;

    const staff =
      !staffRes.error && staffRes.data && staffRes.data.length > 0
        ? staffRes.data
        : AUDITED_STAFF_FALLBACK;

    const gallery =
      !galleryRes.error && galleryRes.data && galleryRes.data.length > 0
        ? galleryRes.data.map((g: any) => ({
            id: g.id,
            title: g.title_en,
            title_ne: g.title_ne,
            category: g.category || 'Store',
            url: g.image_url,
          }))
        : INITIAL_GALLERY;

    return NextResponse.json(
      {
        banners,
        services,
        staff,
        gallery,
      },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  } catch (err: any) {
    console.warn('API /api/content error, returning fallbacks:', err);
    return NextResponse.json(
      {
        banners: FALLBACK_BANNERS,
        services: AUDITED_SERVICES_FALLBACK,
        staff: AUDITED_STAFF_FALLBACK,
        gallery: INITIAL_GALLERY,
      },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  }
}
