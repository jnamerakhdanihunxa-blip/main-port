import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { INITIAL_PRODUCTS } from '@/lib/products-data';

// Force dynamic so new products and stock changes appear immediately
export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const slug = searchParams.get('slug');
    const q = searchParams.get('q');

    const supabase = createAdminClient();

    let query = supabase
      .from('products')
      .select(`
        *,
        category:categories!left(*),
        brand:brands!left(*),
        inventory:inventory!left(*)
      `)
      .eq('is_active', true)
      .order('created_at', { ascending: false });

    if (slug) {
      query = query.eq('slug', slug);
    }

    const { data, error } = await query;

    const noCacheHeaders = {
      'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0, s-maxage=0',
      'Pragma': 'no-cache',
      'Expires': '0',
    };

    const filterByQuery = (prods: any[], queryStr: string) => {
      const rawQuery = queryStr.toLowerCase().trim();
      const tokens = rawQuery.split(/\s+/).filter(Boolean);
      const normalize = (s: string) => s.toLowerCase().replace(/[-_/\\.,]/g, ' ');
      const stripPunct = (s: string) => s.toLowerCase().replace(/[-_/\\.,\s]/g, '');

      return prods.filter((p) => {
        const specsText = Object.entries(p.specifications || {})
          .map(([k, v]) => `${k} ${v}`)
          .join(' ');
        const haystack = [
          p.name_en || '',
          p.name_ne || '',
          p.sku || '',
          p.brand?.name || '',
          p.category?.name_en || '',
          p.category?.name_ne || '',
          p.category?.slug || '',
          p.short_desc_en || '',
          p.full_desc_en || '',
          specsText,
        ].join(' ');

        const lower = haystack.toLowerCase();
        const normalized = normalize(haystack);
        const stripped = stripPunct(haystack);

        return tokens.every((t) => {
          const tNorm = normalize(t);
          const tStrip = stripPunct(t);
          return (
            lower.includes(t) ||
            normalized.includes(tNorm) ||
            stripped.includes(tStrip)
          );
        });
      });
    };

    if (!error && data && data.length > 0) {
      // Map inventory properly (handle object or array join)
      const formatted = data.map((p: any) => {
        const inv = Array.isArray(p.inventory) ? p.inventory[0] : p.inventory;
        const fallbackImg = INITIAL_PRODUCTS.find((init) => init.slug === p.slug)?.primary_image_url || '';
        return {
          ...p,
          primary_image_url: p.primary_image_url || fallbackImg,
          inventory: inv
            ? {
                available_quantity: inv.available_quantity,
                in_stock: inv.available_quantity > 0,
              }
            : { available_quantity: 10, in_stock: true },
        };
      });

      if (slug) {
        return NextResponse.json({ product: formatted[0] }, { headers: noCacheHeaders });
      }

      // Merge Supabase products with INITIAL_PRODUCTS so all catalog items remain visible
      const dbSlugs = new Set(formatted.map((p: any) => p.slug));
      let combined = [
        ...formatted,
        ...INITIAL_PRODUCTS.filter((p) => !dbSlugs.has(p.slug)),
      ];

      if (q && q.trim()) {
        combined = filterByQuery(combined, q);
      }

      return NextResponse.json({ products: combined }, { headers: noCacheHeaders });
    }

    // Fallback if Supabase table is empty or error
    if (slug) {
      const fallback = INITIAL_PRODUCTS.find((p) => p.slug === slug);
      return NextResponse.json({ product: fallback || null }, { headers: noCacheHeaders });
    }

    let fallbackProducts = INITIAL_PRODUCTS;
    if (q && q.trim()) {
      fallbackProducts = filterByQuery(fallbackProducts, q);
    }

    return NextResponse.json({ products: fallbackProducts }, { headers: noCacheHeaders });
  } catch (err: any) {
    console.warn('API /api/products error, falling back to mock:', err);
    return NextResponse.json(
      { products: INITIAL_PRODUCTS },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0, s-maxage=0',
          'Pragma': 'no-cache',
          'Expires': '0',
        },
      }
    );
  }
}
