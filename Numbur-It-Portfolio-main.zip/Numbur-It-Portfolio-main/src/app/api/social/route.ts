import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { FALLBACK_SOCIAL_LINKS } from '@/lib/site-defaults';

export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

export async function GET() {
  try {
    const supabase = createAdminClient();
    const { data, error } = await supabase
      .from('social_links')
      .select('*')
      .eq('is_active', true)
      .order('display_order', { ascending: true });

    if (!error && data && data.length > 0) {
      return NextResponse.json(
        { links: data },
        {
          headers: {
            'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
          },
        }
      );
    }

    return NextResponse.json(
      { links: FALLBACK_SOCIAL_LINKS },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  } catch (err: any) {
    console.warn('API /api/social error, returning fallbacks:', err);
    return NextResponse.json(
      { links: FALLBACK_SOCIAL_LINKS },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  }
}
