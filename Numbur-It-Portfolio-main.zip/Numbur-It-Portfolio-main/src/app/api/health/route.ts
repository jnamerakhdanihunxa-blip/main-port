import { NextResponse } from 'next/server';

export async function GET() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
  const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

  const cloudName = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME || '';
  const cloudApiKey = process.env.CLOUDINARY_API_KEY || process.env.NEXT_PUBLIC_CLOUDINARY_API_KEY || '';
  const cloudSecret = process.env.CLOUDINARY_API_SECRET || '';

  const supabaseConfigured =
    supabaseUrl.startsWith('https://') &&
    !supabaseUrl.includes('your-project-id') &&
    !supabaseUrl.includes('placeholder') &&
    supabaseAnon.length > 20;

  const cloudinaryConfigured =
    cloudName.length > 2 &&
    !cloudName.includes('your_cloud_name') &&
    cloudApiKey.length > 5 &&
    cloudSecret.length > 5;

  return NextResponse.json({
    supabase: {
      configured: supabaseConfigured,
      hasUrl: Boolean(supabaseUrl),
      hasAnonKey: Boolean(supabaseAnon),
      hasServiceKey: Boolean(supabaseServiceKey),
    },
    cloudinary: {
      configured: cloudinaryConfigured,
      hasCloudName: Boolean(cloudName),
      hasApiKey: Boolean(cloudApiKey),
      hasApiSecret: Boolean(cloudSecret),
    },
  });
}
