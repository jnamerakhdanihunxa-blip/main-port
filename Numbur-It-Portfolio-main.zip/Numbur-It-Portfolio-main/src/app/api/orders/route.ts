import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { buildWhatsAppOrderUrl, WhatsAppOrderData } from '@/lib/whatsapp';
import { INITIAL_PRODUCTS } from '@/lib/products-data';

export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      customer_name,
      customer_phone,
      customer_email,
      delivery_address,
      municipality_area,
      delivery_method = 'ramechhap_delivery',
      customer_notes,
      items,
    } = body;

    // 1. Validate required customer details
    if (!customer_name?.trim()) {
      return NextResponse.json({ error: 'Customer full name is required' }, { status: 400 });
    }
    if (!customer_phone?.trim()) {
      return NextResponse.json({ error: 'Phone number is required' }, { status: 400 });
    }
    if (!delivery_address?.trim()) {
      return NextResponse.json({ error: 'Delivery address is required' }, { status: 400 });
    }
    if (!items || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json({ error: 'Cart must contain at least one item' }, { status: 400 });
    }

    const supabase = createAdminClient();

    // 2. Fetch business WhatsApp number from site_settings or fallback
    let businessWhatsApp = process.env.NEXT_PUBLIC_DEFAULT_WHATSAPP_NUMBER || '9779854040821';
    try {
      const { data: settingRow } = await supabase
        .from('site_settings')
        .select('value')
        .eq('key', 'business_whatsapp_number')
        .maybeSingle();

      if (settingRow?.value) {
        businessWhatsApp = settingRow.value;
      }
    } catch (e) {
      console.warn('Could not fetch business whatsapp number from db, using default');
    }

    // 3. Server-side validate product prices and inventory
    const productIds = items.map((i: any) => i.productId || i.id).filter(Boolean);
    const { data: dbProducts } = await supabase
      .from('products')
      .select('id, name_en, sku, selling_price, discount_price')
      .in('id', productIds);

    const verifiedItems: Array<{
      productId: string;
      name: string;
      sku: string;
      quantity: number;
      unitPrice: number;
      total: number;
    }> = [];

    let calculatedSubtotal = 0;

    for (const item of items) {
      const pId = item.productId || item.id;
      const qty = Math.max(1, Number(item.quantity || 1));

      // Find in DB or fallback array
      const product =
        dbProducts?.find((p: any) => p.id === pId) ||
        INITIAL_PRODUCTS.find((p) => p.id === pId || p.slug === item.slug);

      if (product) {
        const unitPrice =
          product.discount_price && product.discount_price < product.selling_price
            ? Number(product.discount_price)
            : Number(product.selling_price);

        const total = unitPrice * qty;
        calculatedSubtotal += total;

        verifiedItems.push({
          productId: product.id,
          name: product.name_en,
          sku: product.sku || `SKU-${product.id.slice(0, 8)}`,
          quantity: qty,
          unitPrice,
          total,
        });
      }
    }

    if (verifiedItems.length === 0) {
      return NextResponse.json({ error: 'No valid products found in order' }, { status: 400 });
    }

    // 4. Generate unique human-readable Order Number
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `NIS-2026-${randomSuffix}`;

    // 5. Insert pending order record into Supabase (if table accessible)
    try {
      const { data: orderRow, error: orderErr } = await supabase
        .from('orders')
        .insert({
          order_number: orderNumber,
          customer_name: customer_name.trim(),
          customer_phone: customer_phone.trim(),
          customer_email: customer_email?.trim() || null,
          delivery_address: delivery_address.trim(),
          municipality_area: municipality_area?.trim() || 'Manthali Municipality',
          delivery_method: delivery_method === 'store_pickup' ? 'store_pickup' : 'ramechhap_delivery',
          delivery_instructions: customer_notes?.trim() || null,
          customer_notes: customer_notes?.trim() || null,
          subtotal_amount: calculatedSubtotal,
          total_amount: calculatedSubtotal,
          remaining_balance: calculatedSubtotal,
          order_status: 'pending',
          payment_status: 'unpaid',
        })
        .select('id')
        .maybeSingle();

      if (!orderErr && orderRow?.id) {
        // Insert order items
        const itemRows = verifiedItems.map((item) => ({
          order_id: orderRow.id,
          product_id: item.productId,
          product_name_snapshot: item.name,
          sku_snapshot: item.sku,
          unit_price_snapshot: item.unitPrice,
          quantity: item.quantity,
          total_price: item.total,
        }));

        await supabase.from('order_items').insert(itemRows);
      } else if (orderErr) {
        console.warn('Orders table insert warning (guest order without profile FK):', orderErr.message);
      }
    } catch (dbErr: any) {
      console.warn('Could not persist pending order row to database:', dbErr.message);
    }

    // 6. Generate formatted WhatsApp order payload and URL
    const whatsappPayload: WhatsAppOrderData = {
      orderNumber,
      customerName: customer_name.trim(),
      customerPhone: customer_phone.trim(),
      deliveryMethod: delivery_method,
      deliveryAddress: delivery_address.trim(),
      municipalityArea: municipality_area?.trim() || 'Manthali Municipality',
      items: verifiedItems.map((i) => ({
        name: i.name,
        sku: i.sku,
        quantity: i.quantity,
        price: i.unitPrice,
        total: i.total,
      })),
      subtotal: calculatedSubtotal,
      specialInstructions: customer_notes?.trim() || undefined,
    };

    const waUrl = buildWhatsAppOrderUrl(businessWhatsApp, whatsappPayload);

    return NextResponse.json({
      success: true,
      orderNumber,
      totalAmount: calculatedSubtotal,
      verifiedItems,
      waUrl,
      whatsappNumber: businessWhatsApp,
      message: 'Order created as pending. Continue to WhatsApp to confirm with representative.',
    });
  } catch (err: any) {
    console.error('API /api/orders error:', err);
    return NextResponse.json({ error: err.message || 'Internal server error' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const orderNumber = searchParams.get('orderNumber');

    if (!orderNumber) {
      return NextResponse.json({ error: 'Order number is required' }, { status: 400 });
    }

    const supabase = createAdminClient();
    const { data: order, error } = await supabase
      .from('orders')
      .select(`
        id,
        order_number,
        customer_name,
        customer_phone,
        customer_email,
        delivery_address,
        municipality_area,
        delivery_method,
        delivery_instructions,
        customer_notes,
        subtotal_amount,
        total_amount,
        advance_payment_amount,
        remaining_balance,
        order_status,
        payment_status,
        created_at,
        updated_at,
        order_items (*)
      `)
      .eq('order_number', orderNumber.trim())
      .maybeSingle();

    if (error || !order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }

    // Format items
    const formatted = {
      ...order,
      items: (order.order_items || []).map((i: any) => ({
        name: i.product_name_snapshot,
        sku: i.sku_snapshot,
        quantity: i.quantity,
        price: i.unit_price_snapshot,
        total: i.total_price,
      })),
    };

    return NextResponse.json(
      { order: formatted },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  } catch (err: any) {
    console.error('API /api/orders GET error:', err);
    return NextResponse.json({ error: err.message || 'Internal server error' }, { status: 500 });
  }
}

