import { NextRequest, NextResponse } from 'next/server';
import { uploadToCloudinaryServer } from '@/lib/cloudinary';
import { verifyAdminOrStaff } from '@/lib/auth/admin-guard';

export async function POST(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const formData = await req.formData();
    const file = formData.get('file') as File | null;
    const folder = (formData.get('folder') as string) || 'numbur-it/catalog';

    if (!file) {
      return NextResponse.json(
        { error: 'No image file was provided for upload.' },
        { status: 400 }
      );
    }

    // Validate mime type
    if (!file.type.startsWith('image/')) {
      return NextResponse.json(
        { error: 'Only image files (JPEG, PNG, WebP, SVG, AVIF) are supported.' },
        { status: 400 }
      );
    }

    // Max 10MB file limit
    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json(
        { error: 'Image file size must be less than 10MB.' },
        { status: 400 }
      );
    }

    // Convert file to base64 Data URI
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    const base64Data = `data:${file.type};base64,${buffer.toString('base64')}`;

    // Upload directly to Cloudinary
    const result = await uploadToCloudinaryServer(base64Data, folder);

    return NextResponse.json({
      success: true,
      url: result.secure_url,
      publicId: result.public_id,
      width: result.width,
      height: result.height,
    });
  } catch (error: any) {
    console.error('Image upload error:', error);
    const isConfigMissing =
      error.message?.includes('not configured') ||
      error.message?.includes('Missing Cloudinary');

    return NextResponse.json(
      {
        error: error.message || 'Image upload failed',
        isConfigMissing,
      },
      { status: isConfigMissing ? 503 : 500 }
    );
  }
}
