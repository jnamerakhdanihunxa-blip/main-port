import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { DEFAULT_SITE_SETTINGS } from '@/lib/site-defaults';

export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

export async function GET() {
  try {
    const supabase = createAdminClient();
    const { data, error } = await supabase.from('site_settings').select('key, value');

    if (error || !data || data.length === 0) {
      return NextResponse.json(
        { settings: DEFAULT_SITE_SETTINGS },
        {
          headers: {
            'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
          },
        }
      );
    }

    const settingsMap: Record<string, string> = { ...DEFAULT_SITE_SETTINGS };
    data.forEach((item) => {
      settingsMap[item.key] = item.value;
    });

    return NextResponse.json(
      { settings: settingsMap },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  } catch (err: any) {
    console.warn('API /api/settings error, returning defaults:', err);
    return NextResponse.json(
      { settings: DEFAULT_SITE_SETTINGS },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  }
}
