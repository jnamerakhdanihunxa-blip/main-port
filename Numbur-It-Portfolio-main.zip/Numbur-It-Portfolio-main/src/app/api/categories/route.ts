import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { FALLBACK_CATEGORIES } from '@/components/public/CategoryGrid';

export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

export async function GET() {
  try {
    const supabase = createAdminClient();
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .eq('is_active', true)
      .order('display_order', { ascending: true });

    const noCacheHeaders = {
      'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
    };

    if (!error && data && data.length > 0) {
      return NextResponse.json({ categories: data }, { headers: noCacheHeaders });
    }

    return NextResponse.json({ categories: FALLBACK_CATEGORIES }, { headers: noCacheHeaders });
  } catch (err: any) {
    console.warn('API /api/categories error, falling back:', err);
    return NextResponse.json(
      { categories: FALLBACK_CATEGORIES },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  }
}
