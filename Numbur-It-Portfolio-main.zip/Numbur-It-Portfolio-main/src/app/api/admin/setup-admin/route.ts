import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { verifyAdminOrStaff } from '@/lib/auth/admin-guard';

export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

const DEFAULT_ADMIN_EMAIL = 'admin@numburit.com';
const DEFAULT_ADMIN_PASSWORD = 'NumburAdmin@2069';

const DEFAULT_STAFF_EMAIL = 'staff@numburit.com';
const DEFAULT_STAFF_PASSWORD = 'NumburStaff@2069';

export async function POST(req: NextRequest) {
  try {
    const supabase = createAdminClient();
    const { data: listData, error: listError } = await supabase.auth.admin.listUsers();
    if (listError) {
      return NextResponse.json({ error: listError.message }, { status: 500 });
    }

    // 1. Super Admin Account
    let adminUser = listData.users.find((u) => u.email === DEFAULT_ADMIN_EMAIL);
    if (adminUser) {
      // Prevent unauthenticated credential resets if admin account exists
      const auth = await verifyAdminOrStaff(req);
      if (!auth.authorized || auth.role !== 'super_admin') {
        return NextResponse.json(
          { error: 'Admin account already exists. Super Admin authentication required to reset credentials.' },
          { status: 403 }
        );
      }

      await supabase.auth.admin.updateUserById(adminUser.id, {
        password: DEFAULT_ADMIN_PASSWORD,
        email_confirm: true,
        user_metadata: { full_name: 'Numbur iT Super Admin', role: 'super_admin' },
      });
    } else {
      const { data: created, error: createError } = await supabase.auth.admin.createUser({
        email: DEFAULT_ADMIN_EMAIL,
        password: DEFAULT_ADMIN_PASSWORD,
        email_confirm: true,
        user_metadata: { full_name: 'Numbur iT Super Admin', role: 'super_admin' },
      });
      if (createError) {
        return NextResponse.json({ error: createError.message }, { status: 500 });
      }
      adminUser = created.user;
    }

    await supabase.from('profiles').upsert({
      id: adminUser.id,
      full_name: 'Numbur iT Super Admin',
      phone: '9854040821',
      role: 'super_admin',
      is_active: true,
    });

    // 2. Staff Account
    let staffUser = listData.users.find((u) => u.email === DEFAULT_STAFF_EMAIL);
    if (staffUser) {
      await supabase.auth.admin.updateUserById(staffUser.id, {
        password: DEFAULT_STAFF_PASSWORD,
        email_confirm: true,
        user_metadata: { full_name: 'Numbur iT Staff Member', role: 'staff' },
      });
    } else {
      const { data: createdStaff, error: createStaffError } = await supabase.auth.admin.createUser({
        email: DEFAULT_STAFF_EMAIL,
        password: DEFAULT_STAFF_PASSWORD,
        email_confirm: true,
        user_metadata: { full_name: 'Numbur iT Staff Member', role: 'staff' },
      });
      if (createStaffError) {
        return NextResponse.json({ error: createStaffError.message }, { status: 500 });
      }
      staffUser = createdStaff.user;
    }

    await supabase.from('profiles').upsert({
      id: staffUser.id,
      full_name: 'Numbur iT Staff Member',
      phone: '9854040821',
      role: 'staff',
      is_active: true,
    });

    return NextResponse.json({
      success: true,
      message: 'Admin and staff accounts ready.',
      admin: { email: DEFAULT_ADMIN_EMAIL, role: 'super_admin' },
      staff: { email: DEFAULT_STAFF_EMAIL, role: 'staff' },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
