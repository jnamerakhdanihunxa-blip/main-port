import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { FALLBACK_SOCIAL_LINKS } from '@/lib/site-defaults';
import { verifyAdminOrStaff } from '@/lib/auth/admin-guard';

export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

export async function GET() {
  try {
    const supabase = createAdminClient();
    const { data, error } = await supabase
      .from('social_links')
      .select('*')
      .order('display_order', { ascending: true });

    if (error) {
      return NextResponse.json({ links: FALLBACK_SOCIAL_LINKS, warning: error.message });
    }

    return NextResponse.json(
      { links: data || [] },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const body = await req.json();
    const { action = 'create' } = body;
    const supabase = createAdminClient();

    if (action === 'delete') {
      const { id } = body;
      if (!id) return NextResponse.json({ error: 'Link ID is required' }, { status: 400 });

      const { error } = await supabase.from('social_links').delete().eq('id', id);
      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true });
    }

    if (action === 'create') {
      const {
        platform,
        platform_name,
        url,
        icon_name = 'Globe',
        display_order = 0,
        is_active = true,
      } = body;

      if (!platform || !url) {
        return NextResponse.json({ error: 'Platform and URL are required' }, { status: 400 });
      }

      const { data, error } = await supabase
        .from('social_links')
        .insert({
          platform: platform.toLowerCase(),
          platform_name: platform_name || platform,
          url,
          icon_name,
          display_order: Number(display_order),
          is_active: Boolean(is_active),
        })
        .select()
        .single();

      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true, link: data });
    }

    if (action === 'update') {
      const {
        id,
        platform,
        platform_name,
        url,
        icon_name,
        display_order,
        is_active,
      } = body;

      if (!id) return NextResponse.json({ error: 'Link ID is required' }, { status: 400 });

      const updateData: any = { updated_at: new Date().toISOString() };
      if (platform !== undefined) updateData.platform = platform.toLowerCase();
      if (platform_name !== undefined) updateData.platform_name = platform_name;
      if (url !== undefined) updateData.url = url;
      if (icon_name !== undefined) updateData.icon_name = icon_name;
      if (display_order !== undefined) updateData.display_order = Number(display_order);
      if (is_active !== undefined) updateData.is_active = Boolean(is_active);

      const { data, error } = await supabase
        .from('social_links')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true, link: data });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
