import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { DEFAULT_SITE_SETTINGS } from '@/lib/site-defaults';
import { verifyAdminOrStaff } from '@/lib/auth/admin-guard';

export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

export async function GET() {
  try {
    const supabase = createAdminClient();
    const { data, error } = await supabase.from('site_settings').select('*');

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    const settingsMap: Record<string, string> = { ...DEFAULT_SITE_SETTINGS };
    data?.forEach((item) => {
      settingsMap[item.key] = item.value;
    });

    return NextResponse.json(
      { settings: settingsMap, raw: data || [] },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const body = await req.json();
    const { settings } = body;

    if (!settings || typeof settings !== 'object') {
      return NextResponse.json({ error: 'Settings object required' }, { status: 400 });
    }

    const supabase = createAdminClient();

    // Upsert each key-value pair
    const upsertRows = Object.entries(settings).map(([key, value]) => ({
      key,
      value: String(value ?? ''),
      updated_at: new Date().toISOString(),
    }));

    const { data, error } = await supabase
      .from('site_settings')
      .upsert(upsertRows, { onConflict: 'key' })
      .select();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true, updated: data });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
