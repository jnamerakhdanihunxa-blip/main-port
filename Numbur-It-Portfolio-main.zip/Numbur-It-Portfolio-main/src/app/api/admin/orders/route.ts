import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { verifyAdminOrStaff } from '@/lib/auth/admin-guard';

export const dynamic = 'force-dynamic';
export const revalidate = 0;
export const fetchCache = 'force-no-store';

const DEMO_ORDERS = [
  {
    order_number: 'NIS-2026-1042',
    customer_name: 'Niraz Sapkota',
    customer_phone: '9854040821',
    delivery_address: 'Khimti-7, Ramechhap',
    municipality_area: 'Manthali Municipality',
    delivery_method: 'ramechhap_delivery',
    delivery_instructions: 'Deliver via Bolero vehicle near Khimti bazaar',
    subtotal_amount: 4499,
    total_amount: 4499,
    advance_payment_amount: 1000,
    remaining_balance: 3499,
    order_status: 'confirmed',
    payment_status: 'advance_paid',
    internal_notes: 'Advance verified via Fonepay QR. Ready to dispatch.',
    created_at: new Date(Date.now() - 3600000 * 4).toISOString(),
    items: [
      {
        name: 'EZVIZ H8c 2MP Smart WiFi Outdoor Camera',
        sku: 'CAM-EZ-H8C-2MP',
        quantity: 1,
        price: 4499,
        total: 4499,
      },
    ],
  },
];

export async function GET(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const supabase = createAdminClient();
    const { data: dbOrders, error } = await supabase
      .from('orders')
      .select(`
        id,
        order_number,
        customer_name,
        customer_phone,
        customer_email,
        delivery_address,
        municipality_area,
        delivery_method,
        delivery_instructions,
        customer_notes,
        subtotal_amount,
        total_amount,
        advance_payment_amount,
        remaining_balance,
        order_status,
        payment_status,
        internal_notes,
        created_at,
        updated_at,
        order_items (*)
      `)
      .order('created_at', { ascending: false });

    if (error || !dbOrders || dbOrders.length === 0) {
      return NextResponse.json({ orders: DEMO_ORDERS, source: 'fallback' });
    }

    const formattedOrders = dbOrders.map((o: any) => ({
      ...o,
      items: (o.order_items || []).map((i: any) => ({
        name: i.product_name_snapshot,
        sku: i.sku_snapshot,
        quantity: i.quantity,
        price: i.unit_price_snapshot,
        total: i.total_price,
      })),
    }));

    return NextResponse.json(
      { orders: formattedOrders, source: 'database' },
      {
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        },
      }
    );
  } catch (err: any) {
    console.warn('API /api/admin/orders GET warning:', err);
    return NextResponse.json({ orders: DEMO_ORDERS, source: 'fallback' });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const body = await req.json();
    const {
      order_number,
      order_status,
      payment_status,
      advance_payment_amount,
      remaining_balance,
      internal_notes,
    } = body;

    if (!order_number) {
      return NextResponse.json({ error: 'Order number is required' }, { status: 400 });
    }

    const supabase = createAdminClient();

    const updateFields: any = {
      updated_at: new Date().toISOString(),
    };

    if (order_status !== undefined) updateFields.order_status = order_status;
    if (payment_status !== undefined) updateFields.payment_status = payment_status;
    if (advance_payment_amount !== undefined) updateFields.advance_payment_amount = Number(advance_payment_amount);
    if (remaining_balance !== undefined) updateFields.remaining_balance = Number(remaining_balance);
    if (internal_notes !== undefined) updateFields.internal_notes = internal_notes;

    const { data, error } = await supabase
      .from('orders')
      .update(updateFields)
      .eq('order_number', order_number)
      .select()
      .maybeSingle();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true, order: data });
  } catch (err: any) {
    console.error('API /api/admin/orders PATCH error:', err);
    return NextResponse.json({ error: err.message || 'Internal server error' }, { status: 500 });
  }
}
