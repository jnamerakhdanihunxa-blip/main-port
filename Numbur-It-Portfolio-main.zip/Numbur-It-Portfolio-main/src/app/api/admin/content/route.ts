import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { verifyAdminOrStaff } from '@/lib/auth/admin-guard';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const supabase = createAdminClient();
    const [svcRes, bnrRes, galRes] = await Promise.all([
      supabase.from('services').select('*').order('display_order', { ascending: true }),
      supabase.from('site_banners').select('*').order('display_order', { ascending: true }),
      supabase.from('gallery_items').select('*').order('display_order', { ascending: true }),
    ]);

    return NextResponse.json({
      services: svcRes.data || [],
      banners: bnrRes.data || [],
      gallery: (galRes.data || []).map((g: any) => ({
        id: g.id,
        title: g.title_en || g.title,
        category: g.category || 'Store',
        url: g.image_url || '',
      })),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const body = await req.json();
    const { type, action = 'create', id, data: nestedData, ...flatData } = body;
    const itemData = nestedData || (Object.keys(flatData).length > 0 ? flatData : undefined);
    const supabase = createAdminClient();

    if (!type || !['banner', 'service', 'gallery'].includes(type)) {
      return NextResponse.json({ error: 'Valid content type required' }, { status: 400 });
    }

    const table =
      type === 'banner' ? 'site_banners' : type === 'service' ? 'services' : 'gallery_items';

    if (action === 'delete') {
      const targetId = id || itemData?.id;
      if (!targetId) return NextResponse.json({ error: 'ID required' }, { status: 400 });
      const { error } = await supabase.from(table).delete().eq('id', targetId);
      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true });
    }

    if (action === 'create') {
      if (!itemData) {
        return NextResponse.json({ error: 'Item data required' }, { status: 400 });
      }
      const createFields = { ...itemData };
      delete createFields.id;
      const { error, data: created } = await supabase
        .from(table)
        .insert(createFields)
        .select()
        .single();
      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true, item: created });
    }

    if (action === 'update') {
      const targetId = id || itemData?.id;
      if (!targetId) return NextResponse.json({ error: 'ID required' }, { status: 400 });
      const updateFields = itemData ? { ...itemData } : {};
      delete updateFields.id;
      if (Object.keys(updateFields).length === 0) {
        return NextResponse.json({ error: 'No update fields provided' }, { status: 400 });
      }
      const { error, data: updated } = await supabase
        .from(table)
        .update(updateFields)
        .eq('id', targetId)
        .select()
        .single();
      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true, item: updated });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
