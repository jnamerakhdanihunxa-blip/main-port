import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { verifyAdminOrStaff } from '@/lib/auth/admin-guard';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const supabase = createAdminClient();
    const { data, error } = await supabase
      .from('products')
      .select(`
        *,
        category:categories!left(*),
        brand:brands!left(*),
        inventory:inventory!left(*)
      `)
      .order('created_at', { ascending: false });

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    const formatted = (data || []).map((p: any) => ({
      ...p,
      inventory: p.inventory
        ? {
            available_quantity: p.inventory.available_quantity,
            in_stock: p.inventory.available_quantity > 0,
          }
        : { available_quantity: 0, in_stock: false },
    }));

    return NextResponse.json({ products: formatted });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const body = await req.json();
    const { action = 'create' } = body;
    const supabase = createAdminClient();

    if (action === 'delete') {
      const { id } = body;
      if (!id) {
        return NextResponse.json({ error: 'Product ID required' }, { status: 400 });
      }

      await supabase.from('inventory').delete().eq('product_id', id);
      const { error } = await supabase.from('products').delete().eq('id', id);

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 400 });
      }

      return NextResponse.json({ success: true, message: 'Product deleted' });
    }

    if (action === 'create') {
      const {
        name_en,
        name_ne,
        sku,
        slug,
        category_id,
        brand_id,
        selling_price,
        cost_price,
        discount_price,
        primary_image_url,
        short_desc_en,
        full_desc_en,
        warranty_info_en,
        specifications,
        is_featured = false,
        is_bestseller = false,
        is_new_arrival = false,
        is_active = true,
        initial_stock = 10,
      } = body;

      if (!name_en || !category_id) {
        return NextResponse.json(
          { error: 'Name and Category are required' },
          { status: 400 }
        );
      }

      const generatedSlug =
        slug ||
        name_en
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)+/g, '') +
          '-' +
          Date.now();

      const generatedSku =
        sku || `SKU-${Math.floor(1000 + Math.random() * 9000)}`;

      const { data: newProd, error: prodErr } = await supabase
        .from('products')
        .insert({
          name_en,
          name_ne: name_ne || null,
          slug: generatedSlug,
          sku: generatedSku,
          category_id,
          brand_id: brand_id || null,
          selling_price: Number(selling_price) || 0,
          cost_price: cost_price !== undefined && cost_price !== null ? Number(cost_price) : null,
          discount_price: discount_price !== undefined && discount_price !== null ? Number(discount_price) : null,
          primary_image_url: primary_image_url || null,
          short_desc_en: short_desc_en || null,
          full_desc_en: full_desc_en || null,
          warranty_info_en: warranty_info_en || null,
          specifications: specifications || {},
          is_featured: Boolean(is_featured),
          is_bestseller: Boolean(is_bestseller),
          is_new_arrival: Boolean(is_new_arrival),
          is_active: Boolean(is_active),
        })
        .select(`
          *,
          category:categories!left(*),
          brand:brands!left(*)
        `)
        .single();

      if (prodErr) {
        console.error('Admin product insert error:', prodErr);
        return NextResponse.json({ error: prodErr.message }, { status: 400 });
      }

      // Create corresponding inventory record
      const stockQty = Number(initial_stock) >= 0 ? Number(initial_stock) : 10;
      await supabase.from('inventory').insert({
        product_id: newProd.id,
        total_purchased: stockQty,
        available_quantity: stockQty,
        sold_quantity: 0,
        damaged_quantity: 0,
        low_stock_threshold: 3,
      });

      return NextResponse.json({
        success: true,
        product: {
          ...newProd,
          inventory: {
            available_quantity: stockQty,
            in_stock: stockQty > 0,
          },
        },
      });
    }

    if (action === 'update') {
      const {
        id,
        name_en,
        name_ne,
        sku,
        slug,
        category_id,
        brand_id,
        selling_price,
        cost_price,
        discount_price,
        primary_image_url,
        short_desc_en,
        full_desc_en,
        warranty_info_en,
        specifications,
        is_featured,
        is_bestseller,
        is_new_arrival,
        is_active,
        available_quantity,
      } = body;

      if (!id) {
        return NextResponse.json({ error: 'Product ID required' }, { status: 400 });
      }

      const updateData: any = {
        updated_at: new Date().toISOString(),
      };

      if (name_en !== undefined) updateData.name_en = name_en;
      if (name_ne !== undefined) updateData.name_ne = name_ne || null;
      if (sku !== undefined) updateData.sku = sku;
      if (slug !== undefined) updateData.slug = slug;
      if (category_id !== undefined) updateData.category_id = category_id;
      if (brand_id !== undefined) updateData.brand_id = brand_id || null;
      if (selling_price !== undefined) updateData.selling_price = Number(selling_price);
      if (cost_price !== undefined) updateData.cost_price = cost_price !== null ? Number(cost_price) : null;
      if (discount_price !== undefined) updateData.discount_price = discount_price !== null ? Number(discount_price) : null;
      if (primary_image_url !== undefined) updateData.primary_image_url = primary_image_url || null;
      if (short_desc_en !== undefined) updateData.short_desc_en = short_desc_en;
      if (full_desc_en !== undefined) updateData.full_desc_en = full_desc_en;
      if (warranty_info_en !== undefined) updateData.warranty_info_en = warranty_info_en || null;
      if (specifications !== undefined) updateData.specifications = specifications;
      if (is_featured !== undefined) updateData.is_featured = Boolean(is_featured);
      if (is_bestseller !== undefined) updateData.is_bestseller = Boolean(is_bestseller);
      if (is_new_arrival !== undefined) updateData.is_new_arrival = Boolean(is_new_arrival);
      if (is_active !== undefined) updateData.is_active = Boolean(is_active);

      let { data: updatedProd, error: updateErr } = await supabase
        .from('products')
        .update(updateData)
        .eq('id', id)
        .select(`
          *,
          category:categories!left(*),
          brand:brands!left(*)
        `)
        .maybeSingle();

      // If not updated by ID (e.g. ID mismatch or mock ID), fallback to update by slug
      if (!updatedProd && slug) {
        const bySlug = await supabase
          .from('products')
          .update(updateData)
          .eq('slug', slug)
          .select(`
            *,
            category:categories!left(*),
            brand:brands!left(*)
          `)
          .maybeSingle();
        if (bySlug.data) {
          updatedProd = bySlug.data;
          updateErr = bySlug.error;
        }
      }

      // If still not found, upsert product so changes are never lost
      if (!updatedProd && !updateErr) {
        const { data: upsertedProd, error: upsertErr } = await supabase
          .from('products')
          .upsert({
            id,
            ...updateData,
          })
          .select(`
            *,
            category:categories!left(*),
            brand:brands!left(*)
          `)
          .maybeSingle();
        updatedProd = upsertedProd;
        updateErr = upsertErr;
      }

      if (updateErr) {
        console.error('Admin product update error:', updateErr);
        return NextResponse.json({ error: updateErr.message }, { status: 400 });
      }

      // Update inventory if available_quantity provided
      if (available_quantity !== undefined) {
        const qty = Number(available_quantity);
        await supabase
          .from('inventory')
          .upsert(
            {
              product_id: id,
              available_quantity: qty,
              total_purchased: qty,
              updated_at: new Date().toISOString(),
            },
            { onConflict: 'product_id' }
          );
      }

      return NextResponse.json({
        success: true,
        product: updatedProd,
      });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (err: any) {
    console.error('API /api/admin/products error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
