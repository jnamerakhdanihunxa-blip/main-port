import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { verifyAdminOrStaff } from '@/lib/auth/admin-guard';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const supabase = createAdminClient();
    const { data, error } = await supabase
      .from('staff_profiles')
      .select('*')
      .order('display_order', { ascending: true });

    if (error) return NextResponse.json({ error: error.message }, { status: 400 });
    return NextResponse.json({ staff: data || [] });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const body = await req.json();
    const { action = 'create' } = body;
    const supabase = createAdminClient();

    if (action === 'delete') {
      const { id } = body;
      if (!id) return NextResponse.json({ error: 'Staff ID required' }, { status: 400 });

      const { error } = await supabase.from('staff_profiles').delete().eq('id', id);
      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true });
    }

    if (action === 'create') {
      const {
        name,
        designation,
        department,
        bio_en,
        bio_ne,
        photo_url,
        public_contact_phone,
        public_contact_email,
        public_address,
        display_order = 1,
        is_public = true,
      } = body;

      if (!name || !designation) {
        return NextResponse.json({ error: 'Name and designation are required' }, { status: 400 });
      }

      const { data, error } = await supabase
        .from('staff_profiles')
        .insert({
          name,
          designation,
          department: department || null,
          bio_en: bio_en || null,
          bio_ne: bio_ne || null,
          photo_url: photo_url || null,
          public_contact_phone: public_contact_phone || null,
          public_contact_email: public_contact_email || null,
          public_address: public_address || null,
          display_order: Number(display_order),
          is_public: Boolean(is_public),
        })
        .select()
        .single();

      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true, staff: data });
    }

    if (action === 'update') {
      const {
        id,
        name,
        designation,
        department,
        bio_en,
        bio_ne,
        photo_url,
        public_contact_phone,
        public_contact_email,
        public_address,
        display_order,
        is_public,
      } = body;

      if (!id) return NextResponse.json({ error: 'Staff ID required' }, { status: 400 });

      const updateData: any = { updated_at: new Date().toISOString() };
      if (name !== undefined) updateData.name = name;
      if (designation !== undefined) updateData.designation = designation;
      if (department !== undefined) updateData.department = department;
      if (bio_en !== undefined) updateData.bio_en = bio_en;
      if (bio_ne !== undefined) updateData.bio_ne = bio_ne;
      if (photo_url !== undefined) updateData.photo_url = photo_url || null;
      if (public_contact_phone !== undefined) updateData.public_contact_phone = public_contact_phone || null;
      if (public_contact_email !== undefined) updateData.public_contact_email = public_contact_email || null;
      if (public_address !== undefined) updateData.public_address = public_address || null;
      if (display_order !== undefined) updateData.display_order = Number(display_order);
      if (is_public !== undefined) updateData.is_public = Boolean(is_public);

      const { data, error } = await supabase
        .from('staff_profiles')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true, staff: data });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
