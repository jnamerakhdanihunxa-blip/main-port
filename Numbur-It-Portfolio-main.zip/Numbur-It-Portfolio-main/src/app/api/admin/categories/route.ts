import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { verifyAdminOrStaff } from '@/lib/auth/admin-guard';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const supabase = createAdminClient();
    const { data, error } = await supabase
      .from('categories')
      .select('*')
      .order('display_order', { ascending: true });

    if (error) return NextResponse.json({ error: error.message }, { status: 400 });
    return NextResponse.json({ categories: data || [] });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const body = await req.json();
    const { action = 'create' } = body;
    const supabase = createAdminClient();

    if (action === 'delete') {
      const { id } = body;
      if (!id) return NextResponse.json({ error: 'Category ID required' }, { status: 400 });

      // Check for linked products
      const { data: linkedProds } = await supabase
        .from('products')
        .select('id')
        .eq('category_id', id);

      if (linkedProds && linkedProds.length > 0) {
        return NextResponse.json(
          {
            error: `Cannot delete category: ${linkedProds.length} product(s) are linked to it. Please reassign or delete them first.`,
          },
          { status: 400 }
        );
      }

      const { error } = await supabase.from('categories').delete().eq('id', id);
      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true });
    }

    if (action === 'create') {
      const {
        name_en,
        name_ne,
        slug,
        description_en,
        description_ne,
        image_url,
        display_order = 1,
        is_active = true,
      } = body;

      if (!name_en) {
        return NextResponse.json({ error: 'Category name is required' }, { status: 400 });
      }

      const generatedSlug =
        slug ||
        name_en
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)+/g, '');

      const { data, error } = await supabase
        .from('categories')
        .insert({
          name_en,
          name_ne: name_ne || null,
          slug: generatedSlug,
          description_en: description_en || null,
          description_ne: description_ne || null,
          image_url: image_url || null,
          display_order: Number(display_order),
          is_active: Boolean(is_active),
        })
        .select()
        .single();

      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true, category: data });
    }

    if (action === 'update') {
      const {
        id,
        name_en,
        name_ne,
        slug,
        description_en,
        description_ne,
        image_url,
        display_order,
        is_active,
      } = body;

      if (!id) return NextResponse.json({ error: 'Category ID required' }, { status: 400 });

      const updateData: any = { updated_at: new Date().toISOString() };
      if (name_en !== undefined) updateData.name_en = name_en;
      if (name_ne !== undefined) updateData.name_ne = name_ne || null;
      if (slug !== undefined) updateData.slug = slug;
      if (description_en !== undefined) updateData.description_en = description_en;
      if (description_ne !== undefined) updateData.description_ne = description_ne;
      if (image_url !== undefined) updateData.image_url = image_url || null;
      if (display_order !== undefined) updateData.display_order = Number(display_order);
      if (is_active !== undefined) updateData.is_active = Boolean(is_active);

      const { data, error } = await supabase
        .from('categories')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) return NextResponse.json({ error: error.message }, { status: 400 });
      return NextResponse.json({ success: true, category: data });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
