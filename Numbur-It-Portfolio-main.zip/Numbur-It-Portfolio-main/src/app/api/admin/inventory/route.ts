import { NextRequest, NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { verifyAdminOrStaff } from '@/lib/auth/admin-guard';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const supabase = createAdminClient();

    const [prodRes, moveRes] = await Promise.all([
      supabase
        .from('products')
        .select(`
          id,
          name_en,
          sku,
          selling_price,
          category:categories(name_en),
          inventory:inventory(*)
        `)
        .order('name_en', { ascending: true }),
      supabase
        .from('inventory_movements')
        .select(`
          *,
          product:products(name_en, sku)
        `)
        .order('created_at', { ascending: false })
        .limit(50),
    ]);

    return NextResponse.json({
      products: prodRes.data || [],
      movements: moveRes.data || [],
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await verifyAdminOrStaff(req);
    if (!auth.authorized) {
      return NextResponse.json({ error: auth.error || 'Unauthorized' }, { status: auth.status || 401 });
    }

    const body = await req.json();
    const { productId, quantityChange, movementType, reason, staffName = 'Admin' } = body;

    if (!productId || quantityChange === undefined || !movementType || !reason) {
      return NextResponse.json(
        { error: 'Product ID, quantity change, movement type, and reason are required' },
        { status: 400 }
      );
    }

    const supabase = createAdminClient();

    // 1. Fetch current stock
    const { data: invData, error: invFetchErr } = await supabase
      .from('inventory')
      .select('*')
      .eq('product_id', productId)
      .single();

    let currentQty = 0;
    let totalPurchased = 0;
    let soldQty = 0;
    let damagedQty = 0;

    if (invData) {
      currentQty = invData.available_quantity || 0;
      totalPurchased = invData.total_purchased || 0;
      soldQty = invData.sold_quantity || 0;
      damagedQty = invData.damaged_quantity || 0;
    }

    const changeVal = Number(quantityChange);
    const delta =
      movementType === 'purchase' || movementType === 'return'
        ? Math.abs(changeVal)
        : -Math.abs(changeVal);

    // Negative stock prevention rule
    if (currentQty + delta < 0) {
      return NextResponse.json(
        {
          error: `Atomic Stock Rule: Cannot deduct ${Math.abs(
            changeVal
          )} units. Available stock is only ${currentQty}. Negative stock disallowed.`,
        },
        { status: 400 }
      );
    }

    const newQty = currentQty + delta;
    if (movementType === 'purchase') {
      totalPurchased += Math.abs(changeVal);
    } else if (movementType === 'sale') {
      soldQty += Math.abs(changeVal);
    } else if (movementType === 'damaged') {
      damagedQty += Math.abs(changeVal);
    }

    // 2. Upsert inventory
    const { error: upsertErr } = await supabase.from('inventory').upsert(
      {
        product_id: productId,
        available_quantity: newQty,
        total_purchased: totalPurchased,
        sold_quantity: soldQty,
        damaged_quantity: damagedQty,
        updated_at: new Date().toISOString(),
      },
      { onConflict: 'product_id' }
    );

    if (upsertErr) {
      return NextResponse.json({ error: upsertErr.message }, { status: 400 });
    }

    // 3. Record in immutable movement ledger
    const { data: movementRow, error: moveErr } = await supabase
      .from('inventory_movements')
      .insert({
        product_id: productId,
        quantity_change: delta,
        movement_type: movementType,
        reason: reason.trim(),
        created_at: new Date().toISOString(),
      })
      .select(`
        *,
        product:products(name_en, sku)
      `)
      .single();

    return NextResponse.json({
      success: true,
      newQuantity: newQty,
      movement: movementRow || {
        id: `m-${Date.now()}`,
        product_id: productId,
        quantity_change: delta,
        movement_type: movementType,
        reason: reason.trim(),
        created_at: new Date().toISOString(),
        staff: { full_name: staffName },
      },
    });
  } catch (err: any) {
    console.error('API /api/admin/inventory error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
