import { NextRequest, NextResponse } from 'next/server';
import { generateCloudinarySignature } from '@/lib/cloudinary';
import { createClientServer } from '@/lib/supabase/server';

export async function POST(req: NextRequest) {
  try {
    const supabase = createClientServer();
    const {
      data: { user },
    } = await supabase.auth.getUser();

    // Check if authenticated
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if user is staff or admin
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (!profile || !['staff', 'admin', 'super_admin'].includes(profile.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const timestamp = Math.round(new Date().getTime() / 1000);
    const body = await req.json().catch(() => ({}));
    const folder = body.folder || 'numbur-it/products';

    const paramsToSign = {
      timestamp,
      folder,
    };

    const signatureData = generateCloudinarySignature(paramsToSign);

    return NextResponse.json({
      ...signatureData,
      folder,
    });
  } catch (error: any) {
    console.error('Cloudinary sign error:', error);
    return NextResponse.json(
      { error: error.message || 'Signature generation failed' },
      { status: 500 }
    );
  }
}
