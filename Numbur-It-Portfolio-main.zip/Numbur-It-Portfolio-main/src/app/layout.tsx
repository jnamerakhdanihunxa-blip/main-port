import type { Metadata } from 'next';
import './globals.css';
import { ThemeProvider } from '@/lib/theme/context';
import { LanguageProvider } from '@/lib/i18n/context';
import { CartProvider } from '@/lib/cart/context';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'),
  title: 'Numbur iT Solution Pvt. Ltd. | Ultimate IT & CCTV Solutions in Ramechhap',
  description:
    'Numbur iT Solution is the premier IT solution provider in Manthali, Ramechhap since 2069 BS. Offering genuine laptops, computers, CCTV surveillance, printers, networking, power backup, and fast WhatsApp ordering.',
  keywords: [
    'Numbur iT Solution',
    'Ramechhap IT Shop',
    'Manthali Computer Repair',
    'CCTV Installation Ramechhap',
    'Dell Laptops Nepal',
    'EZVIZ Cameras Manthali',
    'Office Automation Ramechhap',
  ],
  icons: {
    icon: '/favicon.ico',
  },
  openGraph: {
    title: 'Numbur iT Solution Pvt. Ltd. | Manthali, Ramechhap',
    description:
      'The Ultimate IT solution - Laptops, CCTV Security, Printers, Networking & Expert Support since 2069 BS.',
    url: 'https://numbur-it.com',
    siteName: 'Numbur iT Solution',
    locale: 'en_US',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                try {
                  var stored = localStorage.getItem('numbur_theme');
                  var prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                  if (stored === 'dark' || (!stored && prefersDark)) {
                    document.documentElement.classList.add('dark');
                    document.documentElement.style.colorScheme = 'dark';
                  } else {
                    document.documentElement.classList.remove('dark');
                    document.documentElement.style.colorScheme = 'light';
                  }
                } catch (e) {}
              })();
            `,
          }}
        />
      </head>
      <body className="min-h-screen flex flex-col font-sans bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 transition-colors duration-200">
        <ThemeProvider>
          <LanguageProvider>
            <CartProvider>{children}</CartProvider>
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
