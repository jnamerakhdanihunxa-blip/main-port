import { redirect } from 'next/navigation';

export default function StaffPage() {
  redirect('/admin/login');
}
