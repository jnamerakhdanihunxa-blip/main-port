'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useCart } from '@/lib/cart/context';
import { useLanguage } from '@/lib/i18n/context';
import { buildWhatsAppOrderUrl, WhatsAppOrderData } from '@/lib/whatsapp';
import { DeliveryMethod } from '@/types';
import {
  MessageSquare,
  ShieldAlert,
  Truck,
  Store,
  Info,
  CheckCircle2,
  Lock,
  ArrowRight,
} from 'lucide-react';

export default function CheckoutPage() {
  const router = useRouter();
  const { items, subtotal, clearCart } = useCart();
  const { language, t } = useLanguage();

  const [deliveryMethod, setDeliveryMethod] =
    useState<DeliveryMethod>('all_nepal_delivery');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [municipalityArea, setMunicipalityArea] = useState('Manthali Municipality');
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderComplete, setOrderComplete] = useState<{
    orderNumber: string;
    waUrl: string;
  } | null>(null);

  if (items.length === 0 && !orderComplete) {
    return (
      <div className="max-w-md mx-auto my-16 px-4 text-center">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 transition-colors">
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Your cart is empty</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Please add items to your cart before proceeding to checkout.
          </p>
          <Link
            href="/products"
            className="inline-block bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs px-6 py-2.5 rounded-xl transition"
          >
            Browse Products
          </Link>
        </div>
      </div>
    );
  }

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || !deliveryAddress) {
      alert('Please fill in all required customer and delivery fields.');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        customer_name: customerName.trim(),
        customer_phone: customerPhone.trim(),
        delivery_address: deliveryAddress.trim(),
        municipality_area: municipalityArea.trim(),
        delivery_method: deliveryMethod,
        customer_notes: specialInstructions.trim() || undefined,
        items: items.map((i) => ({
          productId: i.product.id,
          slug: i.product.slug,
          quantity: i.quantity,
          price: i.selectedPrice,
        })),
      };

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to submit order.');
      }

      setOrderComplete({
        orderNumber: data.orderNumber,
        waUrl: data.waUrl,
      });

      // Clear the cart
      clearCart();

      // Open WhatsApp automatically in a new tab
      if (data.waUrl) {
        window.open(data.waUrl, '_blank', 'noopener,noreferrer');
      }
    } catch (err: any) {
      console.error('Order creation error:', err);
      alert(err.message || 'Failed to submit order. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Order Success & WhatsApp Guidance Screen
  if (orderComplete) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-12">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 sm:p-10 border border-slate-200/90 dark:border-slate-800 shadow-lg text-center space-y-6 transition-colors">
          <div className="w-16 h-16 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-100 dark:border-emerald-800">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-2">
            <span className="text-xs font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-3 py-1 rounded-full">
              ORDER #{orderComplete.orderNumber}
            </span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
              Pending Order Created!
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-md mx-auto">
              Your pending order has been recorded in our system. Please ensure you send the message in WhatsApp to our representative.
            </p>
          </div>

          {/* CRITICAL NOTICE: Opening WhatsApp != Order Confirmed */}
          <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl p-4 text-left text-xs text-amber-900 dark:text-amber-200 space-y-2">
            <div className="flex items-center gap-2 font-bold text-amber-800 dark:text-amber-300">
              <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>Important Order Confirmation Notice:</span>
            </div>
            <p className="leading-relaxed">
              Opening WhatsApp does <strong>NOT</strong> mean your message was sent or that your order is automatically confirmed. You must review and tap <strong>Send</strong> in WhatsApp so our team can discuss delivery logistics, advance payment options, and finalize dispatch.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
            <a
              href={orderComplete.waUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-6 py-3.5 rounded-xl transition shadow"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Re-open WhatsApp Message</span>
            </a>

            <Link
              href={`/orders/${orderComplete.orderNumber}`}
              className="inline-flex items-center justify-center gap-2 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold text-xs px-6 py-3.5 rounded-xl transition shadow"
            >
              <span>View Order Instructions</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-8">
      <div className="mb-8 border-b border-slate-200 dark:border-slate-800 pb-4">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
          {t.checkout.title}
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xl">
          {t.checkout.subtitle}
        </p>
      </div>

      <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Customer & Delivery Details (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Customer Details Box */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 transition-colors">
            <h2 className="font-bold text-base text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3 flex items-center gap-2">
              <span>{t.checkout.customerDetails}</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t.checkout.fullName} *
                </label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Niraz Sapkota"
                  className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t.checkout.phone} *
                </label>
                <input
                  type="tel"
                  required
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="e.g. 9854040821"
                  className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
                <span className="text-[11px] text-slate-400 dark:text-slate-500 block mt-1">
                  {t.checkout.phoneHelp}
                </span>
              </div>
            </div>
          </div>

          {/* Delivery Method Selection */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 transition-colors">
            <h2 className="font-bold text-base text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3">
              {t.checkout.deliveryMethodTitle}
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label
                className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition ${
                  deliveryMethod === 'all_nepal_delivery' || deliveryMethod === 'ramechhap_delivery'
                    ? 'bg-brand-50/70 dark:bg-brand-950/40 border-brand-500 ring-1 ring-brand-500'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800'
                }`}
              >
                <input
                  type="radio"
                  name="deliveryMethod"
                  value="all_nepal_delivery"
                  checked={deliveryMethod === 'all_nepal_delivery' || deliveryMethod === 'ramechhap_delivery'}
                  onChange={() => setDeliveryMethod('all_nepal_delivery')}
                  className="mt-1 text-brand-600 focus:ring-brand-500"
                />
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-xs text-slate-900 dark:text-white mb-1">
                    <Truck className="w-4 h-4 text-brand-600 dark:text-brand-400" />
                    <span>All Nepal Delivery (नेपालभर डेलिभरी)</span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    Nationwide courier & transport dispatch available across all 77 districts of Nepal.
                  </p>
                </div>
              </label>

              <label
                className={`flex items-start gap-3 p-4 rounded-2xl border cursor-pointer transition ${
                  deliveryMethod === 'store_pickup'
                    ? 'bg-brand-50/70 dark:bg-brand-950/40 border-brand-500 ring-1 ring-brand-500'
                    : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800'
                }`}
              >
                <input
                  type="radio"
                  name="deliveryMethod"
                  value="store_pickup"
                  checked={deliveryMethod === 'store_pickup'}
                  onChange={() => setDeliveryMethod('store_pickup')}
                  className="mt-1 text-brand-600 focus:ring-brand-500"
                />
                <div>
                  <div className="flex items-center gap-1.5 font-bold text-xs text-slate-900 dark:text-white mb-1">
                    <Store className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span>Store Pickup (Manthali-1 Showroom)</span>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    Devkota Chowk, Manthali-1, Ramechhap. Free of any delivery charges.
                  </p>
                </div>
              </label>
            </div>

            {/* Address inputs */}
            <div className="space-y-4 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {t.checkout.municipalityArea} *
                  </label>
                  <input
                    type="text"
                    required
                    value={municipalityArea}
                    onChange={(e) => setMunicipalityArea(e.target.value)}
                    placeholder="e.g. Manthali Municipality - 1"
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {t.checkout.deliveryAddress} *
                  </label>
                  <input
                    type="text"
                    required
                    value={deliveryAddress}
                    onChange={(e) => setDeliveryAddress(e.target.value)}
                    placeholder="e.g. Near Bus Park, Manthali"
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t.checkout.deliveryInstructions}
                </label>
                <textarea
                  rows={2}
                  value={specialInstructions}
                  onChange={(e) => setSpecialInstructions(e.target.value)}
                  placeholder="e.g. Call before arrival, deliver between 10am-2pm..."
                  className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>
            </div>

            {/* Delivery Limitations Disclaimer Box */}
            <div className="bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-2xl p-4 text-xs text-blue-900 dark:text-blue-200 space-y-1.5">
              <div className="font-bold flex items-center gap-1.5">
                <Info className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                <span>{t.checkout.deliveryDisclaimerTitle}</span>
              </div>
              <p className="leading-relaxed text-blue-800 dark:text-blue-300">
                {t.checkout.deliveryDisclaimerText}
              </p>
            </div>
          </div>
        </div>

        {/* Right: Order Summary & WhatsApp Action (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5 sticky top-24 transition-colors">
            <h2 className="font-bold text-base text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3">
              Order Review ({items.length} items)
            </h2>

            {/* Itemized Mini List */}
            <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
              {items.map((item) => (
                <div
                  key={item.id}
                  className="flex justify-between items-center text-xs py-1 border-b border-slate-50 dark:border-slate-800"
                >
                  <div className="min-w-0 pr-2">
                    <p className="font-semibold text-slate-900 dark:text-white truncate">
                      {item.product.name_en}
                    </p>
                    <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                      Qty: {item.quantity} x Rs. {item.selectedPrice.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <span className="font-bold text-slate-900 dark:text-white shrink-0">
                    Rs. {(item.selectedPrice * item.quantity).toLocaleString('en-IN')}
                  </span>
                </div>
              ))}
            </div>

            {/* Subtotal */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex justify-between items-baseline">
              <span className="font-extrabold text-sm text-slate-900 dark:text-white">Total Due</span>
              <span className="text-2xl font-black text-brand-600 dark:text-brand-400">
                Rs. {subtotal.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Advance Payment Notice */}
            <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl p-3 text-[11px] text-amber-900 dark:text-amber-200 leading-relaxed">
              <strong>{t.checkout.advancePaymentNoticeTitle}</strong>{' '}
              {t.checkout.advancePaymentNoticeText}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-4 px-6 rounded-xl transition shadow-md disabled:opacity-50"
            >
              <MessageSquare className="w-4 h-4" />
              <span>
                {isSubmitting
                  ? t.checkout.submitting
                  : t.checkout.placeOrderBtn}
              </span>
            </button>

            <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal text-center">
              {t.checkout.whatsappNotice}
            </p>
          </div>
        </div>
      </form>
    </div>
  );
}
