'use client';

import React, { useState, useEffect } from 'react';
import ServicesSection, { AUDITED_SERVICES_FALLBACK } from '@/components/public/ServicesSection';
import { ServiceItem } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import { Wrench, PhoneCall, ShieldCheck, CheckCircle2 } from 'lucide-react';

export default function ServicesPage() {
  const { language, t } = useLanguage();
  const [services, setServices] = useState<ServiceItem[]>(AUDITED_SERVICES_FALLBACK);

  useEffect(() => {
    async function loadServices() {
      try {
        const res = await fetch('/api/content', { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data.services && data.services.length > 0) {
            setServices(data.services);
          }
        }
      } catch (err) {
        console.warn('Failed to load services:', err);
      }
    }
    loadServices();
  }, []);

  return (
    <div className="space-y-12">
      {/* Header */}
      <section className="bg-slate-950 text-white py-16 border-b border-slate-800/60">
        <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 text-center max-w-4xl mx-auto">
          <span className="text-xs font-bold text-brand-400 uppercase tracking-wider bg-brand-500/20 border border-brand-400/40 px-3 py-1 rounded-full">
            {language === 'ne' ? 'हाम्रा सेवाहरू' : 'Enterprise & Home Services'}
          </span>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold mt-4 mb-4">
            {t.home.servicesTitle}
          </h1>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-6">
            {language === 'ne'
              ? '१० वर्षभन्दा बढी समयदेखिको अनुभवका साथ हामी मन्थली-१, रामेछापमा कम्प्युटर मर्मत, सीसीटीभी क्यामेरा जडान, र नेटवर्किङ पूर्वाधार सेवाहरू प्रदान गर्दछौं।'
              : 'End-to-end technical support, hardware maintenance, network infrastructure cabling, and CCTV surveillance headquartered in Manthali-1, Ramechhap.'}
          </p>

          {/* Important Coverage Notice: Services in Manthali-1 only, Delivery All Over Nepal */}
          <div className="bg-slate-900/90 border border-brand-500/40 rounded-2xl p-4 sm:p-5 text-left max-w-2xl mx-auto shadow-lg backdrop-blur-sm">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
              <div className="space-y-1">
                <span className="font-extrabold text-amber-400 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                  <span>🛠️</span> {language === 'ne' ? 'प्राविधिक सेवा क्षेत्र:' : 'Technical Services Area:'}
                </span>
                <p className="text-slate-200">
                  {language === 'ne'
                    ? 'अन-साइट प्राविधिक तथा मर्मत सेवाहरू मन्थली-१, रामेछापमा मात्र उपलब्ध छन्।'
                    : 'On-site technical, CCTV installation & repair services are strictly in Manthali-1, Ramechhap only.'}
                </p>
              </div>
              <div className="sm:border-l sm:border-slate-700 sm:pl-4 space-y-1">
                <span className="font-extrabold text-emerald-400 flex items-center gap-1.5 uppercase tracking-wider text-[11px]">
                  <span>🚚</span> {language === 'ne' ? 'सामान डेलिभरी प्रणाली:' : 'Product Delivery System:'}
                </span>
                <p className="text-slate-200">
                  {language === 'ne'
                    ? 'हाम्रा सबै सामानहरू नेपालभर (सबै ७७ जिल्लाहरूमा) डेलिभरी उपलब्ध छ।'
                    : 'Product sales & delivery available all over Nepal across all 77 districts!'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16">
        <ServicesSection services={services} />
      </div>

      {/* On-Site Visit Policy Note */}
      <section className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 pb-12">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 md:p-10 border border-slate-200/90 dark:border-slate-800 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              {language === 'ne'
                ? 'के तपाईंलाई अफिस वा घरमै प्राविधिक चाहिएको छ?'
                : 'Need a technician visit at your office or home in Ramechhap?'}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 max-w-xl">
              {language === 'ne'
                ? 'हाम्रो टिमले गाडी पुग्ने स्थानहरूमा अन-साइट भिजिट सेवा प्रदान गर्दछ। विस्तृत जानकारीको लागि तुरुन्त फोन गर्नुहोस्।'
                : 'Our field engineers travel across Ramechhap accessible by motor vehicles. Call our technical desk for schedule confirmation.'}
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <a
              href="tel:048540314"
              className="bg-brand-600 hover:bg-brand-500 text-white font-bold text-xs px-6 py-3 rounded-xl transition shadow flex items-center gap-2"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Call: 048540314 / 9854040821</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
