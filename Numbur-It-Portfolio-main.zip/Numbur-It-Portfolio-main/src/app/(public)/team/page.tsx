'use client';

import React, { useState, useEffect } from 'react';
import TeamSection, { AUDITED_STAFF_FALLBACK } from '@/components/public/TeamSection';
import { StaffProfile } from '@/types';
import { useLanguage } from '@/lib/i18n/context';

export default function TeamPage() {
  const { language, t } = useLanguage();
  const [staff, setStaff] = useState<StaffProfile[]>(AUDITED_STAFF_FALLBACK);

  useEffect(() => {
    async function loadStaff() {
      try {
        const res = await fetch('/api/content', { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data.staff && data.staff.length > 0) {
            setStaff(data.staff);
          }
        }
      } catch (err) {
        console.warn('Failed to load team staff:', err);
      }
    }
    loadStaff();
  }, []);

  return (
    <div>
      <section className="bg-slate-950 text-white py-16 border-b border-slate-800/60">
        <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 text-center max-w-4xl mx-auto">
          <span className="text-xs font-bold text-brand-400 uppercase tracking-wider bg-brand-500/20 border border-brand-400/40 px-3 py-1 rounded-full">
            {language === 'ne' ? 'हाम्रा संस्थापक तथा प्राविधिकहरू' : 'Our Team & Leadership'}
          </span>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold mt-4 mb-4">
            {t.home.teamTitle}
          </h1>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            {language === 'ne'
              ? 'नम्बुर आइटी सोलुसनलाई अगाडि बढाउने र मन्थली तथा रामेछापभर प्राविधिक सहयोग पुर्‍याउने समर्पित टिम।'
              : 'The dedicated directors, accountants, and IT field technicians ensuring exceptional service delivery across Ramechhap since 2069 BS.'}
          </p>
        </div>
      </section>

      <TeamSection staffList={staff} />
    </div>
  );
}
