'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import ProductCard from '@/components/public/ProductCard';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import { Product } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import { Tag, Sparkles, ArrowRight } from 'lucide-react';

export default function OffersPage() {
  const { language, t } = useLanguage();
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);

  useEffect(() => {
    async function loadProducts() {
      try {
        const res = await fetch(`/api/products?t=${Date.now()}`, { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data.products && data.products.length > 0) {
            setProducts(data.products);
          }
        }
      } catch (err) {
        console.warn('Failed to load offers products:', err);
      }
    }
    loadProducts();
  }, []);

  const discountedProducts = products.filter(
    (p) => p.discount_price && p.discount_price < p.selling_price
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-red-600 via-rose-600 to-amber-600 rounded-3xl p-8 md:p-12 text-white shadow-lg mb-12">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-1.5 bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-4 backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>{language === 'ne' ? 'सिमित समयको अफर' : 'Limited-Time Specials'}</span>
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold mb-3">
            {language === 'ne'
              ? 'विशेष छुट र फेस्टिभल अफरहरू'
              : 'Exclusive Hardware & Surveillance Deals'}
          </h1>
          <p className="text-sm text-red-100 leading-relaxed mb-6">
            {language === 'ne'
              ? 'मन्थली, रामेछापस्थित हाम्रो स्टोरबाट सिधै भारी छुटमा कम्प्युटर, क्यामेरा र प्रिन्टरहरू खरिद गर्नुहोस्।'
              : 'Take advantage of discounted rates on genuine laptops, CCTV security bundles, and high-speed routers with verified warranties.'}
          </p>
          <a
            href="https://wa.me/9779854040821?text=Hello%20Numbur%20iT%20Solution,%20I%20am%20inquiring%20about%20your%20current%20special%20offers."
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 bg-white text-red-700 font-bold text-xs px-6 py-3 rounded-xl hover:bg-red-50 transition shadow"
          >
            <span>{language === 'ne' ? 'ह्वाट्सएपमा अफर बुझ्नुहोस्' : 'Inquire on WhatsApp'}</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* Discounted Product Grid */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-900 mb-6 flex items-center gap-2">
          <Tag className="w-5 h-5 text-red-600" />
          <span>{language === 'ne' ? 'छुट मूल्यमा उपलब्ध सामानहरू' : 'Discounted Products'}</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {discountedProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}
