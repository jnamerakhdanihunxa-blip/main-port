'use client';

import React, { useState } from 'react';
import { useLanguage } from '@/lib/i18n/context';
import { MapPin, Phone, Mail, Clock, MessageSquare, Send, CheckCircle2 } from 'lucide-react';

export default function ContactPage() {
  const { language, t } = useLanguage();
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    service: 'General Inquiry',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) return;

    // Build WhatsApp message for instant delivery
    const text = encodeURIComponent(
      `*NEW WEBSITE INQUIRY - NUMBUR iT*\nName: ${formData.name}\nPhone: ${formData.phone}\nEmail: ${formData.email || 'N/A'}\nSubject: ${formData.service}\nMessage: ${formData.message}`
    );
    window.open(`https://wa.me/9779854040821?text=${text}`, '_blank');
    setSubmitted(true);
  };

  return (
    <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-12">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-bold text-brand-600 dark:text-brand-300 uppercase tracking-wider bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800/60 px-3 py-1 rounded-full">
          {language === 'ne' ? 'हामीसँग सम्पर्क गर्नुहोस्' : 'Get in Touch'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mt-3">
          {t.nav.contact}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
          {language === 'ne'
            ? 'हाम्रो कार्यालय मन्थली-१ मा आइतबारदेखि शुक्रबारसम्म खुला रहन्छ।'
            : 'Visit our office in Manthali-1, call our customer desk, or chat directly via WhatsApp.'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
        {/* Left: Contact Info Cards */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4 transition-colors">
            <h2 className="font-bold text-lg text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3">
              Office Details
            </h2>

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-50 dark:bg-brand-950/80 border border-brand-100 dark:border-brand-800 flex items-center justify-center text-brand-600 dark:text-brand-400 shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <span className="font-bold text-slate-900 dark:text-white block mb-0.5">Physical Address</span>
                <span className="text-slate-600 dark:text-slate-300">
                  Manthali-1, Ramechhap, Bagmati Province, Nepal
                </span>
                <a
                  href="https://www.google.com/maps/place/Numbur+It+Solution+Pvt+Ltd/@27.382878,86.060467,18z"
                  target="_blank"
                  rel="noreferrer"
                  className="text-brand-600 dark:text-brand-400 font-semibold block mt-1 hover:underline"
                >
                  View on Google Maps →
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-50 dark:bg-brand-950/80 border border-brand-100 dark:border-brand-800 flex items-center justify-center text-brand-600 dark:text-brand-400 shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <span className="font-bold text-slate-900 dark:text-white block mb-0.5">Telephone & Mobile</span>
                <p className="text-slate-600 dark:text-slate-300">Landline: <a href="tel:048540314" className="hover:text-brand-600 dark:hover:text-brand-400 font-medium">048540314</a></p>
                <p className="text-slate-600 dark:text-slate-300">Mobile: <a href="tel:9854040821" className="hover:text-brand-600 dark:hover:text-brand-400 font-medium">9854040821</a> / <a href="tel:9846141110" className="hover:text-brand-600 dark:hover:text-brand-400 font-medium">9846141110</a></p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-50 dark:bg-brand-950/80 border border-brand-100 dark:border-brand-800 flex items-center justify-center text-brand-600 dark:text-brand-400 shrink-0">
                <Mail className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <span className="font-bold text-slate-900 dark:text-white block mb-0.5">Email Support</span>
                <a
                  href="mailto:numburitsolution1@gmail.com"
                  className="text-slate-600 dark:text-slate-300 hover:text-brand-600 dark:hover:text-brand-400"
                >
                  numburitsolution1@gmail.com
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-50 dark:bg-brand-950/80 border border-brand-100 dark:border-brand-800 flex items-center justify-center text-brand-600 dark:text-brand-400 shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <span className="font-bold text-slate-900 dark:text-white block mb-0.5">Store Working Hours</span>
                <p className="text-slate-600 dark:text-slate-300">Sun - Fri: 9:00 AM - 6:00 PM</p>
                <p className="text-red-500 font-semibold">Saturday: Closed</p>
              </div>
            </div>

            {/* Nationwide Delivery vs Manthali Services Scope */}
            <div className="p-4 bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl space-y-2 text-xs">
              <div className="flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-300">
                <span>🚚 Delivery System: Available All Over Nepal</span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                We deliver hardware equipment, CCTV, laptops, networking items, and accessories across all 77 districts of Nepal via our transport and courier partners.
              </p>
              <div className="pt-2 border-t border-emerald-200/60 dark:border-emerald-800/60 flex items-center gap-2 font-bold text-amber-800 dark:text-amber-300">
                <span>🛠️ Technical Services: Manthali-1, Ramechhap Only</span>
              </div>
              <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                On-site hardware repairs, CCTV installation, network cabling, and technician visits are exclusively offered within Manthali-1, Ramechhap.
              </p>
            </div>
          </div>

          {/* Quick WhatsApp Box */}
          <div className="bg-emerald-600 text-white p-6 rounded-3xl shadow-md">
            <h3 className="font-bold text-base mb-1 flex items-center gap-2">
              <MessageSquare className="w-5 h-5" />
              <span>Direct WhatsApp Chat</span>
            </h3>
            <p className="text-xs text-emerald-100 mb-4">
              Get an instant response from Mr. Niraz Sapkota or our technicians.
            </p>
            <a
              href="https://wa.me/9779854040821"
              target="_blank"
              rel="noreferrer"
              className="inline-block bg-white text-emerald-800 font-bold text-xs px-5 py-2.5 rounded-xl hover:bg-emerald-50 transition"
            >
              Start Chat (+977 9854040821)
            </a>
          </div>
        </div>

        {/* Right: Message Form */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 p-6 sm:p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm transition-colors">
          <h2 className="font-bold text-lg text-slate-900 dark:text-white mb-1">
            Send an Inquiry Message
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
            Fill in your requirements and we will review your request immediately.
          </p>

          {submitted ? (
            <div className="p-8 text-center space-y-3 bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 rounded-2xl">
              <CheckCircle2 className="w-10 h-10 text-emerald-600 dark:text-emerald-400 mx-auto" />
              <h3 className="font-bold text-base text-emerald-900 dark:text-emerald-200">
                Inquiry Message Generated!
              </h3>
              <p className="text-xs text-emerald-700 dark:text-emerald-300 max-w-sm mx-auto">
                Your message has been opened in WhatsApp. Please press Send in your WhatsApp app to complete communication.
              </p>
              <button
                type="button"
                onClick={() => setSubmitted(false)}
                className="text-xs font-semibold text-emerald-800 dark:text-emerald-300 underline mt-2"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    placeholder="Enter full name"
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) =>
                      setFormData({ ...formData, phone: e.target.value })
                    }
                    placeholder="e.g. 9854040821"
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Email Address (Optional)
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    placeholder="email@example.com"
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Subject / Service Interest
                  </label>
                  <select
                    value={formData.service}
                    onChange={(e) =>
                      setFormData({ ...formData, service: e.target.value })
                    }
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  >
                    <option value="CCTV Camera Installation">CCTV Camera Installation</option>
                    <option value="Laptop / Computer Repair">Laptop / Computer Repair</option>
                    <option value="Printer & Copier Service">Printer & Copier Service</option>
                    <option value="Networking & Wi-Fi Setup">Networking & Wi-Fi Setup</option>
                    <option value="Biometric Attendance Machine">Biometric Attendance Machine</option>
                    <option value="Inverter & Power Backup">Inverter & Power Backup</option>
                    <option value="General Inquiry">General Product Inquiry</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Message / Requirements
                </label>
                <textarea
                  rows={4}
                  required
                  value={formData.message}
                  onChange={(e) =>
                    setFormData({ ...formData, message: e.target.value })
                  }
                  placeholder="Describe your location, requirements or questions..."
                  className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs py-3 px-6 rounded-xl transition shadow"
              >
                <Send className="w-4 h-4" />
                <span>Submit Inquiry via WhatsApp</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
