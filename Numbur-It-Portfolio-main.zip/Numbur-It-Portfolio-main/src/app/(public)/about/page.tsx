'use client';

import React, { useState, useEffect } from 'react';
import SafeImage from '@/components/ui/SafeImage';
import Link from 'next/link';
import TeamSection, { AUDITED_STAFF_FALLBACK } from '@/components/public/TeamSection';
import { StaffProfile } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import { ShieldCheck, Award, MapPin, CheckCircle2, ArrowRight, Laptop } from 'lucide-react';

export default function AboutPage() {
  const { language, t } = useLanguage();
  const [staff, setStaff] = useState<StaffProfile[]>(AUDITED_STAFF_FALLBACK);
  const [aboutImage, setAboutImage] = useState<string>('');

  useEffect(() => {
    async function loadData() {
      try {
        const [contentRes, settingsRes] = await Promise.all([
          fetch('/api/content', { cache: 'no-store' }),
          fetch('/api/settings', { cache: 'no-store' }),
        ]);

        if (contentRes.ok) {
          const data = await contentRes.json();
          if (data.staff && data.staff.length > 0) {
            setStaff(data.staff);
          }
        }

        if (settingsRes.ok) {
          const sData = await settingsRes.json();
          if (sData.settings?.about_image_url) {
            setAboutImage(sData.settings.about_image_url);
          }
        }
      } catch (err) {
        console.warn('Failed to load about page data:', err);
      }
    }
    loadData();
  }, []);

  return (
    <div>
      {/* Hero Header */}
      <section className="bg-slate-900 dark:bg-slate-950 text-white py-16 transition-colors">
        <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 text-center max-w-3xl mx-auto">
          <span className="text-xs font-bold text-brand-400 uppercase tracking-wider bg-brand-500/20 border border-brand-400/40 px-3 py-1 rounded-full">
            {language === 'ne' ? 'हाम्रो परिचय' : 'About Numbur iT Solution'}
          </span>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold mt-4 mb-4">
            {language === 'ne'
              ? '२०६९ सालदेखि रामेछापमा सूचना प्रविधि विस्तारमा समर्पित'
              : 'Serving Ramechhap with Trusted IT Infrastructure Since 2069 BS'}
          </h1>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
            {language === 'ne'
              ? 'नम्बुर आइटी सोलुसन प्रा.लि. मन्थली-१ मा अवस्थित भरपर्दो प्रविधि तथा सीसीटीभी सुरक्षा प्रणाली सेवा प्रदायक कम्पनी हो।'
              : 'Numbur iT Solution Pvt. Ltd. is the premier technology partner for government offices, schools, commercial businesses, and households across Ramechhap and surrounding districts.'}
          </p>
        </div>
      </section>

      {/* Main Story Section */}
      <section className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left: Office & Store Photo */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-[4/3] rounded-3xl overflow-hidden shadow-xl border border-slate-200 dark:border-slate-800">
              <SafeImage
                src={aboutImage}
                alt="Numbur iT Solution Office"
                fill
                type="banner"
                fallbackIcon={
                  <div className="flex flex-col items-center justify-center p-8 text-center bg-gradient-to-br from-slate-900 via-brand-950 to-slate-900 w-full h-full text-white">
                    <div className="w-16 h-16 rounded-2xl bg-brand-600/30 border border-brand-400/40 flex items-center justify-center mb-4 text-brand-300">
                      <Laptop className="w-8 h-8" />
                    </div>
                    <h3 className="text-xl font-bold">Numbur iT Solution</h3>
                    <p className="text-xs text-slate-300 mt-1 max-w-xs">
                      Manthali-1, Ramechhap • Est. 2069 BS
                    </p>
                  </div>
                }
              />
            </div>
            {/* Experience Pill */}
            <div className="absolute -bottom-6 -right-4 bg-brand-600 text-white p-5 rounded-2xl shadow-xl flex items-center gap-3">
              <span className="text-3xl font-extrabold">10+</span>
              <span className="text-xs font-semibold uppercase leading-tight">
                Years of Local<br />Excellence
              </span>
            </div>
          </div>

          {/* Right: Story Details */}
          <div className="lg:col-span-6 space-y-5">
            <span className="text-xs font-bold text-brand-600 dark:text-brand-300 uppercase tracking-wider bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800/60 px-3 py-1 rounded-full">
              Who Are We?
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white leading-tight">
              {language === 'ne'
                ? 'हामी केवल विक्रेता होइनौं, तपाईंको प्रविधि साझेदार हौं'
                : 'More than a store — your complete technological foundation'}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {language === 'ne'
                ? 'नम्बुर आइटी सोलुसन २०६९ सालमा स्थापना भएको कम्पनी हो। हामीले रामेछापको मन्थलीमा आफ्नै भौतिक स्टोर सञ्चालन गरी कम्प्युटर, ल्यापटप, प्रिन्टर, फोटोकपी मेसिन, प्रोजेक्टर, अडियो भिजुअल, इन्भर्टर तथा सीसीटीभी निगरानी प्रणाली उपलब्ध गराउँदै आएका छौं।'
                : 'Founded in 2069 BS in Manthali-1, Ramechhap, Numbur iT Solution Pvt. Ltd. was built with a vision to bring cutting-edge hardware, enterprise network security, and prompt on-site technical support to our mountainous region.'}
            </p>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {language === 'ne'
                ? 'हाम्रा दक्ष प्राविधिकहरूले रामेछापका गाडी चल्ने जुनसुकै स्थानमा पुगेर सीसीटीभी क्यामेरा जडान, नेटवर्क वायरिङ र कम्प्युटर मर्मत गर्ने गर्दछन्।'
                : 'Our certified engineers and support staff travel directly to your location anywhere road access is available to inspect, install, and service hardware. We back every product with authentic brand warranties and fast turnaround times.'}
            </p>

            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="font-semibold text-slate-800 dark:text-slate-200">Physical Store in Manthali</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="font-semibold text-slate-800 dark:text-slate-200">100% Genuine Brand Sourcing</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="font-semibold text-slate-800 dark:text-slate-200">On-Site & Remote Desk Help</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span className="font-semibold text-slate-800 dark:text-slate-200">Transparent WhatsApp Ordering</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership & Staff */}
      <TeamSection staffList={staff} />

      {/* Store Location Map CTA */}
      <section className="bg-white dark:bg-slate-900 py-16 border-t border-slate-200 dark:border-slate-800 transition-colors">
        <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 text-center max-w-2xl mx-auto">
          <MapPin className="w-10 h-10 text-brand-600 dark:text-brand-400 mx-auto mb-3" />
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">
            Visit Our Manthali Store
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
            Located conveniently in Manthali-1, Ramechhap. Open Sunday through Friday from 9:00 AM to 6:00 PM.
          </p>
          <a
            href="https://www.google.com/maps/place/Numbur+It+Solution+Pvt+Ltd/@27.382878,86.060467,18z"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs px-6 py-3 rounded-xl transition shadow"
          >
            <span>Open in Google Maps</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </section>
    </div>
  );
}
