'use client';

import React, { useState, useEffect } from 'react';
import SafeImage from '@/components/ui/SafeImage';
import { useLanguage } from '@/lib/i18n/context';
import { INITIAL_GALLERY } from '@/lib/gallery-data';
import { Eye, X, Camera } from 'lucide-react';

export default function GalleryPage() {
  const { language, t } = useLanguage();
  const [gallery, setGallery] = useState(INITIAL_GALLERY);
  const [activeImage, setActiveImage] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  useEffect(() => {
    async function loadGallery() {
      try {
        const res = await fetch('/api/content', { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data.gallery && data.gallery.length > 0) {
            setGallery(data.gallery);
          }
        }
      } catch (err) {
        console.warn('Failed to load live gallery:', err);
      }
    }
    loadGallery();
  }, []);

  const filteredImages =
    activeCategory === 'all'
      ? gallery
      : gallery.filter((img) => img.category === activeCategory);

  const categories = ['all', 'Store', 'Workplace', 'Installations', 'Equipment', 'Networking'];

  return (
    <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-12">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-xs font-bold text-brand-600 dark:text-brand-400 uppercase tracking-wider bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800/70 px-3 py-1 rounded-full">
          {language === 'ne' ? 'हाम्रा तस्बिरहरू' : 'Visual Showcase'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mt-3">
          {t.nav.gallery}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
          {language === 'ne'
            ? 'मन्थली, रामेछापस्थित हाम्रो स्टोर, मर्मत कार्यशाला तथा ग्राहक सेवाका तस्बिरहरू।'
            : 'A glimpse into our Manthali office, hardware laboratory, CCTV field installations, and equipment inventory.'}
        </p>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {categories.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setActiveCategory(cat)}
            className={`text-xs font-semibold px-4 py-2 rounded-xl transition ${
              activeCategory === cat
                ? 'bg-brand-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
            }`}
          >
            {cat === 'all' ? 'All Photos' : cat}
          </button>
        ))}
      </div>

      {/* Image Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6">
        {filteredImages.map((img) => (
          <div
            key={img.id}
            onClick={() => img.url && setActiveImage(img.url)}
            className={`group relative aspect-[4/3] rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-900 shadow-sm hover:shadow-lg transition-all border border-slate-200 dark:border-slate-800 ${
              img.url ? 'cursor-pointer' : 'cursor-default'
            }`}
          >
            <SafeImage
              src={img.url}
              alt={img.title}
              fill
              type="gallery"
              sizes="(max-width: 768px) 100vw, 33vw"
              className="object-cover group-hover:scale-105 transition-transform duration-300"
              fallbackIcon={
                <div className="flex flex-col items-center justify-center p-6 text-center text-slate-400 dark:text-slate-500 w-full h-full bg-slate-50 dark:bg-slate-900">
                  <Camera className="w-8 h-8 mb-2 text-brand-600 dark:text-brand-400 opacity-60" />
                  <span className="font-bold text-xs text-slate-700 dark:text-slate-200">{img.title}</span>
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 mt-1 uppercase tracking-wider font-semibold">
                    {img.category}
                  </span>
                </div>
              }
            />
            {img.url && (
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4 text-white">
                <span className="text-[10px] uppercase font-bold text-brand-300">
                  {img.category}
                </span>
                <p className="font-semibold text-sm leading-snug">{img.title}</p>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      {activeImage && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setActiveImage(null)}
        >
          <div
            className="relative max-w-4xl w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setActiveImage(null)}
              className="absolute top-4 right-4 z-10 p-2 bg-slate-900/80 text-white rounded-full hover:bg-white hover:text-black transition"
            >
              <X className="w-5 h-5" />
            </button>
            <SafeImage
              src={activeImage}
              alt="Enlarged gallery view"
              fill
              type="gallery"
              className="object-contain"
            />
          </div>
        </div>
      )}
    </div>
  );
}
