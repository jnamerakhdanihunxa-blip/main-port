'use client';

import React from 'react';
import Link from 'next/link';
import { useLanguage } from '@/lib/i18n/context';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

const BRANDS = [
  { name: 'Dell', slug: 'dell', desc: 'World-renowned laptops, business desktops, and enterprise workstations.' },
  { name: 'HP', slug: 'hp', desc: 'Multifunction LaserJet printers, toner supplies, and ProBook laptops.' },
  { name: 'EZVIZ', slug: 'ezviz', desc: 'Smart wireless security cameras, motorized pan-tilt, and home safety.' },
  { name: 'Hikvision', slug: 'hikvision', desc: 'Enterprise video surveillance, Turbo HD DVRs, and NVR security systems.' },
  { name: 'Dahua', slug: 'dahua', desc: 'Professional surveillance cameras, IP network recorders, and security tech.' },
  { name: 'Canon', slug: 'canon', desc: 'Commercial heavy-duty photocopiers, scanners, and high-yield ink printers.' },
  { name: 'Epson', slug: 'epson', desc: 'EcoTank economical color printers, replacement inks, and projectors.' },
  { name: 'TP-Link', slug: 'tp-link', desc: 'Gigabit dual-band WiFi routers, PoE network switches, and range extenders.' },
];

export default function BrandsPage() {
  const { language, t } = useLanguage();

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-bold text-brand-600 uppercase tracking-wider bg-brand-50 border border-brand-200 px-3 py-1 rounded-full">
          {language === 'ne' ? 'आधिकारिक ब्रान्डहरू' : 'Authorized Brands'}
        </span>
        <h1 className="text-3xl font-extrabold text-slate-900 mt-3">
          {t.nav.brands}
        </h1>
        <p className="text-sm text-slate-500 mt-2">
          {language === 'ne'
            ? 'हामी १००% सक्कली ब्रान्डका कम्प्युटर, क्यामेरा र नेटवर्किङ उपकरणहरू मात्र उपलब्ध गराउँछौं।'
            : 'We partner with genuine international brands to provide authentic hardware with official warranties.'}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {BRANDS.map((brand) => (
          <Link
            key={brand.slug}
            href={`/products?brand=${encodeURIComponent(brand.name)}`}
            className="group bg-white rounded-3xl p-6 border border-slate-200/90 shadow-sm hover:shadow-md hover:border-brand-300 transition-all flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-brand-50 border border-brand-100 flex items-center justify-center font-black text-xl text-brand-700 mb-4 group-hover:scale-105 transition-transform">
                {brand.name.charAt(0)}
              </div>
              <h2 className="font-bold text-lg text-slate-900 group-hover:text-brand-600 transition-colors mb-2">
                {brand.name}
              </h2>
              <p className="text-xs text-slate-500 leading-relaxed mb-4">
                {brand.desc}
              </p>
            </div>

            <div className="flex items-center gap-1.5 text-xs font-semibold text-brand-600 pt-3 border-t border-slate-100">
              <span>{language === 'ne' ? 'सामानहरू हेर्नुहोस्' : 'View Products'}</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
