'use client';

import React from 'react';

export default function WarrantyReturnPolicyPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6">
      <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200/90 shadow-sm space-y-6 text-slate-800">
        <h1 className="text-3xl font-extrabold text-slate-900 border-b border-slate-200 pb-4">
          Warranty & Return Policy
        </h1>
        <p className="text-xs text-slate-500">
          Numbur iT Solution Pvt. Ltd. (Manthali-1, Ramechhap)
        </p>

        <section className="space-y-3 text-sm leading-relaxed">
          <h2 className="text-lg font-bold text-slate-900">1. Genuine Warranty Coverage</h2>
          <p>
            Hardware products that explicitly mention warranty information (such as 1 Year Brand Replacement or Comprehensive Hardware Warranty) are serviced directly through our authorized brand partners or our certified technician workbench in Manthali.
          </p>
          <p>
            Products without an explicit warranty statement are sold tested and verified at dispatch, but do not carry post-delivery replacement guarantees.
          </p>
        </section>

        <section className="space-y-3 text-sm leading-relaxed">
          <h2 className="text-lg font-bold text-slate-900">2. Warranty Exclusions</h2>
          <p>
            Warranty claims are void in the event of:
          </p>
          <ul className="list-disc pl-5 space-y-1 text-slate-600">
            <li>Physical damage, water damage, burns, or cracked screens.</li>
            <li>Damage resulting from lightning strikes, power surges, or incorrect voltage.</li>
            <li>Unauthorized tampering or third-party repair attempts.</li>
          </ul>
        </section>

        <section className="space-y-3 text-sm leading-relaxed">
          <h2 className="text-lg font-bold text-slate-900">3. Return & Replacement Process</h2>
          <p>
            If a brand-new item arrives non-functional (dead on arrival), you must notify our office within 48 hours with your order receipt. Once inspected by our technicians, an immediate replacement or store credit will be arranged.
          </p>
        </section>
      </div>
    </div>
  );
}
