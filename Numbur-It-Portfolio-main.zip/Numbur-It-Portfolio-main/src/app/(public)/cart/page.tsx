'use client';

import React from 'react';
import Link from 'next/link';
import SafeImage from '@/components/ui/SafeImage';
import WhatsAppCheckoutModal from '@/components/public/WhatsAppCheckoutModal';
import { useCart } from '@/lib/cart/context';
import { useLanguage } from '@/lib/i18n/context';
import { Trash2, ArrowRight, ShoppingBag, ArrowLeft } from 'lucide-react';

export default function CartPage() {
  const { items, updateQuantity, removeFromCart, clearCart, subtotal, totalItems } =
    useCart();
  const { language, t } = useLanguage();
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = React.useState(false);

  if (items.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-12 border border-slate-200 dark:border-slate-800 shadow-sm max-w-md mx-auto space-y-4 transition-colors">
          <div className="w-16 h-16 bg-brand-50 dark:bg-brand-950/60 text-brand-600 dark:text-brand-400 rounded-full flex items-center justify-center mx-auto border border-brand-100 dark:border-brand-800">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {t.cart.emptyTitle}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {t.cart.emptySubtitle}
          </p>
          <Link
            href="/products"
            className="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white font-bold text-xs px-6 py-3 rounded-xl transition shadow"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>{language === 'ne' ? 'सामानहरू हेर्नुहोस्' : 'Browse Products'}</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-8">
      <div className="flex justify-between items-center mb-8 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            {t.cart.title}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {totalItems} {t.cart.itemsCount}
          </p>
        </div>
        <button
          type="button"
          onClick={clearCart}
          className="text-xs font-semibold text-red-600 dark:text-red-400 hover:text-red-800 dark:hover:text-red-300"
        >
          {t.cart.clearCart}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Cart Items List */}
        <div className="lg:col-span-8 space-y-4">
          {items.map((item) => {
            const title =
              language === 'ne' && item.product.name_ne
                ? item.product.name_ne
                : item.product.name_en;

            return (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 border border-slate-200/90 dark:border-slate-800 shadow-sm flex items-center gap-4 transition-colors"
              >
                {/* Image */}
                <div className="relative w-20 h-20 bg-slate-50 dark:bg-slate-800 rounded-xl overflow-hidden shrink-0 border border-slate-100 dark:border-slate-700 p-2">
                  <SafeImage
                    src={item.product.primary_image_url}
                    alt={title}
                    fill
                    type="product"
                    sizes="80px"
                    className="object-contain"
                  />
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 block">
                    SKU: {item.product.sku}
                  </span>
                  <Link
                    href={`/products/${item.product.slug}`}
                    className="font-bold text-sm text-slate-900 dark:text-white hover:text-brand-600 dark:hover:text-brand-400 transition-colors line-clamp-1"
                  >
                    {title}
                  </Link>
                  <p className="text-xs font-extrabold text-slate-800 dark:text-slate-200 mt-1">
                    {t.common.currency} {item.selectedPrice.toLocaleString('en-IN')}
                  </p>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center border border-slate-200 dark:border-slate-700 rounded-lg bg-slate-50 dark:bg-slate-800 overflow-hidden">
                  <button
                    type="button"
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    className="px-2.5 py-1 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold"
                  >
                    -
                  </button>
                  <span className="px-3 py-1 text-xs font-bold text-slate-900 dark:text-white bg-white dark:bg-slate-900">
                    {item.quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    className="px-2.5 py-1 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 text-xs font-bold"
                  >
                    +
                  </button>
                </div>

                {/* Total & Remove */}
                <div className="text-right shrink-0">
                  <p className="font-extrabold text-sm text-slate-900 dark:text-white">
                    {t.common.currency}{' '}
                    {(item.selectedPrice * item.quantity).toLocaleString('en-IN')}
                  </p>
                  <button
                    type="button"
                    onClick={() => removeFromCart(item.id)}
                    className="text-slate-400 dark:text-slate-500 hover:text-red-600 dark:hover:text-red-400 transition p-1 mt-1"
                    aria-label="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Order Summary Sidebar */}
        <div className="lg:col-span-4">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/90 dark:border-slate-800 shadow-sm space-y-5 sticky top-24 transition-colors">
            <h2 className="font-bold text-base text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-3">
              {t.cart.orderSummary}
            </h2>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-600 dark:text-slate-300">
                <span>{t.common.subtotal}</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {t.common.currency} {subtotal.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between text-slate-600 dark:text-slate-300">
                <span>Estimated Delivery</span>
                <span className="text-slate-500 dark:text-slate-400 italic">Confirmed on WhatsApp</span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-between items-baseline">
              <span className="font-extrabold text-sm text-slate-900 dark:text-white">{t.common.total}</span>
              <span className="text-2xl font-black text-brand-600 dark:text-brand-400">
                {t.common.currency} {subtotal.toLocaleString('en-IN')}
              </span>
            </div>

            <button
              type="button"
              onClick={() => setIsCheckoutModalOpen(true)}
              className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-3.5 px-6 rounded-xl transition shadow-md"
            >
              <span>{t.cart.proceedToCheckout}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 text-center leading-relaxed">
              Order directly via our verified Manthali WhatsApp desk. No online credit card needed.
            </p>
          </div>
        </div>
      </div>

      {/* WhatsApp Checkout Customer Details Modal */}
      <WhatsAppCheckoutModal
        isOpen={isCheckoutModalOpen}
        onClose={() => setIsCheckoutModalOpen(false)}
      />
    </div>
  );
}
