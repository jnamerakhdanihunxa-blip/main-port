'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import HeroSection, { FALLBACK_BANNERS } from '@/components/public/HeroSection';
import CategoryGrid, { FALLBACK_CATEGORIES } from '@/components/public/CategoryGrid';
import ProductCard from '@/components/public/ProductCard';
import ServicesSection, { AUDITED_SERVICES_FALLBACK } from '@/components/public/ServicesSection';
import TeamSection, { AUDITED_STAFF_FALLBACK } from '@/components/public/TeamSection';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import { Product, SiteBanner, Category, ServiceItem, StaffProfile } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import { ArrowRight, Shield, Award, Clock, MapPin, Phone, Mail, Video } from 'lucide-react';

export default function HomePage() {
  const { language, t } = useLanguage();
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [banners, setBanners] = useState<SiteBanner[]>(FALLBACK_BANNERS);
  const [categories, setCategories] = useState<Category[]>(FALLBACK_CATEGORIES);
  const [services, setServices] = useState<ServiceItem[]>(AUDITED_SERVICES_FALLBACK);
  const [staff, setStaff] = useState<StaffProfile[]>(AUDITED_STAFF_FALLBACK);

  useEffect(() => {
    async function loadLiveData() {
      try {
        const [prodResult, contentResult, catResult] = await Promise.allSettled([
          fetch(`/api/products?t=${Date.now()}`, { cache: 'no-store' }),
          fetch(`/api/content?t=${Date.now()}`, { cache: 'no-store' }),
          fetch(`/api/categories?t=${Date.now()}`, { cache: 'no-store' }),
        ]);

        if (prodResult.status === 'fulfilled' && prodResult.value.ok) {
          const pData = await prodResult.value.json();
          if (pData.products && pData.products.length > 0) {
            setProducts(pData.products);
          }
        }

        if (contentResult.status === 'fulfilled' && contentResult.value.ok) {
          const cData = await contentResult.value.json();
          if (cData.banners && cData.banners.length > 0) {
            setBanners(cData.banners);
          }
          if (cData.services && cData.services.length > 0) {
            setServices(cData.services);
          }
          if (cData.staff && cData.staff.length > 0) {
            setStaff(cData.staff);
          }
        }

        if (catResult.status === 'fulfilled' && catResult.value.ok) {
          const catData = await catResult.value.json();
          if (catData.categories && catData.categories.length > 0) {
            setCategories(catData.categories);
          }
        }
      } catch (err) {
        console.warn('Failed to load live homepage data:', err);
      }
    }
    loadLiveData();
  }, []);

  const featuredProducts = products.filter((p) => p.is_featured);
  const newArrivals = products.filter((p) => p.is_new_arrival);
  const bestSellers = products.filter((p) => p.is_bestseller);

  return (
    <div className="space-y-12">
      {/* 1. Hero Section */}
      <HeroSection banners={banners} />

      {/* 2. Dynamic Categories */}
      <CategoryGrid categories={categories} />

      {/* 3. Featured Products */}
      <section className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-8 gap-4">
          <div>
            <span className="text-xs font-bold text-brand-600 dark:text-brand-300 uppercase tracking-wider bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800/60 px-3 py-1 rounded-full">
              {language === 'ne' ? 'छानिएका सामानहरू' : 'Handpicked Technology'}
            </span>
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white mt-2">
              {t.home.featuredTitle}
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.home.featuredSubtitle}
            </p>
          </div>
          <Link
            href="/products?filter=featured"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand-600 dark:text-brand-400 hover:text-brand-700 dark:hover:text-brand-300 transition"
          >
            <span>{language === 'ne' ? 'सबै हेर्नुहोस्' : 'View All Featured'}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
          {featuredProducts.slice(0, 10).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 4. Promotional Banner (Middle Highlight) - Clean White in Light Theme, Dark Slate in Dark Theme */}
      <section className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16">
        <div className="relative rounded-3xl overflow-hidden bg-white dark:bg-slate-900 text-slate-900 dark:text-white p-8 md:p-12 border border-slate-200/90 dark:border-slate-800 shadow-lg dark:shadow-2xl transition-colors duration-200">
          {/* Subtle background texture */}
          <div className="absolute inset-0 bg-[radial-gradient(#1877f2_1.2px,transparent_1.2px)] [background-size:24px_24px] opacity-10 dark:opacity-20 pointer-events-none" />
          <div className="absolute right-0 top-0 bottom-0 w-1/2 bg-gradient-to-l from-brand-50/60 via-transparent to-transparent dark:from-brand-950/30 dark:via-transparent dark:to-transparent pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Column: Heading & CTAs */}
            <div className="lg:col-span-6 space-y-4">
              <span className="inline-flex items-center gap-2 bg-brand-50 dark:bg-brand-950/80 text-brand-700 dark:text-brand-300 border border-brand-200 dark:border-brand-500/40 text-xs font-bold px-3.5 py-1.5 rounded-full uppercase tracking-wider shadow-xs">
                <Shield className="w-3.5 h-3.5 text-brand-500 dark:text-brand-400" />
                <span>{language === 'ne' ? 'सीसीटीभी सुरक्षा विशेष' : 'Special Security Package'}</span>
              </span>
              <h3 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight">
                {language === 'ne'
                  ? 'तपाईंको घर तथा पसलको सुरक्षा हाम्रो जिम्मा'
                  : 'Protect Your Premises with Smart HD Surveillance'}
              </h3>
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed max-w-xl">
                {language === 'ne'
                  ? 'हामी १० वर्षदेखि रामेछापमा विभिन्न ब्रान्डका क्यामेराहरू सुलभ दरमा जडान तथा मर्मत गर्दै आइरहेका छौं। मोबाइलबाटै लाइभ हेर्ने सुविधा र स्थानीय वारेन्टी।'
                  : 'Certified wireless WiFi & wired IP CCTV systems with live mobile remote monitoring, 1-year replacement warranty, and local on-site installation in Manthali.'}
              </p>
              <div className="flex flex-wrap gap-3 pt-2">
                <Link
                  href="/categories/cctv-security"
                  className="bg-brand-500 hover:bg-brand-600 text-white font-extrabold text-sm px-6 py-3 rounded-xl transition shadow-md hover:shadow-lg active:scale-95 flex items-center gap-2"
                >
                  <span>{language === 'ne' ? 'क्यामेरा प्याकेज हेर्नुहोस्' : 'Explore Camera Packages'}</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  href="/contact"
                  className="bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 font-bold text-sm px-5 py-3 rounded-xl transition"
                >
                  {language === 'ne' ? 'नि:शुल्क परामर्श' : 'Free Consultation'}
                </Link>
              </div>
            </div>

            {/* Right Column: Feature Cards Grid (Clean White/Slate Cards) */}
            <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 p-4 rounded-2xl flex items-start gap-3 shadow-xs">
                <div className="w-10 h-10 rounded-xl bg-brand-50 dark:bg-brand-500/20 border border-brand-200 dark:border-brand-500/40 flex items-center justify-center text-brand-600 dark:text-brand-400 shrink-0">
                  <Video className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900 dark:text-white">360° Color Night Vision</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-snug">Full HD live surveillance day & night with crystal audio</p>
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 p-4 rounded-2xl flex items-start gap-3 shadow-xs">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-500/20 border border-emerald-200 dark:border-emerald-500/40 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
                  <Shield className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900 dark:text-white">AI Motion Detection</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-snug">Real-time smartphone alerts & active defense strobe</p>
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 p-4 rounded-2xl flex items-start gap-3 shadow-xs">
                <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-500/20 border border-amber-200 dark:border-amber-500/40 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900 dark:text-white">1-Year Brand Warranty</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-snug">Genuine Hikvision & EZVIZ replacement backing</p>
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 p-4 rounded-2xl flex items-start gap-3 shadow-xs">
                <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-500/20 border border-blue-200 dark:border-blue-500/40 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900 dark:text-white">On-Site Manthali Setup</h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 leading-snug">Professional field technician cabling & support</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Best Sellers & New Arrivals */}
      <section className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 space-y-12">
        {/* Best Sellers */}
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
              {t.home.bestSellers}
            </h2>
            <Link
              href="/products?filter=bestseller"
              className="text-xs font-semibold text-brand-600 dark:text-brand-400 hover:text-brand-700 dark:hover:text-brand-300 flex items-center gap-1"
            >
              <span>{language === 'ne' ? 'थप हेर्नुहोस्' : 'See More'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
            {bestSellers.slice(0, 5).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>

        {/* New Arrivals */}
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
              {t.home.newArrivals}
            </h2>
            <Link
              href="/products?filter=new"
              className="text-xs font-semibold text-brand-600 dark:text-brand-400 hover:text-brand-700 dark:hover:text-brand-300 flex items-center gap-1"
            >
              <span>{language === 'ne' ? 'थप हेर्नुहोस्' : 'See More'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 sm:gap-6">
            {newArrivals.slice(0, 5).map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* 6. Professional Services Section */}
      <ServicesSection services={services} limit={8} />

      {/* 7. Why Choose Us / Trust Badges */}
      <section className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 md:p-12 border border-slate-200/90 dark:border-slate-800 shadow-sm transition-colors">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold text-brand-600 dark:text-brand-300 uppercase tracking-wider bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800/60 px-3 py-1 rounded-full">
              {language === 'ne' ? 'हाम्रो प्रतिबद्धता' : 'Our Commitment'}
            </span>
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white mt-2">
              {t.home.whyChooseUs}
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.home.customerTrust}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center p-4">
              <div className="w-14 h-14 rounded-2xl bg-blue-50 dark:bg-blue-950/60 border border-blue-100 dark:border-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400 mb-4">
                <MapPin className="w-7 h-7" />
              </div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white mb-2">
                {t.home.why1Title}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {t.home.why1Desc}
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-4">
              <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-100 dark:border-emerald-900/50 flex items-center justify-center text-emerald-600 dark:text-emerald-400 mb-4">
                <Award className="w-7 h-7" />
              </div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white mb-2">
                {t.home.why2Title}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {t.home.why2Desc}
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-50 dark:bg-amber-950/60 border border-amber-100 dark:border-amber-900/50 flex items-center justify-center text-amber-600 dark:text-amber-400 mb-4">
                <Clock className="w-7 h-7" />
              </div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white mb-2">
                {t.home.why3Title}
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {t.home.why3Desc}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Staff / Our Team Section (Near Bottom) */}
      <TeamSection staffList={staff} />

      {/* 9. Contact Summary & Quick Call */}
      <section className="bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-white py-12 border-t border-slate-200 dark:border-slate-800/80 transition-colors">
        <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">
              {language === 'ne'
                ? 'के तपाईंलाई कुनै आइटी सहयोग वा परामर्श चाहिन्छ?'
                : 'Need immediate hardware assistance or technical guidance?'}
            </h3>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              {language === 'ne'
                ? 'हाम्रो कार्यालय मन्थली-१ मा आइतबारदेखि शुक्रबारसम्म खुला रहन्छ।'
                : 'Visit our store in Manthali-1 or call our technical team directly.'}
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <a
              href="tel:048540314"
              className="bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs px-5 py-3 rounded-xl flex items-center gap-2 transition shadow-xs"
            >
              <Phone className="w-4 h-4" />
              <span>Call: 048-540314</span>
            </a>
            <a
              href="https://wa.me/9779854040821"
              target="_blank"
              rel="noreferrer"
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-5 py-3 rounded-xl flex items-center gap-2 transition shadow-xs"
            >
              <span>WhatsApp Direct</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
