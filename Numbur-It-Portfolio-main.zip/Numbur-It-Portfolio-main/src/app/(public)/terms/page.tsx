'use client';

import React from 'react';

export default function TermsPage() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6">
      <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200/90 shadow-sm space-y-6 text-slate-800">
        <h1 className="text-3xl font-extrabold text-slate-900 border-b border-slate-200 pb-4">
          Terms & Conditions
        </h1>
        <p className="text-xs text-slate-500">
          Numbur iT Solution Pvt. Ltd. • Registered in Nepal (Regd. 2069 BS)
        </p>

        <section className="space-y-3 text-sm leading-relaxed">
          <h2 className="text-lg font-bold text-slate-900">1. Order Placement & WhatsApp Confirmation</h2>
          <p>
            Placing an order on this website generates an official order number and opens WhatsApp with your itemized summary. Opening WhatsApp does not mean your order is automatically confirmed or shipped. An order is confirmed only after direct consultation with our staff and receipt of any required advance payment.
          </p>
        </section>

        <section className="space-y-3 text-sm leading-relaxed">
          <h2 className="text-lg font-bold text-slate-900">2. Delivery Feasibility within Ramechhap</h2>
          <p>
            We offer direct delivery within Ramechhap strictly to areas with accessible motor vehicle roads. Due to geographic and weather conditions, feasibility and applicable delivery transport charges will be communicated transparently by our team before dispatch. Store pickup at our Manthali-1 office is always free of delivery charges.
          </p>
        </section>

        <section className="space-y-3 text-sm leading-relaxed">
          <h2 className="text-lg font-bold text-slate-900">3. Pricing & Product Availability</h2>
          <p>
            All catalog prices are listed in Nepalese Rupees (Rs.). While we strive for absolute accuracy, prices and stock availability are verified authoritatively on our server at checkout time.
          </p>
        </section>
      </div>
    </div>
  );
}
