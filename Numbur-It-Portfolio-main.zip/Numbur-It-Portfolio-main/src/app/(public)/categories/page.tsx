'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import SafeImage from '@/components/ui/SafeImage';
import { FALLBACK_CATEGORIES } from '@/components/public/CategoryGrid';
import { Category } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import {
  ArrowRight,
  Video,
  Laptop,
  Printer,
  Wifi,
  Zap,
  FileSpreadsheet,
  Layers,
} from 'lucide-react';

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  'cctv-security': <Video className="w-16 h-16 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
  'laptops-computers': <Laptop className="w-16 h-16 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
  'printers-copiers': <Printer className="w-16 h-16 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
  'networking-solutions': <Wifi className="w-16 h-16 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
  'power-backup': <Zap className="w-16 h-16 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
  'office-automation': <FileSpreadsheet className="w-16 h-16 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
};

export default function CategoriesPage() {
  const { language, t } = useLanguage();
  const [categories, setCategories] = useState<Category[]>(FALLBACK_CATEGORIES);

  useEffect(() => {
    async function loadCategories() {
      try {
        const res = await fetch('/api/categories', { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data.categories && data.categories.length > 0) {
            setCategories(data.categories);
          }
        }
      } catch (err) {
        console.warn('Failed to load categories:', err);
      }
    }
    loadCategories();
  }, []);

  return (
    <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-12">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-bold text-brand-600 dark:text-brand-400 uppercase tracking-wider bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800/70 px-3 py-1 rounded-full">
          {language === 'ne' ? 'सबै वर्गहरू' : 'All Categories'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white mt-3">
          {t.nav.categories}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
          {language === 'ne'
            ? 'हाम्रा विभिन्न श्रेणीका आईटी उपकरण तथा सीसीटीभी सुरक्षा प्रणालीहरू अन्वेषण गर्नुहोस्।'
            : 'Explore enterprise hardware, CCTV security systems, laptops, and networking solutions available in Ramechhap.'}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6">
        {categories.map((cat) => {
          const name =
            language === 'ne' && cat.name_ne ? cat.name_ne : cat.name_en;
          const desc =
            language === 'ne' && cat.description_ne
              ? cat.description_ne
              : cat.description_en;
          const customIcon = CATEGORY_ICONS[cat.slug] || (
            <Layers className="w-16 h-16 text-brand-500 dark:text-brand-400 stroke-[1.75]" />
          );

          return (
            <Link
              key={cat.id}
              href={`/categories/${cat.slug}`}
              className="group bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200/90 dark:border-slate-800 shadow-sm hover:shadow-md hover:border-brand-500/60 dark:hover:border-brand-500/60 transition-all flex flex-col justify-between"
            >
              <div>
                <div
                  className={`relative w-full h-48 rounded-2xl overflow-hidden mb-4 ${
                    cat.image_url
                      ? 'bg-transparent border border-slate-200/60 dark:border-slate-800'
                      : 'bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-700/60'
                  } flex items-center justify-center transition-all`}
                >
                  {cat.image_url ? (
                    <SafeImage
                      src={cat.image_url}
                      alt={name}
                      fill
                      type="category"
                      sizes="(max-width: 768px) 100vw, 33vw"
                      className="object-cover w-full h-full p-0 group-hover:scale-105 transition-transform duration-500"
                      fallbackIcon={customIcon}
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-gradient-to-b from-blue-50/70 to-brand-50/30 dark:from-slate-800/90 dark:to-slate-900/60">
                      <div className="group-hover:scale-110 transition-transform duration-300">
                        {customIcon}
                      </div>
                    </div>
                  )}
                </div>
                <h2 className="font-bold text-lg text-slate-900 dark:text-white group-hover:text-brand-500 dark:group-hover:text-brand-400 transition-colors mb-2">
                  {name}
                </h2>
                {desc && (
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed line-clamp-2 mb-4">
                    {desc}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-1.5 text-xs font-semibold text-brand-500 dark:text-brand-400 pt-3 border-t border-slate-100 dark:border-slate-800">
                <span>{language === 'ne' ? 'सामानहरू हेर्नुहोस्' : 'Browse Products'}</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
