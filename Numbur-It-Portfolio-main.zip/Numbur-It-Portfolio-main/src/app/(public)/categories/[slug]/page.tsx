'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { notFound, useParams } from 'next/navigation';
import ProductCard from '@/components/public/ProductCard';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import { FALLBACK_CATEGORIES } from '@/components/public/CategoryGrid';
import { Product, Category } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import { ChevronRight, ArrowLeft } from 'lucide-react';

export default function CategoryDetailPage() {
  const { slug } = useParams();
  const { language } = useLanguage();

  const [categories, setCategories] = useState<Category[]>(FALLBACK_CATEGORIES);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function loadData() {
      try {
        const [catRes, prodRes] = await Promise.all([
          fetch(`/api/categories?t=${Date.now()}`, { cache: 'no-store' }),
          fetch(`/api/products?t=${Date.now()}`, { cache: 'no-store' }),
        ]);

        if (catRes.ok) {
          const cData = await catRes.json();
          if (cData.categories && cData.categories.length > 0) {
            setCategories(cData.categories);
          }
        }

        if (prodRes.ok) {
          const pData = await prodRes.json();
          if (pData.products && pData.products.length > 0) {
            setProducts(pData.products);
          }
        }
      } catch (err) {
        console.warn('Failed to load category products:', err);
      }
    }
    loadData();
  }, []);

  const category = categories.find((c) => c.slug === slug);
  if (!category && !loading) {
    // If not in state yet, check fallback before throwing 404
    const fallback = FALLBACK_CATEGORIES.find((c) => c.slug === slug);
    if (!fallback) {
      notFound();
    }
  }

  const currentCat = category || FALLBACK_CATEGORIES.find((c) => c.slug === slug)!;

  const name =
    language === 'ne' && currentCat.name_ne ? currentCat.name_ne : currentCat.name_en;
  const desc =
    language === 'ne' && currentCat.description_ne
      ? currentCat.description_ne
      : currentCat.description_en;

  const categoryProducts = products.filter(
    (p) => p.category?.slug === slug || p.category_id === currentCat.id
  );

  return (
    <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-8">
      {/* Breadcrumbs */}
      <nav className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400 mb-6">
        <Link href="/" className="hover:text-brand-600 dark:hover:text-brand-400">
          Home
        </Link>
        <ChevronRight className="w-3 h-3 text-slate-400 dark:text-slate-600" />
        <Link href="/categories" className="hover:text-brand-600 dark:hover:text-brand-400">
          Categories
        </Link>
        <ChevronRight className="w-3 h-3 text-slate-400 dark:text-slate-600" />
        <span className="text-slate-800 dark:text-slate-200 font-semibold">{name}</span>
      </nav>

      {/* Category Header */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200 dark:border-slate-800 shadow-sm mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mb-2">
          {name}
        </h1>
        {desc && <p className="text-sm text-slate-600 dark:text-slate-400 max-w-2xl">{desc}</p>}
        <div className="mt-4 text-xs font-semibold text-brand-600 dark:text-brand-400">
          {categoryProducts.length}{' '}
          {language === 'ne' ? 'सामान उपलब्ध' : 'Products Available'}
        </div>
      </div>

      {/* Product List */}
      {categoryProducts.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4 sm:gap-6">
          {categoryProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-12 border border-slate-200 dark:border-slate-800 text-center max-w-md mx-auto my-8">
          <h3 className="font-bold text-base text-slate-900 dark:text-white mb-2">
            {language === 'ne'
              ? 'यस वर्गमा अहिले कुनै सामान उपलब्ध छैन'
              : 'No products currently in this category'}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
            {language === 'ne'
              ? 'कृपया अन्य वर्गहरू हेर्नुहोस् वा हाम्रो टिमसँग सिधै सम्पर्क गर्नुहोस्।'
              : 'Check out our other categories or contact our office for special orders.'}
          </p>
          <Link
            href="/categories"
            className="inline-flex items-center gap-2 bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold px-4 py-2 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to All Categories</span>
          </Link>
        </div>
      )}
    </div>
  );
}
