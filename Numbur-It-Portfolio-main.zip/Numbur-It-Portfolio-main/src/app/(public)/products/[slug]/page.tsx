'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import SafeImage from '@/components/ui/SafeImage';
import { notFound, useParams } from 'next/navigation';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import { Product } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import { useCart } from '@/lib/cart/context';
import { buildWhatsAppOrderUrl } from '@/lib/whatsapp';
import {
  ShoppingCart,
  MessageSquare,
  Shield,
  Truck,
  Check,
  ChevronRight,
  Share2,
  Tag,
  Info,
} from 'lucide-react';

export default function ProductDetailPage() {
  const { slug } = useParams();
  const { language, t } = useLanguage();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const fallbackProduct = INITIAL_PRODUCTS.find((p) => p.slug === slug);
  const [product, setProduct] = useState<Product | null>(fallbackProduct || null);
  const [loading, setLoading] = useState(!fallbackProduct);

  useEffect(() => {
    async function loadProduct() {
      if (!slug) return;
      try {
        const res = await fetch(`/api/products?slug=${encodeURIComponent(slug as string)}&t=${Date.now()}`, {
          cache: 'no-store',
        });
        if (res.ok) {
          const data = await res.json();
          if (data.product) {
            setProduct(data.product);
            setLoading(false);
            return;
          }
        }
      } catch (err) {
        console.warn('Failed to load product detail:', err);
      }
      setLoading(false);
    }
    loadProduct();
  }, [slug]);

  if (loading) {
    return (
      <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-24 text-center">
        <div className="animate-spin w-8 h-8 border-2 border-brand-600 border-t-transparent rounded-full mx-auto mb-4" />
        <p className="text-slate-500 dark:text-slate-400 text-sm">Loading product details...</p>
      </div>
    );
  }

  if (!product) {
    notFound();
  }

  const title =
    language === 'ne' && product.name_ne ? product.name_ne : product.name_en;
  const shortDesc =
    language === 'ne' && product.short_desc_ne
      ? product.short_desc_ne
      : product.short_desc_en;
  const fullDesc =
    language === 'ne' && product.full_desc_ne
      ? product.full_desc_ne
      : product.full_desc_en;
  const warranty =
    language === 'ne' && product.warranty_info_ne
      ? product.warranty_info_ne
      : product.warranty_info_en;

  const hasDiscount =
    product.discount_price && product.discount_price < product.selling_price;
  const currentPrice = hasDiscount ? product.discount_price! : product.selling_price;

  const isAvailable =
    product.inventory?.in_stock ??
    (product.inventory?.available_quantity === undefined ||
      product.inventory.available_quantity > 0);

  const handleAddToCart = () => {
    if (!isAvailable) return;
    addToCart(product, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const handleBuyNowWhatsApp = () => {
    const whatsappNumber =
      process.env.NEXT_PUBLIC_DEFAULT_WHATSAPP_NUMBER || '9779854040821';
    const waUrl = buildWhatsAppOrderUrl(whatsappNumber, {
      orderNumber: `DIR-${Math.floor(1000 + Math.random() * 9000)}`,
      customerName: 'Customer (Direct Inquiry)',
      customerPhone: 'N/A',
      deliveryMethod: 'all_nepal_delivery',
      deliveryAddress: 'Inquiry from Product Page (Delivery All Over Nepal)',
      municipalityArea: 'All Nepal Delivery',
      items: [
        {
          name: product.name_en,
          sku: product.sku,
          quantity: quantity,
          price: currentPrice,
          total: currentPrice * quantity,
        },
      ],
      subtotal: currentPrice * quantity,
      specialInstructions: `Direct inquiry for ${product.name_en} (Qty: ${quantity})`,
    });
    window.open(waUrl, '_blank');
  };

  const specificationsList = Object.entries(product.specifications || {});

  return (
    <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-8">
      {/* Breadcrumbs */}
      <nav className="flex items-center space-x-2 text-xs text-slate-500 dark:text-slate-400 mb-6">
        <Link href="/" className="hover:text-brand-600 dark:hover:text-brand-400">
          Home
        </Link>
        <ChevronRight className="w-3 h-3 text-slate-400 dark:text-slate-600" />
        <Link href="/products" className="hover:text-brand-600 dark:hover:text-brand-400">
          Products
        </Link>
        {product.category && (
          <>
            <ChevronRight className="w-3 h-3 text-slate-400 dark:text-slate-600" />
            <Link
              href={`/categories/${product.category.slug}`}
              className="hover:text-brand-600 dark:hover:text-brand-400"
            >
              {language === 'ne' && product.category.name_ne
                ? product.category.name_ne
                : product.category.name_en}
            </Link>
          </>
        )}
        <ChevronRight className="w-3 h-3 text-slate-400 dark:text-slate-600" />
        <span className="text-slate-800 dark:text-slate-200 font-semibold truncate max-w-xs">
          {title}
        </span>
      </nav>

      {/* Main Product Showcase */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-12">
        {/* Left: Product Image Box (45%) */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200/90 dark:border-slate-800 shadow-sm flex items-center justify-center relative transition-colors">
          <div className="relative w-full aspect-square max-h-[480px]">
            <SafeImage
              src={product.primary_image_url}
              alt={title}
              fill
              priority
              type="product"
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-contain"
            />
          </div>
          {/* Availability Badge */}
          <div className="absolute top-4 left-4">
            {isAvailable ? (
              <span className="bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold px-3 py-1 rounded-full">
                ● {t.common.inStock}
              </span>
            ) : (
              <span className="bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800 text-xs font-semibold px-3 py-1 rounded-full">
                ● {t.common.outOfStock}
              </span>
            )}
          </div>
        </div>

        {/* Right: Pricing, Description, Actions (55%) */}
        <div className="lg:col-span-6 flex flex-col justify-between">
          <div className="space-y-4">
            {/* Brand & SKU */}
            <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
              {product.brand && (
                <span className="bg-brand-50 dark:bg-brand-950/60 text-brand-700 dark:text-brand-300 border border-brand-200 dark:border-brand-800 font-bold px-2.5 py-0.5 rounded-full uppercase">
                  {product.brand.name}
                </span>
              )}
              <span className="font-mono bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded">
                SKU: {product.sku}
              </span>
            </div>

            {/* Title */}
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white leading-tight">
              {title}
            </h1>

            {/* Pricing Box */}
            <div className="p-4 bg-slate-50 dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 rounded-2xl flex items-baseline gap-4">
              <span className="text-3xl font-black text-slate-900 dark:text-white">
                {t.common.currency} {currentPrice.toLocaleString('en-IN')}
              </span>
              {hasDiscount && (
                <>
                  <span className="text-base text-slate-400 line-through">
                    {t.common.currency} {product.selling_price.toLocaleString('en-IN')}
                  </span>
                  <span className="bg-red-100 dark:bg-red-950/80 text-red-700 dark:text-red-300 text-xs font-bold px-2 py-0.5 rounded border border-red-200 dark:border-red-800">
                    Save {t.common.currency} {(product.selling_price - currentPrice).toLocaleString('en-IN')}
                  </span>
                </>
              )}
            </div>

            {/* Short Description */}
            {shortDesc && (
              <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {shortDesc}
              </p>
            )}

            {/* Optional Warranty Banner: ONLY rendered if warranty exists */}
            {warranty && (
              <div className="flex items-center gap-2 p-3 bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs rounded-xl">
                <Shield className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span className="font-semibold">{t.common.warranty}: {warranty}</span>
              </div>
            )}

            {/* Delivery Coverage & Services Scope Notice */}
            <div className="p-3 bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs rounded-xl space-y-1.5">
              <div className="flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-300">
                <Truck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>
                  {language === 'ne'
                    ? 'डेलिभरी प्रणाली: नेपालभर (सबै ७७ जिल्लामा) उपलब्ध'
                    : 'Product Delivery System: Available All Over Nepal (All 77 Districts)'}
                </span>
              </div>
              <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-300 pl-6">
                {language === 'ne'
                  ? 'सामानहरू कूरियर वा यातायात मार्फत नेपालभर डेलिभरी गरिन्छ, वा मन्थली-१ देवकोटा चोक स्टोरबाट पिकअप गर्न सक्नुहुन्छ। (नोट: प्राविधिक तथा अन-साइट मर्मत सेवा मन्थली-१, रामेछापमा मात्र उपलब्ध छ।)'
                  : 'Hardware items delivered nationwide via courier & transport network, or self-pickup at our Manthali-1 Devkota Chowk showroom. (Note: On-site technical support & repair services are strictly in Manthali-1, Ramechhap only.)'}
              </p>
            </div>
          </div>

          {/* Action Row */}
          <div className="pt-6 border-t border-slate-200 dark:border-slate-800 mt-6 space-y-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center border border-slate-300 dark:border-slate-700 rounded-xl bg-white dark:bg-slate-800 overflow-hidden">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-3 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 font-bold"
                >
                  -
                </button>
                <span className="px-4 py-2 text-sm font-bold text-slate-900 dark:text-white">
                  {quantity}
                </span>
                <button
                  type="button"
                  onClick={() => setQuantity((q) => q + 1)}
                  className="px-3 py-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 font-bold"
                >
                  +
                </button>
              </div>

              <button
                type="button"
                onClick={handleAddToCart}
                disabled={!isAvailable}
                className={`flex-1 flex items-center justify-center gap-2 py-3 px-6 rounded-xl font-bold text-sm transition ${
                  added
                    ? 'bg-emerald-600 text-white'
                    : isAvailable
                    ? 'bg-brand-600 hover:bg-brand-700 text-white shadow-md'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed'
                }`}
              >
                {added ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Added to Cart</span>
                  </>
                ) : (
                  <>
                    <ShoppingCart className="w-4 h-4" />
                    <span>{t.common.addToCart}</span>
                  </>
                )}
              </button>
            </div>

            <button
              type="button"
              onClick={handleBuyNowWhatsApp}
              disabled={!isAvailable}
              className={`w-full flex items-center justify-center gap-2 py-3 px-6 rounded-xl font-bold text-sm transition ${
                isAvailable
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>{t.common.buyNow}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Dynamic Specifications & Full Description Tabs */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-200/90 dark:border-slate-800 shadow-sm space-y-8 transition-colors">
        {/* Full Description */}
        {fullDesc && (
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-3 border-b border-slate-100 dark:border-slate-800 pb-2">
              {language === 'ne' ? 'विस्तृत विवरण' : 'Product Description'}
            </h2>
            <div className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-line">
              {fullDesc}
            </div>
          </div>
        )}

        {/* Dynamic Specifications: ONLY displays entered attributes */}
        {specificationsList.length > 0 && (
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-3 border-b border-slate-100 dark:border-slate-800 pb-2">
              {t.common.specifications}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2">
              {specificationsList.map(([key, value]) => (
                <div
                  key={key}
                  className="flex justify-between py-2 border-b border-slate-100 dark:border-slate-800 text-xs"
                >
                  <span className="font-semibold text-slate-500 dark:text-slate-400">{key}:</span>
                  <span className="font-medium text-slate-900 dark:text-slate-200 text-right">{value}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
