'use client';

import React, { useState, useMemo, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import ProductCard from '@/components/public/ProductCard';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import { FALLBACK_CATEGORIES } from '@/components/public/CategoryGrid';
import { Product, Category } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import { Filter, SlidersHorizontal, Search, RefreshCw, X } from 'lucide-react';

function ProductsPageContent() {
  const { language, t } = useLanguage();
  const searchParams = useSearchParams();

  // Dynamic products & categories from API
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<Category[]>(FALLBACK_CATEGORIES);

  useEffect(() => {
    async function loadData() {
      try {
        const [prodResult, catResult] = await Promise.allSettled([
          fetch(`/api/products?t=${Date.now()}`, { cache: 'no-store' }),
          fetch(`/api/categories?t=${Date.now()}`, { cache: 'no-store' }),
        ]);

        if (prodResult.status === 'fulfilled' && prodResult.value.ok) {
          const pData = await prodResult.value.json();
          if (pData.products && pData.products.length > 0) {
            setProducts(pData.products);
          }
        }

        if (catResult.status === 'fulfilled' && catResult.value.ok) {
          const catData = await catResult.value.json();
          if (catData.categories && catData.categories.length > 0) {
            setCategories(catData.categories);
          }
        }
      } catch (err) {
        console.warn('Catalog fetch warning:', err);
      }
    }
    loadData();
  }, []);

  // URL query params
  const initialCategory = searchParams.get('category') || '';
  const initialBrand = searchParams.get('brand') || '';
  const initialQuery = searchParams.get('q') || '';
  const initialFilter = searchParams.get('filter') || '';

  // Local filter states
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [selectedBrand, setSelectedBrand] = useState<string>(initialBrand);
  const [searchKeyword, setSearchKeyword] = useState<string>(initialQuery);
  const [sortBy, setSortBy] = useState<string>('newest');
  const [inStockOnly, setInStockOnly] = useState<boolean>(false);
  const [featuredOnly, setFeaturedOnly] = useState<boolean>(
    initialFilter === 'featured'
  );
  const [maxPrice, setMaxPrice] = useState<number>(100000);
  const [mobileFilterOpen, setMobileFilterOpen] = useState<boolean>(false);

  // Synchronize state when URL query parameters change (e.g. Header search or Category navigation)
  useEffect(() => {
    const q = searchParams.get('q');
    const cat = searchParams.get('category');
    const br = searchParams.get('brand');
    const filt = searchParams.get('filter');

    if (q !== null) {
      setSearchKeyword(q);
    }
    if (cat !== null) {
      setSelectedCategory(cat);
    }
    if (br !== null) {
      setSelectedBrand(br);
    }
    if (filt === 'featured') {
      setFeaturedOnly(true);
    }
  }, [searchParams]);

  // Derive unique brands from products
  const brands = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => {
      if (p.brand?.name) set.add(p.brand.name);
    });
    return Array.from(set);
  }, [products]);

  // Multi-faceted filtering (all filters work together!)
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // 1. Keyword search (Name, SKU, Brand, Category, Specifications, Description)
      if (searchKeyword.trim()) {
        const rawQuery = searchKeyword.toLowerCase().trim();
        // Split multi-word queries (e.g. "dell laptop", "wifi router", "cctv camera")
        const queryTokens = rawQuery.split(/\s+/).filter(Boolean);

        // Normalize strings for punctuation-agnostic search (e.g. "wi-fi" vs "wifi")
        const normalize = (str: string) => str.toLowerCase().replace(/[-_/\\.,]/g, ' ');
        const stripPunct = (str: string) => str.toLowerCase().replace(/[-_/\\.,\s]/g, '');

        // Build specifications search text
        const specsText = Object.entries(product.specifications || {})
          .map(([k, v]) => `${k} ${v}`)
          .join(' ');

        // Add domain synonyms to help users find common terms
        const aliases: string[] = [];
        const catSlug = product.category?.slug || '';
        const nameLower = (product.name_en || '').toLowerCase();

        if (
          catSlug.includes('cctv') ||
          catSlug.includes('security') ||
          nameLower.includes('camera') ||
          nameLower.includes('dvr')
        ) {
          aliases.push(
            'cctv camera surveillance dvr nvr security ip camera night vision 1080p pan tilt'
          );
        }
        if (
          catSlug.includes('network') ||
          nameLower.includes('router') ||
          nameLower.includes('wi-fi') ||
          nameLower.includes('wifi')
        ) {
          aliases.push(
            'router wifi wi-fi gigabit internet wireless lan access point tp-link'
          );
        }
        if (
          catSlug.includes('laptop') ||
          catSlug.includes('computer') ||
          nameLower.includes('laptop') ||
          nameLower.includes('vostro')
        ) {
          aliases.push(
            'laptop notebook computer pc desktop intel core i5 i3 i7 ram ssd'
          );
        }
        if (
          catSlug.includes('printer') ||
          nameLower.includes('printer') ||
          nameLower.includes('laserjet') ||
          nameLower.includes('dcp')
        ) {
          aliases.push(
            'printer photocopier copy scan scanner laser monochrome cartridge toner brother hp'
          );
        }
        if (
          nameLower.includes('keyboard') ||
          nameLower.includes('mouse') ||
          catSlug.includes('keyboard')
        ) {
          aliases.push('keyboard mouse combo wireless optical usb wired dpi havit');
        }

        const combinedHaystack = [
          product.name_en || '',
          product.name_ne || '',
          product.sku || '',
          product.slug || '',
          product.brand?.name || '',
          product.category?.name_en || '',
          product.category?.name_ne || '',
          product.category?.slug || '',
          product.short_desc_en || '',
          product.short_desc_ne || '',
          product.full_desc_en || '',
          specsText,
          aliases.join(' '),
        ].join(' ');

        const haystackLower = combinedHaystack.toLowerCase();
        const haystackNormalized = normalize(combinedHaystack);
        const haystackStripped = stripPunct(combinedHaystack);

        // Every token in search query MUST match somewhere in the product
        const matchesAllTokens = queryTokens.every((token) => {
          const tokenNorm = normalize(token);
          const tokenStrip = stripPunct(token);
          return (
            haystackLower.includes(token) ||
            haystackNormalized.includes(tokenNorm) ||
            haystackStripped.includes(tokenStrip)
          );
        });

        if (!matchesAllTokens) {
          return false;
        }
      }

      // 2. Category filter
      if (selectedCategory && selectedCategory !== 'all') {
        const categoryMatch =
          product.category?.slug === selectedCategory ||
          product.category_id === selectedCategory;
        if (!categoryMatch) return false;
      }

      // 3. Brand filter
      if (selectedBrand && selectedBrand !== 'all') {
        const brandName = product.brand?.name || '';
        if (brandName.toLowerCase() !== selectedBrand.toLowerCase()) {
          return false;
        }
      }

      // 4. In-Stock filter
      if (inStockOnly) {
        const isInStock =
          product.inventory?.in_stock ??
          (product.inventory?.available_quantity === undefined ||
            product.inventory.available_quantity > 0);
        if (!isInStock) return false;
      }

      // 5. Featured filter
      if (featuredOnly && !product.is_featured) {
        return false;
      }

      // 6. Price range
      const effectivePrice = product.discount_price ?? product.selling_price;
      if (effectivePrice > maxPrice) {
        return false;
      }

      return true;
    }).sort((a, b) => {
      const priceA = a.discount_price ?? a.selling_price;
      const priceB = b.discount_price ?? b.selling_price;

      if (sortBy === 'price-low') {
        const diff = priceA - priceB;
        if (diff !== 0) return diff;
        return (a.id || '').localeCompare(b.id || '');
      }
      if (sortBy === 'price-high') {
        const diff = priceB - priceA;
        if (diff !== 0) return diff;
        return (a.id || '').localeCompare(b.id || '');
      }
      if (sortBy === 'name') {
        const diff = (a.name_en || '').localeCompare(b.name_en || '');
        if (diff !== 0) return diff;
        return (a.id || '').localeCompare(b.id || '');
      }
      // default: newest
      const timeA = a.created_at ? new Date(a.created_at).getTime() : 0;
      const timeB = b.created_at ? new Date(b.created_at).getTime() : 0;
      const diff = (isNaN(timeB) ? 0 : timeB) - (isNaN(timeA) ? 0 : timeA);
      if (diff !== 0) return diff;
      return (a.id || '').localeCompare(b.id || '');
    });
  }, [
    searchKeyword,
    selectedCategory,
    selectedBrand,
    inStockOnly,
    featuredOnly,
    maxPrice,
    sortBy,
  ]);

  const resetFilters = () => {
    setSelectedCategory('');
    setSelectedBrand('');
    setSearchKeyword('');
    setSortBy('newest');
    setInStockOnly(false);
    setFeaturedOnly(false);
    setMaxPrice(100000);
  };

  return (
    <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-8 transition-colors duration-200">
      {/* Top Header & Breadcrumb */}
      <div className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
            {t.nav.allProducts}
          </h1>
          <p className="text-xs md:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {language === 'ne'
              ? `कुल ${filteredProducts.length} वटा सामानहरू फेला परे`
              : `Showing ${filteredProducts.length} verified products in Ramechhap`}
          </p>
        </div>

        {/* Sort & Mobile Trigger */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
          <button
            type="button"
            onClick={() => setMobileFilterOpen(true)}
            className="lg:hidden flex items-center gap-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 shadow-sm"
          >
            <Filter className="w-4 h-4 text-brand-600 dark:text-brand-400" />
            <span>Filters</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-500 dark:text-slate-400 hidden sm:inline">Sort:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-xs font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white rounded-xl px-3.5 py-2 focus:outline-none focus:ring-2 focus:ring-brand-500"
            >
              <option value="newest">Newest Arrivals</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="name">Name (A - Z)</option>
            </select>
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6 xl:gap-8 items-start w-full">
        {/* Desktop Sidebar Filters */}
        <aside className="hidden lg:block w-64 xl:w-72 2xl:w-80 shrink-0 space-y-6 bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200/90 dark:border-slate-800 shadow-sm sticky top-28 transition-colors">
          <div className="flex justify-between items-center pb-3 border-b border-slate-100 dark:border-slate-800">
            <h2 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-brand-600 dark:text-brand-400" />
              <span>Filters</span>
            </h2>
            <button
              type="button"
              onClick={resetFilters}
              className="text-[11px] text-brand-600 dark:text-brand-400 hover:underline font-semibold flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>

          {/* Search Box */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              Search by Keyword
            </label>
            <div className="relative">
              <input
                type="text"
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                placeholder="Product or SKU..."
                className="w-full text-xs rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white pl-8 pr-3 py-2 focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          {/* Categories */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              Category
            </label>
            <div className="space-y-1.5 text-xs max-h-48 overflow-y-auto pr-1">
              <button
                type="button"
                onClick={() => setSelectedCategory('')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg transition ${
                  selectedCategory === ''
                    ? 'bg-brand-50 dark:bg-brand-950/70 text-brand-700 dark:text-brand-300 font-bold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                All Categories
              </button>
              {categories.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setSelectedCategory(c.slug)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg transition ${
                    selectedCategory === c.slug
                      ? 'bg-brand-50 dark:bg-brand-950/70 text-brand-700 dark:text-brand-300 font-bold'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  {language === 'ne' && c.name_ne ? c.name_ne : c.name_en}
                </button>
              ))}
            </div>
          </div>

          {/* Brand Filter */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
              Brand
            </label>
            <div className="space-y-1 text-xs">
              <button
                type="button"
                onClick={() => setSelectedBrand('')}
                className={`w-full text-left px-2.5 py-1.5 rounded-lg transition ${
                  selectedBrand === ''
                    ? 'bg-brand-50 dark:bg-brand-950/70 text-brand-700 dark:text-brand-300 font-bold'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                All Brands
              </button>
              {brands.map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => setSelectedBrand(b)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg transition ${
                    selectedBrand === b
                      ? 'bg-brand-50 dark:bg-brand-950/70 text-brand-700 dark:text-brand-300 font-bold'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          {/* Max Price Range Slider */}
          <div>
            <div className="flex justify-between items-center mb-1 text-xs">
              <span className="font-semibold text-slate-700 dark:text-slate-300">Max Price:</span>
              <span className="font-bold text-slate-900 dark:text-white">
                Rs. {maxPrice.toLocaleString('en-IN')}
              </span>
            </div>
            <input
              type="range"
              min="1000"
              max="150000"
              step="1000"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full accent-brand-600 cursor-pointer"
            />
          </div>

          {/* Toggle Switches */}
          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={inStockOnly}
                onChange={(e) => setInStockOnly(e.target.checked)}
                className="rounded text-brand-600 focus:ring-brand-500 w-4 h-4"
              />
              <span>In Stock Only</span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={featuredOnly}
                onChange={(e) => setFeaturedOnly(e.target.checked)}
                className="rounded text-brand-600 focus:ring-brand-500 w-4 h-4"
              />
              <span>Featured Only</span>
            </label>
          </div>
        </aside>

        {/* Product Grid Area - Expands to Fill Full Available Width */}
        <section className="flex-1 w-full min-w-0">
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4 sm:gap-6 w-full">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-12 text-center max-w-md mx-auto my-8 shadow-sm">
              <div className="w-12 h-12 bg-slate-100 dark:bg-slate-800 text-slate-400 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white mb-1">
                {t.common.noResults}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
                {t.common.emptyStateDesc}
              </p>
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-1.5 bg-brand-600 hover:bg-brand-700 text-white text-xs font-semibold px-4 py-2 rounded-xl transition"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reset All Filters</span>
              </button>
            </div>
          )}
        </section>
      </div>

      {/* Mobile Filters Drawer */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex justify-end md:hidden">
          <div className="bg-white dark:bg-slate-900 text-slate-900 dark:text-white w-4/5 max-w-xs h-full p-5 overflow-y-auto space-y-6 shadow-2xl">
            <div className="flex justify-between items-center pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-base">Filters</h3>
              <button
                type="button"
                onClick={() => setMobileFilterOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Mobile Categories */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                Category
              </label>
              <div className="space-y-1 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategory('');
                    setMobileFilterOpen(false);
                  }}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg ${
                    selectedCategory === '' ? 'bg-brand-50 dark:bg-brand-950/70 text-brand-700 dark:text-brand-300 font-bold' : ''
                  }`}
                >
                  All Categories
                </button>
                {categories.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => {
                      setSelectedCategory(c.slug);
                      setMobileFilterOpen(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg ${
                      selectedCategory === c.slug
                        ? 'bg-brand-50 dark:bg-brand-950/70 text-brand-700 dark:text-brand-300 font-bold'
                        : ''
                    }`}
                  >
                    {language === 'ne' && c.name_ne ? c.name_ne : c.name_en}
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex gap-2">
              <button
                type="button"
                onClick={() => {
                  resetFilters();
                  setMobileFilterOpen(false);
                }}
                className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold py-2 rounded-xl"
              >
                Reset
              </button>
              <button
                type="button"
                onClick={() => setMobileFilterOpen(false)}
                className="flex-1 bg-brand-600 text-white text-xs font-semibold py-2 rounded-xl"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function AllProductsPage() {
  return (
    <Suspense fallback={<div className="p-12 text-center text-xs text-slate-500">Loading catalog...</div>}>
      <ProductsPageContent />
    </Suspense>
  );
}

