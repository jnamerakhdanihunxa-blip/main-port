'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useLanguage } from '@/lib/i18n/context';
import { OrderStatus, PaymentStatus } from '@/types';
import {
  Clock,
  CheckCircle2,
  AlertCircle,
  Truck,
  Store,
  MessageSquare,
  Phone,
  ArrowLeft,
  ShieldCheck,
} from 'lucide-react';

interface StoredOrder {
  order_number: string;
  customer_name: string;
  customer_phone: string;
  delivery_address: string;
  municipality_area: string;
  delivery_method: string;
  delivery_instructions?: string;
  subtotal_amount: number;
  total_amount: number;
  advance_payment_amount: number;
  remaining_balance: number;
  order_status: OrderStatus;
  payment_status: PaymentStatus;
  items: Array<{
    name: string;
    sku: string;
    quantity: number;
    price: number;
    total: number;
  }>;
  created_at: string;
}

export default function OrderStatusPage() {
  const { orderNumber } = useParams();
  const { language, t } = useLanguage();
  const [order, setOrder] = useState<StoredOrder | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadOrder() {
      if (!orderNumber) {
        setLoading(false);
        return;
      }

      try {
        // 1. Try to fetch from server API (Supabase)
        const res = await fetch(`/api/orders?orderNumber=${encodeURIComponent(orderNumber as string)}`, {
          cache: 'no-store',
        });

        if (res.ok) {
          const data = await res.json();
          if (data.order) {
            setOrder(data.order);
            setLoading(false);
            return;
          }
        }
      } catch (apiErr) {
        console.warn('Could not fetch order from server API, falling back to local:', apiErr);
      }

      // 2. Fallback to localStorage
      try {
        const orders: StoredOrder[] = JSON.parse(
          localStorage.getItem('numbur_orders') || '[]'
        );
        const matched = orders.find((o) => o.order_number === orderNumber);
        if (matched) {
          setOrder(matched);
        } else {
          // If not in local storage and not found on server
          setOrder(null);
        }
      } catch (localErr) {
        console.error('LocalStorage order parse error:', localErr);
        setOrder(null);
      } finally {
        setLoading(false);
      }
    }

    loadOrder();
  }, [orderNumber]);

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto py-24 px-4 text-center">
        <div className="animate-spin w-8 h-8 border-2 border-brand-600 border-t-transparent rounded-full mx-auto mb-4" />
        <p className="text-slate-500 dark:text-slate-400 text-sm">{t.common.loading}</p>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="max-w-md mx-auto my-16 px-4 text-center">
        <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="w-12 h-12 bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 rounded-2xl flex items-center justify-center mx-auto border border-amber-200 dark:border-amber-800">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Order Not Found</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            We could not find an order with identifier <span className="font-mono font-bold text-slate-700 dark:text-slate-300">{String(orderNumber)}</span>. Please verify your order number or contact our customer desk.
          </p>
          <div className="pt-2 flex flex-col gap-2">
            <a
              href="https://wa.me/9779854040821"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl transition"
            >
              <MessageSquare className="w-4 h-4" />
              <span>Contact via WhatsApp</span>
            </a>
            <Link
              href="/products"
              className="inline-block bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs px-5 py-2.5 rounded-xl transition"
            >
              Browse Products
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'confirmed':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'delivered':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'shipped':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'ready_for_pickup':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 sm:px-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8 border-b border-slate-200 pb-4">
        <div>
          <span className="text-xs font-mono font-bold text-slate-500">
            ORDER IDENTIFIER
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            #{order.order_number}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Placed on {new Date(order.created_at).toLocaleDateString()}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span
            className={`text-xs font-bold px-3 py-1 rounded-full border uppercase tracking-wider ${getStatusBadge(
              order.order_status
            )}`}
          >
            ● {order.order_status.replace('_', ' ')}
          </span>
          <span className="text-xs font-bold px-3 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200 uppercase">
            Payment: {order.payment_status.replace('_', ' ')}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left: Items Snapshot & Delivery Details */}
        <div className="lg:col-span-7 space-y-6">
          {/* Order Items */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <h2 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-2">
              {t.orderStatus.itemsOrdered} ({order.items.length})
            </h2>

            <div className="space-y-3">
              {order.items.map((item, idx) => (
                <div
                  key={idx}
                  className="flex justify-between items-center text-xs py-2 border-b border-slate-50 last:border-0"
                >
                  <div>
                    <h3 className="font-bold text-slate-900">{item.name}</h3>
                    <span className="text-[10px] text-slate-400 font-mono">
                      SKU: {item.sku} • Qty: {item.quantity} x Rs.{' '}
                      {item.price.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <span className="font-extrabold text-slate-900">
                    Rs. {item.total.toLocaleString('en-IN')}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Delivery & Customer Snapshot */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3 text-xs">
            <h2 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-2">
              Delivery Information
            </h2>
            <div className="grid grid-cols-2 gap-2 text-slate-600">
              <div>
                <span className="text-slate-400 block">Recipient:</span>
                <span className="font-semibold text-slate-900">
                  {order.customer_name}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Contact Phone:</span>
                <span className="font-semibold text-slate-900">
                  {order.customer_phone}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Delivery Method:</span>
                <span className="font-semibold text-slate-900">
                  {order.delivery_method === 'ramechhap_delivery'
                    ? 'Ramechhap Road Delivery'
                    : 'Store Pickup'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Address:</span>
                <span className="font-semibold text-slate-900">
                  {order.delivery_address}, {order.municipality_area}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Payment Balance & Actions */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <h2 className="font-bold text-sm text-slate-900 border-b border-slate-100 pb-2">
              Financial Breakdown
            </h2>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal</span>
                <span className="font-bold text-slate-900">
                  Rs. {order.subtotal_amount.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Advance Payment Recorded</span>
                <span className="font-bold text-emerald-600">
                  Rs. {order.advance_payment_amount.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline">
                <span className="font-bold text-slate-900">Remaining Balance</span>
                <span className="text-xl font-black text-brand-600">
                  Rs. {order.remaining_balance.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 space-y-3">
              <a
                href={`https://wa.me/9779854040821?text=Inquiry%20regarding%20Order%20%23${order.order_number}`}
                target="_blank"
                rel="noreferrer"
                className="w-full flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-3 px-4 rounded-xl transition shadow"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Chat about this Order on WhatsApp</span>
              </a>

              <a
                href="tel:048540314"
                className="w-full flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs py-3 px-4 rounded-xl transition"
              >
                <Phone className="w-4 h-4" />
                <span>Call Store Office: 048540314</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
