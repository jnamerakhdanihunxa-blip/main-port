'use client';

import React from 'react';
import { useLanguage } from '@/lib/i18n/context';

export default function PrivacyPolicyPage() {
  const { language } = useLanguage();

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 sm:px-6">
      <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200/90 shadow-sm space-y-6 text-slate-800">
        <h1 className="text-3xl font-extrabold text-slate-900 border-b border-slate-200 pb-4">
          Privacy Policy
        </h1>
        <p className="text-xs text-slate-500">
          Last updated: September 2026 • Numbur iT Solution Pvt. Ltd. (Manthali-1, Ramechhap)
        </p>

        <section className="space-y-3 text-sm leading-relaxed">
          <h2 className="text-lg font-bold text-slate-900">1. Information We Collect</h2>
          <p>
            When you register an account, make an inquiry, or initiate a WhatsApp order with Numbur iT Solution, we collect necessary contact information including your full name, telephone/mobile number, email address, municipality/ward, and delivery address.
          </p>
        </section>

        <section className="space-y-3 text-sm leading-relaxed">
          <h2 className="text-lg font-bold text-slate-900">2. Customer Data Privacy & Security</h2>
          <p>
            Your private details (such as phone numbers, delivery coordinates, and purchase histories) are strictly protected using server-side authorization and database Row Level Security (RLS). We never share, sell, or disclose your contact or order details to third parties or other customers.
          </p>
        </section>

        <section className="space-y-3 text-sm leading-relaxed">
          <h2 className="text-lg font-bold text-slate-900">3. Purpose of Collection</h2>
          <p>
            Your information is used solely for verifying product availability, executing order delivery within Ramechhap, issuing tax invoices and warranty records, and providing technical support.
          </p>
        </section>

        <section className="space-y-3 text-sm leading-relaxed">
          <h2 className="text-lg font-bold text-slate-900">4. Contact & Inquiries</h2>
          <p>
            For any questions regarding your data, contact our data administrator at <a href="mailto:numburitsolution1@gmail.com" className="text-brand-600 underline">numburitsolution1@gmail.com</a> or phone 048540314.
          </p>
        </section>
      </div>
    </div>
  );
}
