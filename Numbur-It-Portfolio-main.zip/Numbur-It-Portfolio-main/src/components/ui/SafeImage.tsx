'use client';

import React, { useState } from 'react';
import Image, { ImageProps } from 'next/image';
import {
  Package,
  Layers,
  User,
  Image as ImageIcon,
  Laptop,
  Camera,
  HardDrive,
} from 'lucide-react';

interface SafeImageProps extends Omit<ImageProps, 'src'> {
  src?: string | null;
  type?: 'product' | 'category' | 'avatar' | 'banner' | 'gallery' | 'generic';
  fallbackIcon?: React.ReactNode;
  fallbackText?: string;
}

export default function SafeImage({
  src,
  alt,
  type = 'generic',
  fallbackIcon,
  fallbackText,
  className = '',
  fill,
  width,
  height,
  ...props
}: SafeImageProps) {
  const [hasError, setHasError] = useState(false);

  React.useEffect(() => {
    setHasError(false);
  }, [src]);

  // Check if source is valid, non-empty, and not a legacy local path that no longer exists
  const isValidSrc =
    !hasError &&
    Boolean(src) &&
    typeof src === 'string' &&
    src.trim().length > 0 &&
    !src.startsWith('/images/');

  if (!isValidSrc) {
    // Render custom vector / SVG placeholder
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 via-slate-50 to-slate-200 text-slate-400 select-none ${
          fill ? 'absolute inset-0 w-full h-full' : ''
        } ${className}`}
        style={!fill && width && height ? { width, height } : undefined}
        title={alt || 'Image preview'}
      >
        {fallbackIcon ? (
          fallbackIcon
        ) : type === 'product' ? (
          <div className="flex flex-col items-center gap-1.5 p-3 text-center">
            <div className="w-10 h-10 rounded-xl bg-white/80 shadow-sm border border-slate-200/80 flex items-center justify-center text-brand-600">
              <Laptop className="w-5 h-5" />
            </div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              Numbur iT
            </span>
          </div>
        ) : type === 'category' ? (
          <div className="w-10 h-10 rounded-xl bg-white/80 shadow-sm border border-slate-200/80 flex items-center justify-center text-brand-600">
            <Layers className="w-5 h-5" />
          </div>
        ) : type === 'avatar' ? (
          <div className="flex flex-col items-center justify-center w-full h-full bg-slate-200 text-slate-500">
            <User className="w-10 h-10 opacity-70" />
            {fallbackText && (
              <span className="text-[11px] font-bold mt-1 text-slate-600">
                {fallbackText}
              </span>
            )}
          </div>
        ) : type === 'banner' ? (
          <div className="flex flex-col items-center justify-center w-full h-full bg-gradient-to-r from-slate-900 via-brand-950 to-slate-900 text-white/50 p-6 text-center">
            <HardDrive className="w-10 h-10 mb-2 text-brand-400 opacity-60" />
            <span className="text-xs font-bold tracking-widest uppercase text-slate-300">
              Numbur iT Solution
            </span>
          </div>
        ) : type === 'gallery' ? (
          <div className="flex flex-col items-center justify-center w-full h-full bg-slate-100 text-slate-400">
            <Camera className="w-8 h-8 opacity-60" />
            <span className="text-[10px] font-medium mt-1">Showcase Photo</span>
          </div>
        ) : (
          <ImageIcon className="w-6 h-6 opacity-50" />
        )}
      </div>
    );
  }

  // Check if domain is remote (not a local relative path)
  const isExternal = typeof src === 'string' && src.startsWith('http');
  const isCloudinary = typeof src === 'string' && src.includes('res.cloudinary.com');

  return (
    <Image
      key={src || 'empty'}
      src={src!}
      alt={alt || 'Image'}
      fill={fill}
      width={!fill ? width : undefined}
      height={!fill ? height : undefined}
      className={className}
      onError={() => setHasError(true)}
      unoptimized={isExternal || isCloudinary}
      {...props}
    />
  );
}
