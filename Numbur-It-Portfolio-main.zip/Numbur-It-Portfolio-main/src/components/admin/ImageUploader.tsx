'use client';

import React, { useState, useRef } from 'react';
import SafeImage from '@/components/ui/SafeImage';
import {
  Upload,
  Link as LinkIcon,
  X,
  Loader2,
  CheckCircle2,
  AlertCircle,
  Image as ImageIcon,
} from 'lucide-react';

interface ImageUploaderProps {
  value?: string;
  onChange: (url: string) => void;
  folder?: string;
  label?: string;
  aspectRatio?: 'square' | 'video' | 'portrait';
}

export default function ImageUploader({
  value,
  onChange,
  folder = 'numbur-it/catalog',
  label = 'Product Image',
  aspectRatio = 'square',
}: ImageUploaderProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [inputMode, setInputMode] = useState<'upload' | 'url'>('upload');
  const [urlInput, setUrlInput] = useState(value || '');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setErrorMessage('');

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('folder', folder);

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      const raw = await res.text();
      let data: any = {};
      try {
        data = JSON.parse(raw);
      } catch (jsonErr) {
        throw new Error(`Upload server error (${res.status}): ${raw.slice(0, 100) || 'Empty response'}`);
      }

      if (!res.ok || data.error) {
        throw new Error(data.error || 'Upload failed. Check Cloudinary settings.');
      }

      onChange(data.url);
      setUrlInput(data.url);
    } catch (err: any) {
      console.error('Upload failed:', err);
      setErrorMessage(
        err.message ||
          'Failed to upload image. You can switch to URL mode or configure Cloudinary credentials.'
      );
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleApplyUrl = () => {
    if (urlInput.trim()) {
      onChange(urlInput.trim());
      setErrorMessage('');
    }
  };

  const handleRemove = () => {
    onChange('');
    setUrlInput('');
    setErrorMessage('');
  };

  const aspectClass =
    aspectRatio === 'video'
      ? 'aspect-video'
      : aspectRatio === 'portrait'
      ? 'aspect-[3/4]'
      : 'aspect-square';

  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <label className="block text-xs font-bold text-slate-700">{label}</label>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setInputMode('upload')}
            className={`text-[11px] px-2 py-0.5 rounded transition ${
              inputMode === 'upload'
                ? 'bg-brand-50 text-brand-700 font-bold'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            Direct Upload
          </button>
          <button
            type="button"
            onClick={() => setInputMode('url')}
            className={`text-[11px] px-2 py-0.5 rounded transition ${
              inputMode === 'url'
                ? 'bg-brand-50 text-brand-700 font-bold'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            Paste URL
          </button>
        </div>
      </div>

      {/* Main Upload Box / Preview */}
      <div className="flex gap-4 items-start">
        {/* Thumbnail Preview */}
        <div
          className={`relative w-24 h-24 rounded-2xl overflow-hidden border border-slate-200 bg-slate-50 shrink-0 shadow-inner group`}
        >
          {value ? (
            <>
              <SafeImage
                src={value}
                alt="Uploaded preview"
                fill
                className="object-contain p-1"
              />
              <button
                type="button"
                onClick={handleRemove}
                className="absolute top-1 right-1 p-1 bg-black/60 hover:bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition shadow"
                title="Remove image"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center w-full h-full text-slate-300">
              <ImageIcon className="w-6 h-6 mb-1" />
              <span className="text-[9px] font-semibold text-slate-400">No Image</span>
            </div>
          )}
        </div>

        {/* Input Control Area */}
        <div className="flex-1 space-y-2">
          {inputMode === 'upload' ? (
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/png, image/jpeg, image/webp, image/avif"
                onChange={handleFileChange}
                className="hidden"
                id={`file-upload-${label.replace(/\s+/g, '-').toLowerCase()}`}
              />
              <label
                htmlFor={`file-upload-${label.replace(/\s+/g, '-').toLowerCase()}`}
                className={`flex flex-col items-center justify-center p-3 border-2 border-dashed rounded-2xl cursor-pointer transition ${
                  isUploading
                    ? 'border-brand-300 bg-brand-50/30'
                    : 'border-slate-200 hover:border-brand-500 hover:bg-slate-50/50'
                }`}
              >
                {isUploading ? (
                  <div className="flex items-center gap-2 text-brand-600 text-xs font-semibold py-1">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Uploading to Cloudinary...</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-slate-600 text-xs py-1">
                    <Upload className="w-4 h-4 text-brand-600" />
                    <span className="font-semibold text-brand-700">Choose Image File</span>
                    <span className="text-slate-400 text-[11px]">(PNG, JPG, WebP)</span>
                  </div>
                )}
              </label>
            </div>
          ) : (
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  placeholder="https://res.cloudinary.com/..."
                  value={urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  className="w-full text-xs rounded-xl border border-slate-200 pl-8 pr-3 py-2 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
                <LinkIcon className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              </div>
              <button
                type="button"
                onClick={handleApplyUrl}
                className="bg-brand-600 hover:bg-brand-700 text-white text-xs font-bold px-3 py-2 rounded-xl transition"
              >
                Set
              </button>
            </div>
          )}

          {/* Quick Info / Cloudinary notice */}
          <div className="flex items-center justify-between text-[10px] text-slate-400">
            <span>Powered by Cloudinary CDN</span>
            {value && (
              <span className="text-emerald-600 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> Image linked
              </span>
            )}
          </div>
        </div>
      </div>

      {errorMessage && (
        <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span className="leading-tight">{errorMessage}</span>
        </div>
      )}
    </div>
  );
}
