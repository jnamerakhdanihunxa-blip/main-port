'use client';

import React, { useState } from 'react';
import { useCart } from '@/lib/cart/context';
import { useLanguage } from '@/lib/i18n/context';
import {
  MessageSquare,
  Truck,
  Store,
  X,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ShieldCheck,
  ShoppingBag,
  ExternalLink,
} from 'lucide-react';

interface WhatsAppCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const NEPAL_AREAS = [
  'Manthali-1 / Manthali Municipality (मन्थली-१ / नगरपालिका, रामेछाप)',
  'Ramechhap Municipality (रामेछाप नगरपालिका)',
  'Khandadevi Rural Municipality (खाँडादेवी गाउँपालिका, रामेछाप)',
  'Doramba Sailung Rural Municipality (दोरम्बा शैलुङ गाउँपालिका, रामेछाप)',
  'Sunapati Rural Municipality (सुनापती गाउँपालिका, रामेछाप)',
  'Likhu Tamakoshi Rural Municipality (लिखु तामाकोशी गाउँपालिका, रामेछाप)',
  'Gokulganga Rural Municipality (गोकुलगङ्गा गाउँपालिका, रामेछाप)',
  'Umakunda Rural Municipality (उमाकुण्ड गाउँपालिका, रामेछाप)',
  'Kathmandu Valley / Bagmati Province (काठमाडौं उपत्यका तथा बागमती)',
  'Koshi Province (कोशी प्रदेश - विराटनगर, इटहरी, धरान, आदि)',
  'Madhesh Province (मधेश प्रदेश - जनकपुर, वीरगञ्ज, आदि)',
  'Gandaki Province (गण्डकी प्रदेश - पोखरा, आदि)',
  'Lumbini Province (लुम्बिनी प्रदेश - बुटवल, भैरहवा, दाङ, आदि)',
  'Karnali Province (कर्णाली प्रदेश - सुर्खेत, आदि)',
  'Sudurpashchim Province (सुदूरपश्चिम प्रदेश - धनगढी, आदि)',
  'All Nepal Delivery / Other Districts (अन्य सबै जिल्लाहरू - नेपालभर डेलिभरी)',
];

export default function WhatsAppCheckoutModal({
  isOpen,
  onClose,
}: WhatsAppCheckoutModalProps) {
  const { items, subtotal, clearCart } = useCart();
  const { language, t } = useLanguage();

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [municipalityArea, setMunicipalityArea] = useState(NEPAL_AREAS[0]);
  const [deliveryMethod, setDeliveryMethod] = useState<'all_nepal_delivery' | 'ramechhap_delivery' | 'store_pickup'>('all_nepal_delivery');
  const [orderNotes, setOrderNotes] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [completedOrder, setCompletedOrder] = useState<{
    orderNumber: string;
    waUrl: string;
    totalAmount: number;
  } | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!customerName.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }

    const cleanPhone = customerPhone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 9) {
      setErrorMsg('Please enter a valid phone number.');
      return;
    }

    if (!deliveryAddress.trim()) {
      setErrorMsg('Please enter your delivery street address or landmark.');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        customer_name: customerName.trim(),
        customer_phone: customerPhone.trim(),
        customer_email: customerEmail.trim() || undefined,
        delivery_address: deliveryAddress.trim(),
        municipality_area: municipalityArea,
        delivery_method: deliveryMethod,
        customer_notes: orderNotes.trim() || undefined,
        items: items.map((i) => ({
          productId: i.product.id,
          slug: i.product.slug,
          quantity: i.quantity,
          price: i.selectedPrice,
        })),
      };

      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to submit order.');
      }

      setCompletedOrder({
        orderNumber: data.orderNumber,
        waUrl: data.waUrl,
        totalAmount: data.totalAmount,
      });

      // Clear the cart
      clearCart();

      // Open WhatsApp automatically in a new window/tab
      if (data.waUrl) {
        window.open(data.waUrl, '_blank', 'noopener,noreferrer');
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error processing order. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-2xl overflow-hidden my-auto max-h-[90vh] flex flex-col transition-colors">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/80 dark:bg-slate-800/50">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center shrink-0">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base sm:text-lg text-slate-900 dark:text-white leading-tight">
                {completedOrder ? 'Order Recorded Successfully' : 'Order via WhatsApp Desk'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {completedOrder
                  ? 'Your pending order is ready for WhatsApp confirmation'
                  : 'Enter delivery details before connecting to our Manthali staff'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800 transition"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {completedOrder ? (
            /* Success State */
            <div className="space-y-6 text-center py-4">
              <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto ring-8 ring-emerald-50 dark:ring-emerald-950/40">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <span className="inline-block bg-brand-50 dark:bg-brand-950/60 text-brand-700 dark:text-brand-300 text-xs font-mono font-bold px-3 py-1 rounded-full border border-brand-200 dark:border-brand-800 mb-2">
                  Order Number: #{completedOrder.orderNumber}
                </span>
                <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
                  Pending Order Created!
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 max-w-md mx-auto leading-relaxed">
                  Your order has been registered in our system. A pre-filled WhatsApp message has been generated.
                </p>
              </div>

              <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-2xl p-4 text-left text-xs text-amber-900 dark:text-amber-200 space-y-1.5 max-w-lg mx-auto">
                <p className="font-bold flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
                  Important Next Step:
                </p>
                <p className="leading-relaxed">
                  Please make sure to <strong>manually press SEND</strong> in your WhatsApp conversation. Our customer service representative in Manthali will review your items and confirm availability and delivery!
                </p>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row gap-3 justify-center">
                <a
                  href={completedOrder.waUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm py-3 px-6 rounded-xl shadow-lg transition"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Open WhatsApp Message Again</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <button
                  type="button"
                  onClick={onClose}
                  className="inline-flex items-center justify-center text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white py-3 px-4 border border-slate-200 dark:border-slate-700 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  Close & Continue Browsing
                </button>
              </div>
            </div>
          ) : (
            /* Details Input Form */
            <form onSubmit={handleSubmit} className="space-y-4">
              {errorMsg && (
                <div className="p-3 bg-red-50 dark:bg-red-950/50 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Delivery Method Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2 uppercase tracking-wider">
                  Select Delivery Method *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setDeliveryMethod('all_nepal_delivery')}
                    className={`p-3.5 rounded-2xl border text-left flex items-start gap-3 transition ${
                      deliveryMethod === 'all_nepal_delivery' || deliveryMethod === 'ramechhap_delivery'
                        ? 'border-brand-600 dark:border-brand-500 bg-brand-50/50 dark:bg-brand-950/40 ring-1 ring-brand-600 dark:ring-brand-500'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 dark:bg-slate-800/40'
                    }`}
                  >
                    <Truck
                      className={`w-5 h-5 shrink-0 mt-0.5 ${
                        deliveryMethod !== 'store_pickup' ? 'text-brand-600 dark:text-brand-400' : 'text-slate-400 dark:text-slate-500'
                      }`}
                    />
                    <div>
                      <span className="font-bold text-xs text-slate-900 dark:text-white block">
                        All Nepal Delivery (नेपालभर डेलिभरी)
                      </span>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400 block mt-0.5 leading-tight">
                        Courier & transport delivery available all over Nepal (All 77 districts).
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeliveryMethod('store_pickup')}
                    className={`p-3.5 rounded-2xl border text-left flex items-start gap-3 transition ${
                      deliveryMethod === 'store_pickup'
                        ? 'border-brand-600 dark:border-brand-500 bg-brand-50/50 dark:bg-brand-950/40 ring-1 ring-brand-600 dark:ring-brand-500'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 dark:bg-slate-800/40'
                    }`}
                  >
                    <Store
                      className={`w-5 h-5 shrink-0 mt-0.5 ${
                        deliveryMethod === 'store_pickup' ? 'text-brand-600 dark:text-brand-400' : 'text-slate-400 dark:text-slate-500'
                      }`}
                    />
                    <div>
                      <span className="font-bold text-xs text-slate-900 dark:text-white block">
                        Store Pickup (पसलमा पिकअप)
                      </span>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400 block mt-0.5 leading-tight">
                        Showroom: Manthali-1, Devkota Chowk, Ramechhap. Free of charge.
                      </span>
                    </div>
                  </button>
                </div>

                {/* Clear Location & Coverage Notice */}
                <div className="mt-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-2xl p-3 text-xs text-blue-900 dark:text-blue-200 space-y-1">
                  <p className="font-bold flex items-center gap-1.5 text-blue-800 dark:text-blue-300">
                    <Truck className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0" />
                    <span>Coverage & Location Information:</span>
                  </p>
                  <p className="text-[11px] leading-relaxed text-blue-800 dark:text-blue-300">
                    • <strong>Product Delivery System:</strong> Available <strong>all over Nepal</strong> to all 77 districts via courier and local dispatch.<br/>
                    • <strong>On-Site Technical & Repair Services:</strong> Exclusively available in <strong>Manthali-1, Ramechhap</strong> only.<br/>
                    • <strong>Physical Showroom:</strong> Devkota Chowk, Manthali-1, Ramechhap.
                  </p>
                </div>
              </div>

              {/* Customer Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Ram Kumar Shrestha"
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Mobile Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g. 9854040821"
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
              </div>

              {/* Municipality / Area Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Destination District / Municipality / Area *
                </label>
                <select
                  value={municipalityArea}
                  onChange={(e) => setMunicipalityArea(e.target.value)}
                  className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                >
                  {NEPAL_AREAS.map((area) => (
                    <option key={area} value={area}>
                      {area}
                    </option>
                  ))}
                </select>
              </div>

              {/* Street Address & Landmark */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Delivery Address / Landmark *
                </label>
                <input
                  type="text"
                  required
                  value={deliveryAddress}
                  onChange={(e) => setDeliveryAddress(e.target.value)}
                  placeholder="e.g. Manthali Bazar, near District Hospital, Ward 1"
                  className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                />
              </div>

              {/* Optional Email & Notes */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Email Address <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <input
                    type="email"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Order / Delivery Notes <span className="text-slate-400 font-normal">(Optional)</span>
                  </label>
                  <input
                    type="text"
                    value={orderNotes}
                    onChange={(e) => setOrderNotes(e.target.value)}
                    placeholder="e.g. Call before delivery, deliver in afternoon"
                    className="w-full text-xs rounded-xl border border-slate-200 dark:border-slate-700 p-2.5 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500"
                  />
                </div>
              </div>

              {/* Order Items Preview */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-2xl">
                <div className="flex justify-between items-center text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                  <span>Cart Items ({items.length})</span>
                  <span className="text-brand-600 dark:text-brand-400 font-black">
                    Rs. {subtotal.toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="max-h-24 overflow-y-auto space-y-1 text-[11px] text-slate-600 dark:text-slate-400">
                  {items.map((item) => (
                    <div key={item.id} className="flex justify-between">
                      <span className="truncate max-w-[240px]">
                        {item.quantity}x {item.product.name_en}
                      </span>
                      <span className="font-mono">
                        Rs. {(item.selectedPrice * item.quantity).toLocaleString('en-IN')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center gap-3">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm py-3 px-6 rounded-xl shadow-md transition disabled:opacity-50"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>
                    {isSubmitting ? 'Validating Order...' : 'Continue to WhatsApp'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="text-xs font-semibold text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white py-3 px-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
