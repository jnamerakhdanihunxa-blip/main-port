'use client';

import React from 'react';
import Link from 'next/link';
import { useLanguage } from '@/lib/i18n/context';
import {
  MapPin,
  Phone,
  Mail,
  ExternalLink,
  Shield,
  Facebook,
  Twitter,
  Youtube,
  Instagram,
  Linkedin,
  Truck,
  Wrench,
} from 'lucide-react';

export default function Footer() {
  const { t, language } = useLanguage();
  const [siteLogo, setSiteLogo] = React.useState('');
  const [socialLinks, setSocialLinks] = React.useState<Array<{
    id?: string;
    platform: string;
    url: string;
    label: string;
  }>>([
    { platform: 'facebook', url: 'https://www.facebook.com/p/-100057596823175/', label: 'Facebook' },
    { platform: 'twitter', url: 'https://www.x.com', label: 'Twitter / X' },
    { platform: 'youtube', url: 'https://www.youtube.com', label: 'YouTube' },
    { platform: 'instagram', url: 'https://www.instagram.com', label: 'Instagram' },
    { platform: 'linkedin', url: 'https://www.linkedin.com', label: 'LinkedIn' },
  ]);

  React.useEffect(() => {
    async function loadData() {
      try {
        const [settingsRes, socialRes] = await Promise.all([
          fetch('/api/settings', { cache: 'no-store' }),
          fetch('/api/social', { cache: 'no-store' })
        ]);
        if (settingsRes.ok) {
          const sData = await settingsRes.json();
          if (sData.settings?.site_logo_url) {
            setSiteLogo(sData.settings.site_logo_url);
          }
        }
        if (socialRes.ok) {
          const scData = await socialRes.json();
          if (scData.links && scData.links.length > 0) {
            setSocialLinks(scData.links);
          }
        }
      } catch (err) {
        console.warn('Could not load footer dynamic settings or social links:', err);
      }
    }
    loadData();
  }, []);

  const usefulLinks = [
    { name: 'Windows & Office Activator (Massgrave)', href: 'https://massgrave.dev/' },
    { name: 'Office 2021 Download (Archive)', href: 'https://mega.nz/file/Vbp0GbwZ#tXIa9g9pGVwdF7e__q8aAsquwMCzMwpRVIdrwTINrIM' },
    { name: 'Nepali All Font Download (Preeti/Unicode)', href: 'https://mega.nz/folder/VOpymZ4L#eTIANPThpceSU7WMJZPwnw' },
    { name: 'Typeshala All In One', href: 'https://mega.nz/file/xeIgHKZb#dEIJwJqA7sNkJbXeK-g_IDs1iDIWENFD_O-olyN18Dg' },
    { name: 'IDM Activation Script', href: 'https://github.com/Coporton/IDM-Activation-Script' },
  ];

  const quickLinks = [
    { name: t.nav.home, href: '/' },
    { name: t.nav.allProducts, href: '/products' },
    { name: t.nav.categories, href: '/categories' },
    { name: t.nav.services, href: '/services' },
    { name: t.nav.gallery, href: '/gallery' },
    { name: t.nav.about, href: '/about' },
    { name: t.nav.contact, href: '/contact' },
    { name: t.nav.team, href: '/team' },
  ];

  const legalLinks = [
    { name: 'Privacy Policy', href: '/privacy-policy' },
    { name: 'Terms & Conditions', href: '/terms' },
    { name: 'Warranty & Return Policy', href: '/warranty-return-policy' },
  ];

  const getSocialIcon = (platform: string) => {
    const key = platform.toLowerCase();
    if (key.includes('facebook')) return <Facebook className="w-4 h-4" />;
    if (key.includes('twitter') || key === 'x') return <Twitter className="w-4 h-4" />;
    if (key.includes('youtube')) return <Youtube className="w-4 h-4" />;
    if (key.includes('instagram')) return <Instagram className="w-4 h-4" />;
    if (key.includes('linkedin')) return <Linkedin className="w-4 h-4" />;
    if (key.includes('whatsapp')) return <Phone className="w-4 h-4" />;
    return <ExternalLink className="w-4 h-4" />;
  };

  return (
    <footer className="bg-white text-slate-700 dark:bg-slate-950 dark:text-slate-300 mt-auto border-t border-slate-200 dark:border-slate-800 transition-colors duration-200">
      {/* Upper Footer Grid - Fluid Edge-to-Edge Container */}
      <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 xl:gap-12">
          {/* Column 1: Brand & Identity */}
          <div className="space-y-4">
            <Link href="/" className="inline-flex items-center gap-3 group">
              {siteLogo ? (
                <img
                  src={siteLogo}
                  alt="Numbur iT Solution Logo"
                  className="h-10 w-auto max-w-[160px] object-contain rounded"
                />
              ) : (
                <div className="w-10 h-10 rounded-xl bg-brand-500 flex items-center justify-center text-white font-extrabold text-xl shadow-md">
                  N
                </div>
              )}
              <div>
                <span className="font-extrabold text-xl text-slate-900 dark:text-white block group-hover:text-brand-500 dark:group-hover:text-brand-400 transition">
                  Numbur <span className="text-brand-500">iT</span> Solution
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400 font-medium block">
                  Pvt. Ltd. • Regd. 2069 BS
                </span>
              </div>
            </Link>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {t.footer.aboutCompany}
            </p>
            <div className="pt-2 flex flex-wrap items-center gap-2.5">
              {socialLinks.map((item, idx) => (
                <a
                  key={item.id || idx}
                  href={item.url}
                  target="_blank"
                  rel="noreferrer"
                  className="w-9 h-9 rounded-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-brand-500 hover:bg-brand-500 hover:text-white dark:hover:border-brand-500 dark:hover:bg-brand-500 dark:hover:text-white flex items-center justify-center transition-all shadow-xs"
                  aria-label={item.label || item.platform}
                  title={item.label || item.platform}
                >
                  {getSocialIcon(item.platform)}
                </a>
              ))}
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4 border-b border-slate-200 dark:border-slate-800 pb-2">
              {t.footer.quickLinks}
            </h3>
            <ul className="space-y-2 text-xs">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-slate-600 dark:text-slate-400 hover:text-brand-500 dark:hover:text-white transition flex items-center gap-1.5"
                  >
                    <span className="text-brand-500">›</span> {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Useful Links (Legacy Download Resources Preserved) */}
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4 border-b border-slate-200 dark:border-slate-800 pb-2">
              {t.footer.usefulLinks}
            </h3>
            <ul className="space-y-2 text-xs">
              {usefulLinks.map((link, idx) => (
                <li key={idx}>
                  <a
                    href={link.href}
                    target="_blank"
                    rel="noreferrer"
                    className="text-slate-600 dark:text-slate-400 hover:text-brand-500 dark:hover:text-white transition flex items-center gap-1.5"
                  >
                    <ExternalLink className="w-3 h-3 text-slate-400 dark:text-slate-500" />
                    <span>{link.name}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Contact & Office */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4 border-b border-slate-200 dark:border-slate-800 pb-2">
              {t.footer.contactInfo}
            </h3>
            <div className="space-y-2.5 text-xs text-slate-600 dark:text-slate-400">
              <a
                href="https://www.google.com/maps/place/Numbur+It+Solution+Pvt+Ltd/@27.382878,86.060467,18z"
                target="_blank"
                rel="noreferrer"
                className="flex items-start gap-2 hover:text-brand-500 dark:hover:text-white transition"
              >
                <MapPin className="w-4 h-4 text-brand-500 shrink-0 mt-0.5" />
                <span>
                  {language === 'ne'
                    ? 'मन्थली-१, देवकोटा चोक, रामेछाप, नेपाल'
                    : 'Manthali-1, Devkota Chowk, Ramechhap, Nepal'}
                </span>
              </a>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-brand-500 shrink-0" />
                <span>
                  Tel: <a href="tel:048540314" className="hover:text-brand-500 dark:hover:text-white font-medium">048-540314</a> /{' '}
                  <a href="tel:9854040821" className="hover:text-brand-500 dark:hover:text-white font-medium">9854040821</a>
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-brand-500 shrink-0" />
                <a
                  href="mailto:numburitsolution1@gmail.com"
                  className="hover:text-brand-500 dark:hover:text-white"
                >
                  numburitsolution1@gmail.com
                </a>
              </div>
              <div className="pt-2 text-[11px] text-slate-500 dark:text-slate-400 border-t border-slate-200 dark:border-slate-800 space-y-1.5">
                <p className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1.5">
                  <Truck className="w-3.5 h-3.5 shrink-0" />
                  <span>{language === 'ne' ? 'डेलिभरी: नेपालभर उपलब्ध' : 'Delivery: Available All Over Nepal'}</span>
                </p>
                <p className="text-amber-600 dark:text-amber-400 font-semibold flex items-center gap-1.5">
                  <Wrench className="w-3.5 h-3.5 shrink-0" />
                  <span>{language === 'ne' ? 'प्राविधिक सेवा: मन्थली-१ मा मात्र' : 'Services: Manthali-1 Only'}</span>
                </p>
                <p>🕒 {language === 'ne' ? 'आइतबार - शुक्रबार: ९:०० - ६:००' : 'Sun - Fri: 9:00 AM - 6:00 PM'}</p>
                <p className="text-red-500 font-medium">🕒 {language === 'ne' ? 'शनिबार: बन्द' : 'Saturday: Closed'}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Legal & Policy Row */}
        <div className="mt-12 pt-6 border-t border-slate-200 dark:border-slate-900 flex flex-wrap gap-4 justify-between items-center text-xs text-slate-500 dark:text-slate-400">
          <div className="flex flex-wrap gap-4">
            {legalLinks.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="hover:text-brand-500 dark:hover:text-slate-300 transition"
              >
                {item.name}
              </Link>
            ))}
          </div>
          <div suppressHydrationWarning>
            &copy; {new Date().getFullYear()} Numbur iT Solution Pvt. Ltd. {t.footer.copyright}
          </div>
        </div>
      </div>
    </footer>
  );
}
