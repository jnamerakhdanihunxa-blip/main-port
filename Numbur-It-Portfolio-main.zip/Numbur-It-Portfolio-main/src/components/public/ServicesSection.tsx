'use client';

import React from 'react';
import Link from 'next/link';
import { useLanguage } from '@/lib/i18n/context';
import { ServiceItem } from '@/types';
import {
  ShieldCheck,
  Laptop,
  Printer,
  Network,
  Fingerprint,
  PhoneCall,
  Zap,
  Monitor,
  Tv,
  Coins,
  Home,
  Headphones,
  ArrowRight,
} from 'lucide-react';

export const AUDITED_SERVICES_FALLBACK: ServiceItem[] = [
  {
    id: 'e1000000-0000-0000-0000-000000000001',
    title_en: 'CCTV Surveillance & Security',
    title_ne: 'सीसीटीभी निगरानी तथा सुरक्षा',
    slug: 'cctv-surveillance',
    icon_name: 'ShieldCheck',
    short_desc_en: 'Complete IP & smart wireless CCTV installation, NVR setup, and remote mobile viewing for homes, shops, and offices.',
    short_desc_ne: 'घर, पसल तथा कार्यालयका लागि अत्याधुनिक सीसीटीभी क्यामेरा जडान र मोबाइलबाटै हेर्न मिल्ने प्रविधि।',
    display_order: 1,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000002',
    title_en: 'Computer & Laptop Repair',
    title_ne: 'कम्प्युटर तथा ल्यापटप मर्मत',
    slug: 'laptop-pc-repair',
    icon_name: 'Laptop',
    short_desc_en: 'Certified chip-level hardware repair, motherboard diagnostics, SSD speed acceleration, and Windows software setup.',
    short_desc_ne: 'सबै प्रकारका ल्यापटप तथा कम्प्युटरको चिप-लेभल मर्मत, नयाँ विन्डोज र एसएसडी अपग्रेड सेवा।',
    display_order: 2,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000003',
    title_en: 'Printer & Photocopier Maintenance',
    title_ne: 'प्रिन्टर तथा फोटोकपी सेवा',
    slug: 'printer-maintenance',
    icon_name: 'Printer',
    short_desc_en: 'Laser printer repair, ink tank alignment, commercial photocopier maintenance, and original toner refills.',
    short_desc_ne: 'प्रिन्टर मर्मत, टोनर रिफिल तथा फोटोकपी मेसिनको नियमित प्राविधिक सर्भिसिङ।',
    display_order: 3,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000004',
    title_en: 'Networking & Internet Solutions',
    title_ne: 'नेटवर्किङ तथा इन्टरनेट पूर्वाधार',
    slug: 'networking-infrastructure',
    icon_name: 'Network',
    short_desc_en: 'Structured LAN cabling, enterprise WiFi access points, fiber optic connections, and secure router configurations.',
    short_desc_ne: 'कार्यालय तथा संस्थागत भवनहरूमा उच्च गतिको सुरक्षित इन्टरनेट तथा नेटवर्क व्यवस्थापन।',
    display_order: 4,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000005',
    title_en: 'Biometric Attendance Systems',
    title_ne: 'डिजिटल हाजिरी तथा बायोमेट्रिक',
    slug: 'biometric-attendance',
    icon_name: 'Fingerprint',
    short_desc_en: 'Automated facial recognition, fingerprint time-clocks, and automated payroll reporting software.',
    short_desc_ne: 'डिजिटल फिंगरप्रिन्ट र फेस रिकग्निसन हाजिरी मेसिन जडान तथा सफ्टवेयर सेटअप।',
    display_order: 5,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000006',
    title_en: 'Intercom & EPABX Systems',
    title_ne: 'इन्टरकम तथा टेलिफोन प्रणाली',
    slug: 'intercom-systems',
    icon_name: 'PhoneCall',
    short_desc_en: 'Internal communication voice telephone wiring and PBX exchanges for hotels, offices, and residences.',
    short_desc_ne: 'अफिस तथा होटलहरूका लागि आन्तरिक टेलिफोन तथा इन्टरकम व्यवस्थापन।',
    display_order: 6,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000007',
    title_en: 'Power Backup & Inverter Systems',
    title_ne: 'पावर ब्याकअप तथा इन्भर्टर',
    slug: 'power-backup-solutions',
    icon_name: 'Zap',
    short_desc_en: 'Industrial online UPS, solar hybrid inverters, and tubular batteries ensuring 24/7 power protection.',
    short_desc_ne: 'लोडसेडिङबाट सुरक्षित रहन अनलाइन यूपीएस र इन्भर्टर जडान सेवा।',
    display_order: 7,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000008',
    title_en: 'Digital LED Sign Boards',
    title_ne: 'डिजिटल एलईडी सूचना बोर्ड',
    slug: 'digital-led-boards',
    icon_name: 'Monitor',
    short_desc_en: 'Custom programmable LED scrolling signboards, notice boards, and commercial displays for shops.',
    short_desc_ne: 'पसल तथा कार्यालयका लागि आकर्षक डिजिटल एलईडी बोर्ड निर्माण तथा प्रोग्रामिङ।',
    display_order: 8,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000009',
    title_en: 'Projector & AV Setup',
    title_ne: 'प्रोजेक्टर तथा अडियो-भिजुअल',
    slug: 'projector-av-systems',
    icon_name: 'Tv',
    short_desc_en: 'Conference room projector mounting, motorized screens, and audio sound system installation.',
    short_desc_ne: 'बैठक तथा सम्मेलन कक्षका लागि प्रोजेक्टर र साउन्ड सिस्टम जडान।',
    display_order: 9,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000010',
    title_en: 'Note Counting & UV Detection',
    title_ne: 'नोट गन्ने मेसिन सेवा',
    slug: 'note-counting-machines',
    icon_name: 'Coins',
    short_desc_en: 'High-speed automatic currency counters with UV/MG magnetic counterfeit detection for businesses.',
    short_desc_ne: 'बैंक तथा वित्तीय संस्थाका लागि नक्कली नोट पत्ता लगाउने उच्च गतिको नोट काउन्टिङ मेसिन।',
    display_order: 10,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000011',
    title_en: 'On-Site Home & Office Visit Support',
    title_ne: 'घर तथा कार्यालयमा अन-साइट सेवा',
    slug: 'onsite-support',
    icon_name: 'Home',
    short_desc_en: 'Trained technician visits to your location anywhere across Ramechhap with road access for hardware inspection.',
    short_desc_ne: 'तपाईंको घर वा कार्यालयमै दक्ष प्राविधिक पुगेर समस्या समाधान गर्ने सेवा।',
    display_order: 11,
    is_active: true,
    created_at: '',
  },
  {
    id: 'e1000000-0000-0000-0000-000000000012',
    title_en: 'Remote Desk Support',
    title_ne: 'रिमोट डेस्क सपोर्ट सेवा',
    slug: 'remote-desk-support',
    icon_name: 'Headphones',
    short_desc_en: 'Fast remote desktop assistance for software installation, driver fixing, virus removal, and billing setup.',
    short_desc_ne: 'इन्टरनेटमार्फत तत्काल कम्प्युटर समस्या समाधान गर्ने रिमोट सपोर्ट सेवा।',
    display_order: 12,
    is_active: true,
    created_at: '',
  },
];

const iconMap: Record<string, React.ReactNode> = {
  ShieldCheck: <ShieldCheck className="w-6 h-6 text-brand-600" />,
  Laptop: <Laptop className="w-6 h-6 text-brand-600" />,
  Printer: <Printer className="w-6 h-6 text-brand-600" />,
  Network: <Network className="w-6 h-6 text-brand-600" />,
  Fingerprint: <Fingerprint className="w-6 h-6 text-brand-600" />,
  PhoneCall: <PhoneCall className="w-6 h-6 text-brand-600" />,
  Zap: <Zap className="w-6 h-6 text-brand-600" />,
  Monitor: <Monitor className="w-6 h-6 text-brand-600" />,
  Tv: <Tv className="w-6 h-6 text-brand-600" />,
  Coins: <Coins className="w-6 h-6 text-brand-600" />,
  Home: <Home className="w-6 h-6 text-brand-600" />,
  Headphones: <Headphones className="w-6 h-6 text-brand-600" />,
};

interface ServicesSectionProps {
  services?: ServiceItem[];
  limit?: number;
}

export default function ServicesSection({ services, limit }: ServicesSectionProps) {
  const { language, t } = useLanguage();
  let list = services && services.length > 0 ? services : AUDITED_SERVICES_FALLBACK;
  if (limit) {
    list = list.slice(0, limit);
  }

  return (
    <section className="py-16 bg-slate-50 dark:bg-slate-900/60 border-t border-slate-200 dark:border-slate-800 transition-colors">
      <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-12 gap-4">
          <div>
            <span className="text-xs font-bold text-brand-600 dark:text-brand-300 uppercase tracking-wider bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800/60 px-3 py-1 rounded-full">
              {language === 'ne' ? 'हाम्रो विशेषज्ञता' : 'Our Capabilities'}
            </span>
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white mt-2">
              {t.home.servicesTitle}
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-xl">
              {t.home.servicesSubtitle}
            </p>
          </div>
          <Link
            href="/services"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand-600 dark:text-brand-400 hover:text-brand-700 dark:hover:text-brand-300 transition"
          >
            <span>{language === 'ne' ? 'सबै सेवाहरू हेर्नुहोस्' : 'Explore All Services'}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {/* Location & Delivery Coverage Distinction Banner */}
        <div className="mb-8 p-4 bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="p-2 bg-amber-50 dark:bg-amber-950/70 border border-amber-200 dark:border-amber-800 rounded-xl text-amber-700 dark:text-amber-400 font-bold text-xs flex items-center gap-1.5 shrink-0">
              🛠️ {language === 'ne' ? 'प्राविधिक सेवा क्षेत्र' : 'Service Location'}
            </span>
            <p className="text-xs text-slate-700 dark:text-slate-300">
              {language === 'ne'
                ? 'कम्प्युटर मर्मत, सीसीटीभी जडान र प्राविधिक अन-साइट सेवाहरू केवल मन्थली-१, रामेछापमा मात्र उपलब्ध छन्।'
                : 'Hardware repair, CCTV installation, and on-site technical services are strictly provided within Manthali-1, Ramechhap.'}
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/70 border border-emerald-200 dark:border-emerald-800 px-3 py-1.5 rounded-xl shrink-0">
            🚚 {language === 'ne' ? 'डेलिभरी प्रणाली: नेपालभर उपलब्ध' : 'Product Delivery: Available All Over Nepal'}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {list.map((service) => {
            const title =
              language === 'ne' && service.title_ne ? service.title_ne : service.title_en;
            const desc =
              language === 'ne' && service.short_desc_ne
                ? service.short_desc_ne
                : service.short_desc_en;

            return (
              <div
                key={service.id}
                className="bg-white dark:bg-slate-800/80 rounded-2xl p-6 border border-slate-200/90 dark:border-slate-700/80 shadow-sm hover:shadow-md hover:border-brand-200 dark:hover:border-brand-500 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="w-12 h-12 rounded-xl bg-brand-50 dark:bg-brand-950/80 border border-brand-100 dark:border-brand-800 flex items-center justify-center mb-4">
                    {iconMap[service.icon_name] || (
                      <ShieldCheck className="w-6 h-6 text-brand-600 dark:text-brand-400" />
                    )}
                  </div>
                  <h3 className="font-bold text-base text-slate-900 dark:text-white mb-2">
                    {title}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                    {desc}
                  </p>
                </div>

                <Link
                  href={`/contact?service=${encodeURIComponent(service.slug)}`}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-brand-600 dark:text-brand-400 hover:text-brand-700 dark:hover:text-brand-300 pt-3 border-t border-slate-100 dark:border-slate-700"
                >
                  <span>{language === 'ne' ? 'परामर्श लिनुहोस्' : 'Request Service'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
