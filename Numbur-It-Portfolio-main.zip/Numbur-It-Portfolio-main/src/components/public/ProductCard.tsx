'use client';

import React from 'react';
import Link from 'next/link';
import SafeImage from '@/components/ui/SafeImage';
import { Product } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import { useCart } from '@/lib/cart/context';
import { ShoppingCart, Check } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { language, t } = useLanguage();
  const { addToCart } = useCart();
  const [added, setAdded] = React.useState(false);

  const title = language === 'ne' && product.name_ne ? product.name_ne : product.name_en;

  const hasDiscount =
    product.discount_price && product.discount_price < product.selling_price;
  const currentPrice = hasDiscount ? product.discount_price! : product.selling_price;

  // Stock status logic (only in stock vs out of stock publicly)
  const isAvailable =
    product.inventory?.in_stock ??
    (product.inventory?.available_quantity === undefined ||
      product.inventory.available_quantity > 0);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    if (!isAvailable) return;
    addToCart(product, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  const firstImage =
    Array.isArray(product.images) && product.images.length > 0 ? product.images[0] : null;
  const secondaryImage =
    typeof firstImage === 'string' ? firstImage : (firstImage as { image_url?: string } | null)?.image_url;
  const imageUrl = product.primary_image_url || secondaryImage || null;

  const hasImage = Boolean(imageUrl && imageUrl.trim().length > 0 && !imageUrl.startsWith('/images/'));

  return (
    <div className="group bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 shadow-sm hover:shadow-lg dark:hover:shadow-slate-950/60 transition-all duration-200 flex flex-col overflow-hidden relative">
      {/* Top Badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1">
        {product.is_new_arrival && (
          <span
            suppressHydrationWarning
            className="bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm"
          >
            {language === 'ne' ? 'नयाँ' : 'New'}
          </span>
        )}
        {product.is_bestseller && (
          <span
            suppressHydrationWarning
            className="bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm"
          >
            {language === 'ne' ? 'बेस्टसेलर' : 'Best Seller'}
          </span>
        )}
      </div>

      {/* Image Container */}
      <Link
        href={`/products/${product.slug}`}
        className={`relative block w-full pt-[75%] ${hasImage ? 'bg-transparent' : 'bg-slate-50 dark:bg-slate-800/40'} overflow-hidden`}
      >
        <SafeImage
          src={imageUrl}
          alt={title}
          fill
          type="product"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          className={
            hasImage
              ? 'object-cover w-full h-full p-0 group-hover:scale-105 transition-transform duration-500'
              : 'object-contain p-4 group-hover:scale-105 transition-transform duration-300'
          }
        />
        {/* Availability Badge */}
        <div className="absolute bottom-2 right-2">
          {isAvailable ? (
            <span className="bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-[10px] font-semibold px-2 py-0.5 rounded-full">
              {t.common.inStock}
            </span>
          ) : (
            <span className="bg-red-50 dark:bg-red-950/80 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800 text-[10px] font-semibold px-2 py-0.5 rounded-full">
              {t.common.outOfStock}
            </span>
          )}
        </div>
      </Link>

      {/* Details Container */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Brand & SKU */}
          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mb-1">
            <span className="font-semibold text-brand-600 dark:text-brand-400 uppercase">
              {product.brand?.name || 'GENUINE'}
            </span>
            <span className="font-mono text-slate-400 dark:text-slate-500">SKU: {product.sku}</span>
          </div>

          {/* Title */}
          <Link
            href={`/products/${product.slug}`}
            className="block font-bold text-sm md:text-base text-slate-900 dark:text-white group-hover:text-brand-500 dark:group-hover:text-brand-400 transition-colors line-clamp-2 mb-1.5"
          >
            {title}
          </Link>
        </div>

        {/* Pricing & Actions */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 mt-2">
          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-lg md:text-xl font-extrabold text-slate-900 dark:text-white">
              {t.common.currency} {currentPrice.toLocaleString('en-IN')}
            </span>
            {hasDiscount && (
              <span className="text-xs text-slate-400 dark:text-slate-500 line-through">
                {t.common.currency} {product.selling_price.toLocaleString('en-IN')}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleAddToCart}
              disabled={!isAvailable}
              className={`flex-1 flex items-center justify-center gap-1.5 text-xs font-semibold py-2.5 px-3 rounded-xl transition ${
                added
                  ? 'bg-emerald-600 text-white'
                  : isAvailable
                  ? 'bg-brand-500 hover:bg-brand-600 text-white shadow-xs active:scale-95'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed border border-slate-200 dark:border-slate-700'
              }`}
            >
              {added ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Added to Cart</span>
                </>
              ) : (
                <>
                  <ShoppingCart className="w-3.5 h-3.5" />
                  <span>{isAvailable ? t.common.addToCart : t.common.outOfStock}</span>
                </>
              )}
            </button>

            <Link
              href={`/products/${product.slug}`}
              className="text-xs font-semibold py-2.5 px-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-brand-500 dark:hover:border-brand-500 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition"
            >
              {language === 'ne' ? 'हेर्नुहोस्' : 'Details'}
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
