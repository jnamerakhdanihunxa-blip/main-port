'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import SafeImage from '@/components/ui/SafeImage';
import { StaffProfile } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import {
  Phone,
  Mail,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

// Audited Fallback staff profiles (includes all 5 official members with verified Cloudinary photos)
export const AUDITED_STAFF_FALLBACK: StaffProfile[] = [
  {
    id: 'a1000000-0000-0000-0000-000000000001',
    name: 'Mr. Niraz Sapkota',
    designation: 'Owner & Co-founder',
    department: 'Executive Management',
    bio_en:
      'Founder of Numbur iT Solution Pvt. Ltd. Leading IT infrastructure development, enterprise hardware supplies, and customer satisfaction across Ramechhap since 2069 BS.',
    bio_ne:
      'नम्बुर आइटी सोलुसनका संस्थापक। २०६९ सालदेखि रामेछाप जिल्लामा सूचना प्रविधि विस्तारमा क्रियाशील।',
    photo_url:
      'https://res.cloudinary.com/ytzmwyvj/image/upload/v1790175915/numbur-it/staff/d29vqdljh4guuq1jfg98.png',
    public_contact_phone: '9854040821',
    public_contact_email: 'numburitsolution1@gmail.com',
    public_address: 'Khimti-7, Ramechhap',
    display_order: 1,
    is_public: true,
    created_at: '',
    updated_at: '',
  },
  {
    id: 'a1000000-0000-0000-0000-000000000002',
    name: 'Mr. Tikaram',
    designation: 'Co-sub founder & Head Accountant',
    department: 'Finance & Administration',
    bio_en:
      'Overseeing financial administration, accounting operations, supplier settlements, and commercial billing.',
    bio_ne: 'कम्पनीको आर्थिक प्रशासन तथा लेखा व्यवस्थापनको जिम्मेवारी।',
    photo_url:
      'https://res.cloudinary.com/ytzmwyvj/image/upload/v1790175926/numbur-it/staff/qx7yx3kl5gfdmxm7pgnp.png',
    public_contact_phone: '9861561229',
    public_contact_email: 'numburitsolution1@gmail.com',
    public_address: 'Sindhuli',
    display_order: 2,
    is_public: true,
    created_at: '',
    updated_at: '',
  },
  {
    id: 'a1000000-0000-0000-0000-000000000003',
    name: 'Mr. Rohit Prasad Adhikari',
    designation: 'IT Technician & Technical Lead',
    department: 'Technical Department',
    bio_en:
      'Expert hardware diagnostics, CCTV surveillance architecture, network installation, and on-site client technical troubleshooting.',
    bio_ne:
      'हार्डवेयर मर्मत, सीसीटीभी क्यामेरा इन्स्टलेसन र नेटवर्किङ प्राविधिक विशेषज्ञ।',
    photo_url:
      'https://res.cloudinary.com/ytzmwyvj/image/upload/v1790175939/numbur-it/staff/mtxmw0ulceeyzcpl6gnw.png',
    public_contact_phone: '9846141110',
    public_contact_email: 'rohitprasadadhikari11@gmail.com',
    public_address: 'Mithila Mun-11, Dhanusha',
    display_order: 3,
    is_public: true,
    created_at: '',
    updated_at: '',
  },
  {
    id: 'a1000000-0000-0000-0000-000000000004',
    name: 'Mrs. Usha Karki',
    designation: 'Accountant',
    department: 'Accountant Department',
    bio_en:
      'Handling customer invoices, store accounts reconciliation, order advance payments verification, and client reception.',
    bio_ne: 'ग्राहक बिलिङ, इनभ्वाइसिङ र स्टोर एकाउन्टिङ व्यवस्थापन।',
    photo_url:
      'https://res.cloudinary.com/ytzmwyvj/image/upload/v1790175962/numbur-it/staff/chgf4pqkhip9vbhfg7tl.jpg',
    public_contact_phone: '9765990808',
    public_contact_email: 'numburitsolution1@gmail.com',
    public_address: 'Manthali-2, Ramechhap',
    display_order: 4,
    is_public: true,
    created_at: '',
    updated_at: '',
  },
  {
    id: '04d16a2b-055a-489b-ac27-0b7a10274bee',
    name: 'Krishal Shrestha',
    designation: 'Management Team',
    department: 'Management',
    bio_en:
      'Supporting management operations, inventory synchronization, digital ordering, and client customer support.',
    bio_ne:
      'व्यवस्थापकीय कार्य, इन्भेन्ट्री व्यवस्थापन र ग्राहक सेवा सहजीकरण।',
    photo_url:
      'https://res.cloudinary.com/ytzmwyvj/image/upload/v1790181175/numbur-it/staff/lcovlobeq1p0iptjngei.jpg',
    public_contact_phone: '9864029898',
    public_contact_email: 'numburitsolution1@gmail.com',
    public_address: 'Kadaghari, Kathmandu / Manthali',
    display_order: 5,
    is_public: true,
    created_at: '',
    updated_at: '',
  },
];

interface TeamSectionProps {
  staffList?: StaffProfile[];
}

export default function TeamSection({ staffList }: TeamSectionProps) {
  const { language, t } = useLanguage();
  const list = staffList && staffList.length > 0 ? staffList : AUDITED_STAFF_FALLBACK;

  const publicStaff = list
    .filter((s) => s.is_public)
    .sort((a, b) => a.display_order - b.display_order);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState(0);

  const containerRef = useRef<HTMLDivElement>(null);
  const dragStartX = useRef(0);

  const totalMembers = publicStaff.length;

  const handlePrev = useCallback(() => {
    setCurrentIndex((prev) => (prev > 0 ? prev - 1 : prev));
  }, []);

  const handleNext = useCallback(() => {
    setCurrentIndex((prev) => (prev < totalMembers - 1 ? prev + 1 : prev));
  }, [totalMembers]);

  // Autoplay every 5 seconds (pauses on hover or drag)
  useEffect(() => {
    if (isHovered || isDragging || totalMembers <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev < totalMembers - 1 ? prev + 1 : 0));
    }, 5000);

    return () => clearInterval(interval);
  }, [isHovered, isDragging, totalMembers]);

  // Touch and mouse swipe handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    setIsDragging(true);
    dragStartX.current = e.touches[0].clientX;
    setDragOffset(0);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging) return;
    const currentX = e.touches[0].clientX;
    const diff = currentX - dragStartX.current;
    setDragOffset(diff);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStartX.current = e.clientX;
    setDragOffset(0);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    const diff = e.clientX - dragStartX.current;
    setDragOffset(diff);
  };

  const handleDragEnd = () => {
    if (!isDragging) return;
    setIsDragging(false);
    const threshold = 60;

    if (dragOffset < -threshold && currentIndex < totalMembers - 1) {
      setCurrentIndex((prev) => prev + 1);
    } else if (dragOffset > threshold && currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
    setDragOffset(0);
  };

  const canPrev = currentIndex > 0;
  const canNext = currentIndex < totalMembers - 1;

  return (
    <section className="py-16 sm:py-20 lg:py-24 bg-slate-50/70 dark:bg-slate-900/60 border-t border-slate-200/80 dark:border-slate-800 overflow-hidden transition-colors">
      <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16">
        {/* Section Header with Refined Typography & Top-Right Navigation Arrows */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-8 lg:mb-12">
          <div className="max-w-2xl">
            <span className="text-[11px] font-extrabold uppercase tracking-widest text-brand-600 dark:text-brand-300 bg-brand-50 dark:bg-brand-950/60 border border-brand-200/80 dark:border-brand-800/60 px-3 py-1 rounded-full inline-block">
              {language === 'ne' ? 'हाम्रो आधिकारिक टोली' : 'Leadership & Experts'}
            </span>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 dark:text-white mt-2.5 tracking-tight">
              {t.home.teamTitle}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1.5 max-w-xl leading-relaxed">
              {t.home.teamSubtitle}
            </p>
          </div>

          {/* Top-Right Navigation Controls & Member Counter */}
          {totalMembers > 1 && (
            <div className="flex items-center gap-3 self-end sm:self-auto shrink-0">
              <span className="text-xs font-mono font-bold text-slate-400 dark:text-slate-500 mr-1">
                {String(currentIndex + 1).padStart(2, '0')} / {String(totalMembers).padStart(2, '0')}
              </span>
              <button
                type="button"
                onClick={handlePrev}
                disabled={!canPrev}
                className={`w-10 h-10 sm:w-11 sm:h-11 rounded-full border flex items-center justify-center transition-all duration-200 ${
                  canPrev
                    ? 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-900 dark:hover:bg-slate-700 hover:text-white shadow-sm active:scale-95 cursor-pointer'
                    : 'bg-slate-100 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-300 dark:text-slate-600 cursor-not-allowed opacity-40'
                }`}
                aria-label="Previous team member"
                title="Previous member"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                type="button"
                onClick={handleNext}
                disabled={!canNext}
                className={`w-10 h-10 sm:w-11 sm:h-11 rounded-full border flex items-center justify-center transition-all duration-200 ${
                  canNext
                    ? 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-900 dark:hover:bg-slate-700 hover:text-white shadow-sm active:scale-95 cursor-pointer'
                    : 'bg-slate-100 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 text-slate-300 dark:text-slate-600 cursor-not-allowed opacity-40'
                }`}
                aria-label="Next team member"
                title="Next member"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>

        {/* Carousel Viewport: Single Member at a Time (Photo Card Left + Description Card Right) */}
        <div
          ref={containerRef}
          className="relative overflow-hidden select-none cursor-grab active:cursor-grabbing"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => {
            setIsHovered(false);
            if (isDragging) handleDragEnd();
          }}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleDragEnd}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleDragEnd}
        >
          {/* Sliding Track */}
          <div
            className="flex will-change-transform"
            style={{
              transform: `translateX(calc(-${currentIndex * 100}% + ${dragOffset}px))`,
              transition: isDragging
                ? 'none'
                : 'transform 600ms cubic-bezier(0.25, 1, 0.5, 1)',
            }}
          >
            {publicStaff.map((member, idx) => {
              const bio =
                language === 'ne' && member.bio_ne ? member.bio_ne : member.bio_en;
              const initials = member.name
                .replace(/^(Mr\.|Mrs\.|Ms\.)\s*/i, '')
                .split(' ')
                .map((n) => n[0])
                .filter(Boolean)
                .slice(0, 2)
                .join('');

              return (
                <div
                  key={member.id}
                  className="w-full shrink-0 px-1 sm:px-2"
                >
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 lg:gap-8 items-stretch max-w-5xl mx-auto">
                    {/* LEFT: PHOTO CARD */}
                    <div className="md:col-span-5 bg-white dark:bg-slate-800/90 rounded-3xl border border-slate-200/90 dark:border-slate-700/80 shadow-sm hover:shadow-md transition-shadow p-3.5 sm:p-4 flex flex-col justify-center">
                      <div className="relative w-full aspect-[4/5] sm:aspect-square md:aspect-[4/5] rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-900 shadow-inner group">
                        <SafeImage
                          src={member.photo_url}
                          alt={member.name}
                          fill
                          type="avatar"
                          fallbackText={initials}
                          priority={idx === 0}
                          sizes="(max-width: 768px) 90vw, 420px"
                          className="object-cover object-top transition-transform duration-700 group-hover:scale-105"
                        />

                        {/* Soft gradient overlay on the lower portion */}
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-slate-950/15 to-transparent pointer-events-none" />

                        {/* Department Badge Over Lower Portion of the Image */}
                        {member.department && (
                          <div className="absolute bottom-4 left-4 z-10">
                            <span className="inline-flex items-center bg-slate-950/90 backdrop-blur-md text-white text-xs font-semibold px-3 py-1.5 rounded-xl border border-white/15 shadow-lg">
                              {member.department}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* RIGHT: DESCRIPTION & DETAILS CARD */}
                    <div className="md:col-span-7 bg-white dark:bg-slate-800/90 rounded-3xl border border-slate-200/90 dark:border-slate-700/80 shadow-sm hover:shadow-md transition-shadow p-6 sm:p-8 lg:p-10 flex flex-col justify-between">
                      <div>
                        {/* Member Role Pill & Sequence Indicator */}
                        <div className="flex items-center justify-between gap-3 mb-4">
                          <span className="inline-flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-widest text-brand-600 dark:text-brand-300 bg-brand-50 dark:bg-brand-950/60 border border-brand-200/80 dark:border-brand-800/60 px-3 py-1 rounded-full">
                            <Sparkles className="w-3 h-3 text-brand-500" />
                            <span>{language === 'ne' ? 'नम्बुर आइटी टिम सदस्य' : 'Numbur iT Leadership'}</span>
                          </span>
                          <span className="text-xs font-mono font-bold text-slate-400 dark:text-slate-500">
                            {String(idx + 1).padStart(2, '0')} / {String(totalMembers).padStart(2, '0')}
                          </span>
                        </div>

                        {/* Member Name */}
                        <h3 className="text-2xl sm:text-3xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tight leading-tight">
                          {member.name}
                        </h3>

                        {/* Role / Designation */}
                        <p className="text-sm sm:text-base font-bold text-brand-600 dark:text-brand-400 mt-1">
                          {member.designation}
                        </p>

                        {/* Full Professional Description */}
                        {bio && (
                          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-4 leading-relaxed whitespace-pre-line">
                            {bio}
                          </p>
                        )}
                      </div>

                      {/* Contact & Location Details - Shown Directly in the Preview */}
                      <div className="pt-6 mt-6 border-t border-slate-100 dark:border-slate-700 space-y-3">
                        {member.public_contact_phone && (
                          <div className="flex items-center justify-between text-xs sm:text-sm bg-slate-50 dark:bg-slate-900/80 p-3 rounded-2xl border border-slate-100/90 dark:border-slate-700/80">
                            <div className="flex items-center gap-2.5 text-slate-700 dark:text-slate-200 font-mono font-semibold">
                              <Phone className="w-4 h-4 text-brand-600 dark:text-brand-400 shrink-0" />
                              <span>{member.public_contact_phone}</span>
                            </div>
                            <a
                              href={`tel:${member.public_contact_phone}`}
                              className="text-xs font-bold text-brand-600 dark:text-brand-300 hover:text-white dark:hover:text-white bg-brand-50 dark:bg-brand-950/60 hover:bg-brand-600 dark:hover:bg-brand-600 px-3 py-1.5 rounded-xl border border-brand-200 dark:border-brand-800 hover:border-brand-600 transition"
                            >
                              {language === 'ne' ? 'कल गर्नुहोस्' : 'Call Now'}
                            </a>
                          </div>
                        )}

                        {member.public_contact_email && (
                          <div className="flex items-center justify-between text-xs sm:text-sm bg-slate-50 dark:bg-slate-900/80 p-3 rounded-2xl border border-slate-100/90 dark:border-slate-700/80">
                            <div className="flex items-center gap-2.5 text-slate-700 dark:text-slate-200 font-medium truncate max-w-[220px] sm:max-w-[280px]">
                              <Mail className="w-4 h-4 text-brand-600 dark:text-brand-400 shrink-0" />
                              <span className="truncate">{member.public_contact_email}</span>
                            </div>
                            <a
                              href={`mailto:${member.public_contact_email}`}
                              className="text-xs font-bold text-brand-600 dark:text-brand-300 hover:text-white dark:hover:text-white bg-brand-50 dark:bg-brand-950/60 hover:bg-brand-600 dark:hover:bg-brand-600 px-3 py-1.5 rounded-xl border border-brand-200 dark:border-brand-800 hover:border-brand-600 transition shrink-0"
                            >
                              {language === 'ne' ? 'इमेल' : 'Email'}
                            </a>
                          </div>
                        )}

                        {member.public_address && (
                          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 px-1 pt-1">
                            <MapPin className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500 shrink-0" />
                            <span>{member.public_address}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Carousel Bottom Pagination Dots */}
        {totalMembers > 1 && (
          <div className="flex items-center justify-center gap-2 mt-8">
            {publicStaff.map((_, dotIdx) => (
              <button
                key={dotIdx}
                type="button"
                onClick={() => setCurrentIndex(dotIdx)}
                className={`transition-all duration-300 rounded-full ${
                  currentIndex === dotIdx
                    ? 'w-8 h-2.5 bg-brand-600'
                    : 'w-2.5 h-2.5 bg-slate-300 dark:bg-slate-700 hover:bg-slate-400 dark:hover:bg-slate-600'
                }`}
                aria-label={`Go to team member ${dotIdx + 1}`}
              />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
