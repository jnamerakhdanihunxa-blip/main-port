'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useLanguage } from '@/lib/i18n/context';
import { useCart } from '@/lib/cart/context';
import { useTheme } from '@/lib/theme/context';
import SafeImage from '@/components/ui/SafeImage';
import {
  Phone,
  Mail,
  MapPin,
  ShoppingCart,
  Search,
  Menu,
  X,
  Globe,
  Sun,
  Moon,
  Truck,
  Wrench,
} from 'lucide-react';

export default function Header() {
  const { language, setLanguage, t } = useLanguage();
  const { totalItems } = useCart();
  const { theme, toggleTheme } = useTheme();
  const pathname = usePathname();
  const router = useRouter();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [siteLogo, setSiteLogo] = useState('');

  // Sync search input with URL search param on pathname/navigation changes
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const q = params.get('q');
      if (q !== null) {
        setSearchQuery(q);
      } else if (pathname !== '/products') {
        setSearchQuery('');
      }
    }
  }, [pathname]);

  React.useEffect(() => {
    async function loadSettings() {
      try {
        const res = await fetch('/api/settings', { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data.settings?.site_logo_url) {
            setSiteLogo(data.settings.site_logo_url);
          }
        }
      } catch (err) {
        console.warn('Could not load dynamic logo in header:', err);
      }
    }
    loadSettings();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = searchQuery.trim();
    if (query) {
      router.push(`/products?q=${encodeURIComponent(query)}`);
      setMobileMenuOpen(false);
    } else {
      router.push('/products');
      setMobileMenuOpen(false);
    }
  };

  const navLinks = [
    { name: t.nav.home, href: '/' },
    { name: t.nav.allProducts, href: '/products' },
    { name: t.nav.categories, href: '/categories' },
    { name: t.nav.services, href: '/services' },
    { name: t.nav.offers, href: '/offers' },
    { name: t.nav.gallery, href: '/gallery' },
    { name: t.nav.about, href: '/about' },
    { name: t.nav.contact, href: '/contact' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md shadow-sm border-b border-slate-200/90 dark:border-slate-800 transition-colors duration-200">
      {/* Main Navbar Row - Full Width Fluid Space */}
      <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-3.5 sm:py-4">
        <div className="flex items-center justify-between gap-4 xl:gap-8">
          {/* Logo / Brand - High Visibility */}
          <Link href="/" className="flex items-center gap-3 group shrink-0">
            {siteLogo ? (
              <div className="relative w-11 h-11 sm:w-13 sm:h-13 rounded-2xl overflow-hidden shrink-0 border border-slate-200 dark:border-slate-700 bg-white p-1 shadow-xs group-hover:scale-105 transition-transform">
                <SafeImage
                  src={siteLogo}
                  alt="Numbur iT Solution"
                  fill
                  className="object-contain"
                />
              </div>
            ) : (
              <div className="w-11 h-11 sm:w-13 sm:h-13 rounded-2xl bg-brand-500 flex items-center justify-center text-white shadow-md font-black text-2xl sm:text-3xl group-hover:scale-105 transition-transform">
                N
              </div>
            )}
            <div>
              <span className="font-black text-xl sm:text-2xl tracking-tight text-slate-900 dark:text-white block leading-tight">
                Numbur <span className="text-brand-500 dark:text-brand-400">iT</span>
              </span>
              <span className="text-[10px] sm:text-xs tracking-wider text-slate-500 dark:text-slate-400 uppercase font-bold block">
                Solution Pvt. Ltd.
              </span>
            </div>
          </Link>

          {/* Search Bar - Professional & Expanded Size */}
          <form
            onSubmit={handleSearch}
            className="hidden lg:flex flex-1 max-w-xl xl:max-w-2xl 2xl:max-w-3xl mx-4 xl:mx-8 relative"
          >
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.nav.searchPlaceholder}
              className="w-full pl-12 pr-28 py-2.5 sm:py-3 text-sm sm:text-base rounded-full bg-slate-100/90 dark:bg-slate-800/90 border border-slate-200/90 dark:border-slate-700 text-slate-900 dark:text-white focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent transition placeholder:text-slate-400 dark:placeholder:text-slate-500 shadow-inner"
            />
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-3 sm:top-3.5" />
            <button
              type="submit"
              className="absolute right-1.5 top-1.5 px-5 py-1.5 sm:py-2 bg-brand-500 hover:bg-brand-600 text-white text-xs sm:text-sm font-bold rounded-full transition shadow-xs hover:shadow active:scale-95"
            >
              Search
            </button>
          </form>

          {/* Right Action Icons: Language Switcher, Theme Toggle, Cart, Mobile Menu */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Desktop Language Switcher (EN | नेपाली) */}
            <div className="hidden sm:flex items-center border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden bg-slate-100/80 dark:bg-slate-800/80 p-0.5 shadow-2xs">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                  language === 'en'
                    ? 'bg-brand-500 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-brand-600 dark:hover:text-white'
                }`}
              >
                EN
              </button>
              <button
                type="button"
                onClick={() => setLanguage('ne')}
                className={`px-2.5 py-1 text-xs font-bold rounded-lg transition ${
                  language === 'ne'
                    ? 'bg-brand-500 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-300 hover:text-brand-600 dark:hover:text-white'
                }`}
              >
                नेपाली
              </button>
            </div>

            {/* Dark / Light Theme Toggle Button */}
            <button
              type="button"
              onClick={toggleTheme}
              aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
              title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
              className="relative p-2.5 sm:p-2.5 rounded-xl border transition-all duration-200 flex items-center justify-center bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:border-slate-700 dark:text-amber-400 shadow-2xs active:scale-95 cursor-pointer"
            >
              {theme === 'dark' ? (
                <Sun className="w-5 h-5 text-amber-400 transition-transform duration-300 rotate-0 hover:rotate-45" />
              ) : (
                <Moon className="w-5 h-5 text-slate-700 transition-transform duration-300 rotate-0 hover:-rotate-12" />
              )}
            </button>

            {/* Language toggle for mobile (screens < sm) */}
            <button
              type="button"
              onClick={() => setLanguage(language === 'en' ? 'ne' : 'en')}
              className="sm:hidden flex items-center gap-1 text-xs font-bold px-2.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 shadow-2xs"
            >
              <Globe className="w-3.5 h-3.5 text-brand-500 dark:text-brand-400" />
              <span>{language === 'en' ? 'नेपाली' : 'EN'}</span>
            </button>

            {/* Shopping Cart Button */}
            <Link
              href="/cart"
              className="relative flex items-center gap-2 bg-brand-50 hover:bg-brand-100 text-brand-700 dark:bg-brand-950/60 dark:hover:bg-brand-900/60 dark:text-brand-300 border border-brand-200/80 dark:border-brand-800/80 px-3.5 sm:px-4 py-2 sm:py-2.5 rounded-xl transition font-bold text-sm sm:text-base shadow-2xs active:scale-95"
            >
              <ShoppingCart className="w-5 h-5 text-brand-500 dark:text-brand-400" />
              <span className="hidden md:inline font-bold">{t.nav.cart}</span>
              {totalItems > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-red-600 text-white text-xs font-black rounded-full w-5 h-5 flex items-center justify-center shadow animate-pulse">
                  {totalItems}
                </span>
              )}
            </Link>

            {/* Mobile Menu Trigger */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2.5 rounded-xl text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Downside Container (Desktop): Navigation Links on Left, Coverage & Info Pills on Right */}
        <div className="hidden lg:flex items-center justify-between gap-3 xl:gap-4 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          {/* Navigation Links */}
          <nav className="flex items-center space-x-1 xl:space-x-1.5 text-[13px] xl:text-[14px] 2xl:text-[15px] font-bold shrink-0">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`px-3 py-1.5 rounded-xl transition duration-150 ${
                    isActive
                      ? 'text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-950/70 font-black shadow-2xs'
                      : 'text-slate-700 dark:text-slate-300 hover:text-brand-600 dark:hover:text-brand-400 hover:bg-slate-100 dark:hover:bg-slate-800/70'
                  }`}
                >
                  {link.name}
                </Link>
              );
            })}
          </nav>

          {/* Adjusted Downside Info Cluster: Coverage Badges, Location, Phone, Milestone */}
          <div className="flex items-center space-x-2 xl:space-x-3 text-xs shrink-0">
            {/* Delivery All Over Nepal Pill */}
            <span className="inline-flex items-center gap-1.5 text-emerald-700 dark:text-emerald-300 font-bold bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/80 px-2.5 py-1 rounded-full text-[11px] xl:text-xs shrink-0 shadow-2xs">
              <Truck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <span>{language === 'ne' ? 'नेपालभर डेलिभरी' : 'Delivery All Over Nepal'}</span>
            </span>

            {/* Services: Manthali-1 Only Pill */}
            <span className="inline-flex items-center gap-1.5 text-amber-700 dark:text-amber-300 font-semibold bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800/80 px-2.5 py-1 rounded-full text-[11px] xl:text-xs shrink-0 shadow-2xs">
              <Wrench className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>{language === 'ne' ? 'सेवा: मन्थली-१ मात्र' : 'Services: Manthali-1 Only'}</span>
            </span>

            {/* Location */}
            <span className="hidden xl:inline-flex items-center gap-1 text-slate-600 dark:text-slate-300 text-[11px] xl:text-xs shrink-0">
              <MapPin className="w-3.5 h-3.5 text-brand-500 shrink-0" />
              <span>Manthali-1, Devkota Chowk</span>
            </span>

            {/* Phone */}
            <a
              href="tel:048540314"
              className="hidden 2xl:inline-flex items-center gap-1 text-slate-700 dark:text-slate-200 font-mono text-xs font-semibold hover:text-brand-600 dark:hover:text-brand-400 shrink-0 transition"
              title="Call Numbur iT Solution"
            >
              <Phone className="w-3.5 h-3.5 text-brand-500 shrink-0" />
              <span>048-540314</span>
            </a>

            {/* Serving Since Badge */}
            <span className="hidden 2xl:inline text-amber-600 dark:text-amber-400 font-bold text-[11px] shrink-0 tracking-tight">
              ★ {language === 'ne' ? '२०६९ देखि' : 'Since 2069 BS'}
            </span>
          </div>
        </div>
      </div>

      {/* Downside Container for Mobile / Tablet (< lg screens) */}
      <div className="lg:hidden flex items-center justify-between px-4 sm:px-6 py-2 bg-slate-50/90 dark:bg-slate-950/60 border-t border-slate-200/70 dark:border-slate-800/80 text-[11px] overflow-x-auto whitespace-nowrap gap-3 scrollbar-none">
        <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400 font-bold shrink-0">
          <Truck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
          <span>{language === 'ne' ? 'नेपालभर डेलिभरी' : 'Delivery All Over Nepal'}</span>
        </span>
        <span className="text-slate-300 dark:text-slate-700 shrink-0">|</span>
        <span className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-400 font-semibold shrink-0">
          <Wrench className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
          <span>{language === 'ne' ? 'सेवाहरू: मन्थली-१' : 'Services: Manthali-1'}</span>
        </span>
        <span className="text-slate-300 dark:text-slate-700 shrink-0">|</span>
        <a
          href="tel:048540314"
          className="inline-flex items-center gap-1 text-slate-600 dark:text-slate-300 font-mono font-bold shrink-0 hover:text-brand-500"
        >
          <Phone className="w-3 h-3 text-brand-500" />
          <span>048-540314</span>
        </a>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-4 space-y-4">
          <form onSubmit={handleSearch} className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.nav.searchPlaceholder}
              className="w-full pl-10 pr-4 py-2.5 text-sm rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white focus:outline-none"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          </form>

          <div className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`px-4 py-2.5 rounded-xl text-sm font-bold ${
                  pathname === link.href
                    ? 'text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-950/60 font-black'
                    : 'text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 space-y-1">
            <p>📍 Location: Manthali-1, Devkota Chowk, Ramechhap</p>
            <p className="text-emerald-600 dark:text-emerald-400 font-bold">🚚 Delivery System: Available All Over Nepal</p>
            <p className="text-amber-600 dark:text-amber-400 font-semibold">🛠️ Services: Strictly Manthali-1 Only</p>
            <p>📞 Call: 048-540314 / 9854040821</p>
            <p>✉️ numburitsolution1@gmail.com</p>
          </div>
        </div>
      )}
    </header>
  );
}
