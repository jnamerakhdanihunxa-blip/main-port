'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import SafeImage from '@/components/ui/SafeImage';
import { useLanguage } from '@/lib/i18n/context';
import { SiteBanner } from '@/types';
import {
  ArrowRight,
  ShieldCheck,
  Wrench,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  MessageCircle,
  Phone,
  Sparkles,
} from 'lucide-react';

export const FALLBACK_BANNERS: SiteBanner[] = [
  {
    id: 'f1000000-0000-0000-0000-000000000001',
    title_en: 'The Ultimate iT Solution is Numbur iT Solution',
    title_ne: 'अल्टिमेट आइटी सोलुसन - नम्बुर आइटी सोलुसन',
    subtitle_en:
      'Laptops, Desktops, CCTV Cameras, Printers, Power Backup, and Networking Systems in Manthali, Ramechhap since 2069 BS.',
    subtitle_ne:
      '२०६९ सालदेखि रामेछापमा कम्प्युटर, ल्यापटप, प्रिन्टर तथा सीसीटीभी क्यामेराको आधिकारिक बिक्रेता तथा मर्मत सेवा।',
    cta_text_en: 'Explore Catalog',
    cta_text_ne: 'सामानहरू हेर्नुहोस्',
    cta_link: '/products',
    image_url: '',
    banner_type: 'hero',
    display_order: 1,
    is_active: true,
  },
  {
    id: 'f1000000-0000-0000-0000-000000000002',
    title_en: 'Your Safety, Our Responsibility',
    title_ne: 'तपाईंको सुरक्षा, हाम्रो जिम्मेवारी',
    subtitle_en:
      'Complete CCTV surveillance systems for homes, offices, retail shops, and courtyards across Ramechhap at competitive prices.',
    subtitle_ne:
      'घर, पसल तथा कार्यालयका लागि विभिन्न ब्रान्डका सीसीटीभी क्यामेरा सुलभ मूल्यमा जडान तथा मर्मत।',
    cta_text_en: 'View CCTV Systems',
    cta_text_ne: 'सीसीटीभी हेर्नुहोस्',
    cta_link: '/categories/cctv-security',
    image_url: '',
    banner_type: 'hero',
    display_order: 2,
    is_active: true,
  },
  {
    id: 'f1000000-0000-0000-0000-000000000003',
    title_en: 'Your Hope, Our Trust',
    title_ne: 'तपाईंको आशा, हाम्रो विश्वास',
    subtitle_en:
      'Prompt on-site visits, certified hardware diagnostics, and genuine warranty with local physical presence.',
    subtitle_ne:
      'भरपर्दो वारेन्टी, गुणस्तरीय प्रविधि र घर/अफिसमै पुगेर दिइने छिटो छरितो प्राविधिक सेवा।',
    cta_text_en: 'Our Services',
    cta_text_ne: 'हाम्रा सेवाहरू',
    cta_link: '/services',
    image_url: '',
    banner_type: 'hero',
    display_order: 3,
    is_active: true,
  },
];

interface HeroSectionProps {
  banners?: SiteBanner[];
}

export default function HeroSection({ banners }: HeroSectionProps) {
  const { language } = useLanguage();
  const activeBanners =
    banners && banners.length > 0 ? banners.filter((b) => b.is_active) : FALLBACK_BANNERS;

  const validBanners = activeBanners.length > 0 ? activeBanners : FALLBACK_BANNERS;
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Auto-advance hero banner slider every 6.5 seconds
  useEffect(() => {
    if (isPaused || validBanners.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % validBanners.length);
    }, 6500);
    return () => clearInterval(timer);
  }, [isPaused, validBanners.length]);

  const currentBanner = validBanners[currentIndex] || validBanners[0];

  const title =
    language === 'ne' && currentBanner.title_ne
      ? currentBanner.title_ne
      : currentBanner.title_en;
  const subtitle =
    language === 'ne' && currentBanner.subtitle_ne
      ? currentBanner.subtitle_ne
      : currentBanner.subtitle_en;
  const ctaText =
    language === 'ne' && currentBanner.cta_text_ne
      ? currentBanner.cta_text_ne
      : currentBanner.cta_text_en || 'Explore Catalog';

  return (
    <div
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      className="relative bg-slate-950 text-white overflow-hidden min-h-[500px] sm:min-h-[540px] lg:min-h-[600px] flex items-center border-b border-slate-800 transition-colors duration-200"
    >
      {/* Background Image Container with Original Contrast Preservation */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        {currentBanner.image_url ? (
          <div className="relative w-full h-full">
            <SafeImage
              src={currentBanner.image_url}
              alt={title}
              fill
              priority
              type="banner"
              className="object-cover object-center transition-all duration-700 scale-100"
            />
            {/* Soft dark directional gradient on left for text legibility while preserving 100% original photo contrast on center/right */}
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-950/50 to-transparent/10" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-transparent to-transparent" />
          </div>
        ) : (
          <div className="absolute inset-0 bg-slate-950">
            <div className="absolute inset-0 bg-[radial-gradient(#1877f2_1.5px,transparent_1.5px)] [background-size:28px_28px] opacity-20" />
            <div className="absolute inset-0 bg-gradient-to-tr from-brand-950/60 via-slate-950 to-blue-950/40" />
          </div>
        )}
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16 py-16 sm:py-24">
        <div className="max-w-3xl">
          {/* Legacy & Quality Badge */}
          <div className="inline-flex items-center gap-2.5 bg-brand-950/75 border border-brand-500/40 text-brand-300 px-4 py-1.5 rounded-full text-xs font-bold tracking-wide uppercase mb-6 backdrop-blur-md shadow-md">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>
              {language === 'ne'
                ? '२०६९ देखि रामेछापको भरपर्दो प्रविधि साझेदार'
                : 'Trusted IT Partner in Ramechhap Since 2069 BS'}
            </span>
          </div>

          {/* Headline */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-[1.12] mb-5 drop-shadow-md">
            {title}
          </h1>

          {/* Subtitle */}
          <p className="text-base sm:text-lg lg:text-xl text-slate-200 mb-8 leading-relaxed font-normal max-w-2xl drop-shadow-xs">
            {subtitle}
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-4 items-center">
            <Link
              href={currentBanner.cta_link || '/products'}
              className="inline-flex items-center gap-2.5 bg-brand-500 hover:bg-brand-600 text-white font-extrabold text-sm sm:text-base px-7 py-3.5 rounded-2xl shadow-xl hover:shadow-brand-500/30 transition-all active:scale-95"
            >
              <span>{ctaText}</span>
              <ArrowRight className="w-4 h-4" />
            </Link>

            <Link
              href="/contact"
              className="inline-flex items-center gap-2 bg-slate-900/80 hover:bg-slate-800 text-slate-200 border border-slate-700/80 font-bold text-sm sm:text-base px-6 py-3.5 rounded-2xl transition backdrop-blur-md"
            >
              <span>
                {language === 'ne' ? 'सम्पर्क तथा सहयोग' : 'Direct Inquiry'}
              </span>
            </Link>
          </div>

          {/* Business Highlights Checklist */}
          <div className="mt-10 pt-6 border-t border-white/15 grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs sm:text-sm text-slate-200">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Genuine Warranty</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Local On-Site Repair</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>WhatsApp Direct Desk</span>
            </div>
          </div>
        </div>
      </div>

      {/* Slider Controls & Dots */}
      {validBanners.length > 1 && (
        <div className="absolute bottom-6 right-4 sm:right-6 md:right-8 xl:right-12 2xl:right-16 z-20 flex items-center gap-3 bg-slate-900/85 backdrop-blur-md px-3.5 py-2 rounded-2xl border border-slate-800 shadow-xl">
          <button
            type="button"
            onClick={() =>
              setCurrentIndex(
                (prev) => (prev - 1 + validBanners.length) % validBanners.length
              )
            }
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-brand-500 text-white flex items-center justify-center transition"
            aria-label="Previous Slide"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Dots Indicator */}
          <div className="flex items-center gap-1.5 px-1">
            {validBanners.map((_, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setCurrentIndex(idx)}
                className={`h-2 rounded-full transition-all ${
                  idx === currentIndex ? 'w-6 bg-brand-500' : 'w-2 bg-slate-600 hover:bg-slate-400'
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>

          <button
            type="button"
            onClick={() =>
              setCurrentIndex((prev) => (prev + 1) % validBanners.length)
            }
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-brand-500 text-white flex items-center justify-center transition"
            aria-label="Next Slide"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
}
