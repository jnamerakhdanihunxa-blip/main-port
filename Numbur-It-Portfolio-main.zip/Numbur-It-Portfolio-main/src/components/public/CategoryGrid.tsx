'use client';

import React from 'react';
import Link from 'next/link';
import SafeImage from '@/components/ui/SafeImage';
import { Category } from '@/types';
import { useLanguage } from '@/lib/i18n/context';
import {
  ArrowRight,
  Laptop,
  Video,
  Printer,
  Wifi,
  Zap,
  Layers,
  FileSpreadsheet,
} from 'lucide-react';

export const FALLBACK_CATEGORIES: Category[] = [
  {
    id: 'c1000000-0000-0000-0000-000000000001',
    name_en: 'CCTV & Security Systems',
    name_ne: 'सीसीटीभी र सुरक्षा प्रणाली',
    slug: 'cctv-security',
    description_en: 'Smart wireless & IP surveillance cameras, NVR/DVR systems.',
    image_url: '',
    display_order: 1,
    is_active: true,
    created_at: '',
    updated_at: '',
  },
  {
    id: 'c1000000-0000-0000-0000-000000000002',
    name_en: 'Laptops & Computers',
    name_ne: 'ल्यापटप र कम्प्युटर',
    slug: 'laptops-computers',
    description_en: 'Dell, HP, Lenovo laptops and custom desktop PCs.',
    image_url: '',
    display_order: 2,
    is_active: true,
    created_at: '',
    updated_at: '',
  },
  {
    id: 'c1000000-0000-0000-0000-000000000003',
    name_en: 'Printers & Photocopy',
    name_ne: 'प्रिन्टर र फोटोकपी मेसिन',
    slug: 'printers-copiers',
    description_en: 'Commercial photocopiers, laser printers, and cartridge refills.',
    image_url: '',
    display_order: 3,
    is_active: true,
    created_at: '',
    updated_at: '',
  },
  {
    id: 'c1000000-0000-0000-0000-000000000004',
    name_en: 'Networking & Wi-Fi',
    name_ne: 'नेटवर्किङ र वाइफाइ',
    slug: 'networking-solutions',
    description_en: 'High-speed gigabit routers, switches, and structured LAN cabling.',
    image_url: '',
    display_order: 4,
    is_active: true,
    created_at: '',
    updated_at: '',
  },
  {
    id: 'c1000000-0000-0000-0000-000000000005',
    name_en: 'Power Backup & Inverters',
    name_ne: 'पावर ब्याकअप र इन्भर्टर',
    slug: 'power-backup',
    description_en: 'Online UPS systems and heavy-duty inverters for 24/7 uptime.',
    image_url: '',
    display_order: 5,
    is_active: true,
    created_at: '',
    updated_at: '',
  },
  {
    id: 'c1000000-0000-0000-0000-000000000006',
    name_en: 'Office Automation',
    name_ne: 'कार्यालय अटोमेसन',
    slug: 'office-automation',
    description_en: 'Biometric attendance, note counting machines, and intercoms.',
    image_url: 'https://res.cloudinary.com/ytzmwyvj/image/upload/v1790181286/numbur-it/categories/mzqbx5cr0psvvkuejz5q.jpg',
    display_order: 6,
    is_active: true,
    created_at: '',
    updated_at: '',
  },
  {
    id: '71307256-6974-4d0f-85ca-1ad8b698cc59',
    name_en: 'demoo1',
    name_ne: 'demoo1',
    slug: 'demoo1',
    description_en: 'Demoo category',
    image_url: 'https://res.cloudinary.com/ytzmwyvj/image/upload/v1790181265/numbur-it/categories/fnzkmhddhrhwpoohlkaf.png',
    display_order: 7,
    is_active: true,
    created_at: '',
    updated_at: '',
  },
];

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  'cctv-security': <Video className="w-12 h-12 sm:w-14 sm:h-14 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
  'laptops-computers': <Laptop className="w-12 h-12 sm:w-14 sm:h-14 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
  'printers-copiers': <Printer className="w-12 h-12 sm:w-14 sm:h-14 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
  'networking-solutions': <Wifi className="w-12 h-12 sm:w-14 sm:h-14 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
  'power-backup': <Zap className="w-12 h-12 sm:w-14 sm:h-14 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
  'office-automation': <FileSpreadsheet className="w-12 h-12 sm:w-14 sm:h-14 text-brand-500 dark:text-brand-400 stroke-[1.75]" />,
};

interface CategoryGridProps {
  categories?: Category[];
}

export default function CategoryGrid({ categories }: CategoryGridProps) {
  const { language, t } = useLanguage();
  const list = categories && categories.length > 0 ? categories : FALLBACK_CATEGORIES;

  return (
    <section className="py-12 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800 transition-colors">
      <div className="w-full px-4 sm:px-6 md:px-8 xl:px-12 2xl:px-16">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end mb-8 gap-4">
          <div>
            <span className="text-xs font-bold text-brand-600 dark:text-brand-300 uppercase tracking-wider bg-brand-50 dark:bg-brand-950/60 border border-brand-200 dark:border-brand-800/60 px-3 py-1 rounded-full">
              {language === 'ne' ? 'वर्गीकरण' : 'Product Categories'}
            </span>
            <h2 className="text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white mt-2">
              {t.home.browseCategories}
            </h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
              {t.home.browseCategoriesSubtitle}
            </p>
          </div>
          <Link
            href="/categories"
            className="inline-flex items-center gap-1.5 text-sm font-semibold text-brand-500 dark:text-brand-400 hover:text-brand-600 dark:hover:text-brand-300 transition"
          >
            <span>{language === 'ne' ? 'सबै वर्गहरू हेर्नुहोस्' : 'View All Categories'}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-5">
          {list
            .filter((c) => c.is_active)
            .sort((a, b) => a.display_order - b.display_order)
            .map((cat) => {
              const name =
                language === 'ne' && cat.name_ne ? cat.name_ne : cat.name_en;
              const customIcon = CATEGORY_ICONS[cat.slug] || (
                <Layers className="w-12 h-12 sm:w-14 sm:h-14 text-brand-500 dark:text-brand-400 stroke-[1.75]" />
              );

              return (
                <Link
                  key={cat.id}
                  href={`/categories/${cat.slug}`}
                  className="group bg-white dark:bg-slate-900 rounded-2xl p-3 sm:p-4 border border-slate-200/90 dark:border-slate-800 hover:border-brand-500/60 dark:hover:border-brand-500/60 hover:shadow-lg transition-all flex flex-col justify-between text-center"
                >
                  <div
                    className={`relative w-full h-32 sm:h-36 mb-3 rounded-xl overflow-hidden ${
                      cat.image_url
                        ? 'bg-transparent border border-slate-200/60 dark:border-slate-800'
                        : 'bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-700/60'
                    } flex items-center justify-center transition-all`}
                  >
                    {cat.image_url ? (
                      <SafeImage
                        src={cat.image_url}
                        alt={name}
                        fill
                        type="category"
                        sizes="(max-width: 768px) 50vw, 20vw"
                        className="object-cover w-full h-full p-0 group-hover:scale-105 transition-transform duration-500"
                        fallbackIcon={customIcon}
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center p-3 bg-gradient-to-b from-blue-50/70 to-brand-50/30 dark:from-slate-800/90 dark:to-slate-900/60">
                        <div className="group-hover:scale-110 transition-transform duration-300">
                          {customIcon}
                        </div>
                      </div>
                    )}
                  </div>
                  <h3 className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white line-clamp-2 group-hover:text-brand-500 dark:group-hover:text-brand-400 transition-colors">
                    {name}
                  </h3>
                </Link>
              );
            })}
        </div>
      </div>
    </section>
  );
}
