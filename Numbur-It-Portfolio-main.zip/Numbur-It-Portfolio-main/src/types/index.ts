export type UserRole = 'customer' | 'staff' | 'admin' | 'super_admin';

export interface UserProfile {
  id: string;
  full_name: string;
  phone?: string | null;
  role: UserRole;
  delivery_address?: string | null;
  municipality_area?: string | null;
  created_at: string;
  updated_at: string;
}

export interface StaffProfile {
  id: string;
  name: string;
  designation: string;
  department?: string | null;
  bio_en?: string | null;
  bio_ne?: string | null;
  photo_url: string;
  photo_public_id?: string | null;
  public_contact_phone?: string | null;
  public_contact_email?: string | null;
  public_address?: string | null;
  display_order: number;
  is_public: boolean;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name_en: string;
  name_ne?: string | null;
  slug: string;
  description_en?: string | null;
  description_ne?: string | null;
  image_url?: string | null;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  product_count?: number;
}

export interface Brand {
  id: string;
  name: string;
  slug: string;
  logo_url?: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  name_en: string;
  name_ne?: string | null;
  slug: string;
  sku: string;
  category_id: string;
  brand_id?: string | null;
  selling_price: number;
  cost_price?: number | null; // Sensitive: Admin/Staff only
  discount_price?: number | null;
  primary_image_url: string;
  primary_image_public_id?: string | null;
  short_desc_en?: string | null;
  short_desc_ne?: string | null;
  full_desc_en?: string | null;
  full_desc_ne?: string | null;
  specifications: Record<string, string>;
  warranty_info_en?: string | null;
  warranty_info_ne?: string | null;
  is_featured: boolean;
  is_bestseller: boolean;
  is_new_arrival: boolean;
  is_active: boolean;
  seo_title?: string | null;
  seo_description?: string | null;
  created_at: string;
  updated_at: string;
  // Joins
  category?: Category;
  brand?: Brand;
  images?: Array<{ id?: string; image_url: string; display_order?: number }> | string[];
  inventory?: {
    available_quantity: number;
    in_stock: boolean;
  };
}

export interface InventoryItem {
  id: string;
  product_id: string;
  total_purchased: number;
  available_quantity: number;
  sold_quantity: number;
  damaged_quantity: number;
  low_stock_threshold: number;
  updated_at: string;
  product?: Product;
}

export type InventoryMovementType = 'purchase' | 'sale' | 'damaged' | 'adjustment' | 'return';

export interface InventoryMovement {
  id: string;
  product_id: string;
  quantity_change: number;
  movement_type: InventoryMovementType;
  reason: string;
  staff_id?: string | null;
  created_at: string;
  product?: {
    name_en: string;
    sku: string;
  };
  staff?: {
    full_name: string;
  };
}

export type DeliveryMethod = 'all_nepal_delivery' | 'ramechhap_delivery' | 'store_pickup';
export type OrderStatus = 'pending' | 'contacted' | 'confirmed' | 'processing' | 'ready_for_pickup' | 'shipped' | 'delivered' | 'cancelled';
export type PaymentStatus = 'unpaid' | 'advance_paid' | 'partially_paid' | 'paid' | 'refunded';
export type PaymentMethod = 'cash' | 'bank_transfer' | 'fonepay_qr' | 'esewa' | 'khalti';

export interface OrderItem {
  id: string;
  order_id: string;
  product_id?: string | null;
  product_name_snapshot: string;
  sku_snapshot: string;
  unit_price_snapshot: number;
  quantity: number;
  total_price: number;
}

export interface Order {
  id: string;
  order_number: string;
  customer_id: string;
  customer_name: string;
  customer_phone: string;
  delivery_address: string;
  municipality_area: string;
  delivery_method: DeliveryMethod;
  delivery_instructions?: string | null;
  subtotal_amount: number;
  advance_payment_amount: number;
  total_amount: number;
  remaining_balance: number;
  order_status: OrderStatus;
  payment_status: PaymentStatus;
  internal_notes?: string | null;
  created_at: string;
  updated_at: string;
  items?: OrderItem[];
  payments?: PaymentRecord[];
  history?: OrderStatusHistoryItem[];
}

export interface PaymentRecord {
  id: string;
  order_id: string;
  amount: number;
  payment_method: PaymentMethod;
  payment_reference?: string | null;
  notes?: string | null;
  recorded_by?: string | null;
  created_at: string;
}

export interface OrderStatusHistoryItem {
  id: string;
  order_id: string;
  previous_status?: string | null;
  new_status: string;
  changed_by?: string | null;
  notes?: string | null;
  created_at: string;
}

export interface CartItem {
  id: string; // product id
  product: Product;
  quantity: number;
  selectedPrice: number;
}

export interface ServiceItem {
  id: string;
  title_en: string;
  title_ne?: string | null;
  slug: string;
  icon_name: string;
  short_desc_en?: string | null;
  short_desc_ne?: string | null;
  full_desc_en?: string | null;
  full_desc_ne?: string | null;
  display_order: number;
  is_active: boolean;
  created_at: string;
}

export interface GalleryItem {
  id: string;
  title_en: string;
  title_ne?: string | null;
  image_url: string;
  image_public_id?: string | null;
  category?: string;
  display_order: number;
  is_active: boolean;
  created_at: string;
}

export interface SiteBanner {
  id: string;
  title_en: string;
  title_ne?: string | null;
  subtitle_en?: string | null;
  subtitle_ne?: string | null;
  cta_text_en?: string | null;
  cta_text_ne?: string | null;
  cta_link?: string | null;
  image_url: string;
  banner_type: 'hero' | 'promotional' | 'notice';
  display_order: number;
  is_active: boolean;
}

export interface SiteSettings {
  company_name: string;
  tagline_en: string;
  tagline_ne: string;
  whatsapp_number: string;
  store_phone: string;
  store_mobile: string;
  store_email: string;
  store_address_en: string;
  store_address_ne: string;
  business_hours_en: string;
  business_hours_ne: string;
  established_bs: string;
  google_maps_url: string;
  facebook_url: string;
  bank_payment_details: string;
}
