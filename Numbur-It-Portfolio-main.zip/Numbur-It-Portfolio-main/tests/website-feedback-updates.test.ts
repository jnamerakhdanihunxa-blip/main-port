import { describe, it, expect } from 'vitest';
import { buildWhatsAppOrderUrl, generateWhatsAppMessage } from '../src/lib/whatsapp';

describe('Website Feedback Updates & WhatsApp Checkout Tests', () => {
  it('generates a valid WhatsApp order link with Nepal customer information', () => {
    const waUrl = buildWhatsAppOrderUrl('9779854040821', {
      orderNumber: 'NIT-2026-TEST',
      customerName: 'Niraz Sapkota',
      customerPhone: '9854040821',
      deliveryAddress: 'Manthali Bazaar, Ward 1',
      municipalityArea: 'Manthali Municipality',
      deliveryMethod: 'ramechhap_delivery',
      items: [
        {
          name: 'Hikvision 2MP IP Bullet Camera',
          sku: 'HIK-IP-2MP-BUL',
          quantity: 2,
          price: 4500,
          total: 9000,
        },
      ],
      subtotal: 9000,
      specialInstructions: 'Call before delivery',
    });

    expect(waUrl).toContain('https://wa.me/9779854040821');
    expect(waUrl).toContain('NIT-2026-TEST');
    expect(waUrl).toContain('Niraz%20Sapkota');
    expect(waUrl).toContain('9854040821');
    expect(waUrl).toContain('Hikvision');
  });

  it('validates Nepal 10-digit mobile number format (starting with 97 or 98)', () => {
    const nepalPhoneRegex = /^(\+?977)?[9][78]\d{8}$/;

    expect(nepalPhoneRegex.test('9854040821')).toBe(true);
    expect(nepalPhoneRegex.test('+9779854040821')).toBe(true);
    expect(nepalPhoneRegex.test('9741234567')).toBe(true);

    // Invalid phones
    expect(nepalPhoneRegex.test('1234567890')).toBe(false);
    expect(nepalPhoneRegex.test('985404082')).toBe(false); // 9 digits
    expect(nepalPhoneRegex.test('985404082199')).toBe(false); // 12 digits
  });

  it('correctly maps delivery options to human-friendly labels', () => {
    const deliveryMethodLabels: Record<string, string> = {
      store_pickup: 'Store Pickup (Manthali-1 Office)',
      ramechhap_delivery: 'Ramechhap Local Delivery (Road-Accessible)',
      courier_outside: 'Outside District Courier Service',
    };

    expect(deliveryMethodLabels['store_pickup']).toBe('Store Pickup (Manthali-1 Office)');
    expect(deliveryMethodLabels['ramechhap_delivery']).toContain('Ramechhap Local Delivery');
  });

  it('blocks deactivated staff from accessing admin routes', () => {
    const mockProfile = {
      id: 'staff-1',
      role: 'staff',
      is_active: false,
    };

    const isAllowed = mockProfile.is_active && ['super_admin', 'admin', 'staff'].includes(mockProfile.role);
    expect(isAllowed).toBe(false);
  });

  it('allows active staff and admins', () => {
    const activeAdmin = { id: 'admin-1', role: 'admin', is_active: true };
    const activeStaff = { id: 'staff-2', role: 'staff', is_active: true };
    const customer = { id: 'cust-1', role: 'customer', is_active: true };

    const checkAccess = (p: { role: string; is_active: boolean }) =>
      p.is_active && ['super_admin', 'admin', 'staff'].includes(p.role);

    expect(checkAccess(activeAdmin)).toBe(true);
    expect(checkAccess(activeStaff)).toBe(true);
    expect(checkAccess(customer)).toBe(false);
  });
});
