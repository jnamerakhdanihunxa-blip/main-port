import { describe, it, expect } from 'vitest';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import { FALLBACK_CATEGORIES } from '@/components/public/CategoryGrid';

describe('Product and Category Image QA Verification', () => {
  it('Dell Vostro 3501 has uploaded Cloudinary photo in INITIAL_PRODUCTS', () => {
    const dell = INITIAL_PRODUCTS.find((p) => p.slug === 'dell-vostro-3501-core-i5-11th-gen');
    expect(dell).toBeDefined();
    expect(dell?.primary_image_url).toContain('res.cloudinary.com');
    expect(dell?.primary_image_url).toContain('uzrpwwxzgs7oighc67cg');
  });

  it('EZVIZ H8c has uploaded Cloudinary photo in INITIAL_PRODUCTS', () => {
    const ezviz = INITIAL_PRODUCTS.find((p) => p.slug === 'ezviz-h8c-2mp-smart-wifi-outdoor-camera');
    expect(ezviz).toBeDefined();
    expect(ezviz?.primary_image_url).toContain('res.cloudinary.com');
    expect(ezviz?.primary_image_url).toContain('pqt5lvypotcs4r56l5kd');
  });

  it('ghhg product is present in INITIAL_PRODUCTS with its Cloudinary image', () => {
    const ghhg = INITIAL_PRODUCTS.find((p) => p.slug === 'ghhg');
    expect(ghhg).toBeDefined();
    expect(ghhg?.primary_image_url).toContain('res.cloudinary.com');
    expect(ghhg?.primary_image_url).toContain('qdc4egj1kovreaoqfh9h');
  });

  it('All initial products have non-empty valid primary_image_url', () => {
    INITIAL_PRODUCTS.forEach((p) => {
      expect(p.primary_image_url).toBeTruthy();
      expect(p.primary_image_url.length).toBeGreaterThan(10);
      expect(p.primary_image_url.startsWith('http')).toBe(true);
    });
  });

  it('Categories with uploaded images have real Cloudinary image_url', () => {
    const officeCat = FALLBACK_CATEGORIES.find((c) => c.slug === 'office-automation');
    expect(officeCat).toBeDefined();
    expect(officeCat?.image_url).toContain('res.cloudinary.com');
    expect(officeCat?.image_url).toContain('mzqbx5cr0psvvkuejz5q');

    const demoo1Cat = FALLBACK_CATEGORIES.find((c) => c.slug === 'demoo1');
    expect(demoo1Cat).toBeDefined();
    expect(demoo1Cat?.image_url).toContain('res.cloudinary.com');
    expect(demoo1Cat?.image_url).toContain('fnzkmhddhrhwpoohlkaf');
  });
});
