import { describe, it, expect } from 'vitest';
import { INITIAL_PRODUCTS } from '@/lib/products-data';
import { checkoutSchema } from '@/lib/validations';
import { generateWhatsAppMessage } from '@/lib/whatsapp';

describe('Search and Delivery QA Verification', () => {
  it('Validates checkoutSchema with all_nepal_delivery', () => {
    const validData = {
      customer_name: 'Ram Sharma',
      customer_phone: '9854040821',
      delivery_address: 'Biratnagar-4, Morang',
      delivery_method: 'all_nepal_delivery' as const,
      municipality_area: 'Biratnagar',
      delivery_instructions: 'Handle with care',
      items: [
        {
          product_id: 'd1000000-0000-0000-0000-000000000001',
          quantity: 1,
        },
      ],
    };

    const parsed = checkoutSchema.safeParse(validData);
    expect(parsed.success).toBe(true);
  });

  it('Generates WhatsApp message reflecting All Nepal Delivery and Manthali-1 service scope', () => {
    const msg = generateWhatsAppMessage({
      orderNumber: 'ORD-9999',
      customerName: 'Hari Thapa',
      customerPhone: '9841000000',
      deliveryMethod: 'all_nepal_delivery',
      deliveryAddress: 'Pokhara-8, Kaski',
      municipalityArea: 'Pokhara',
      items: [
        {
          name: 'Dell Vostro 3501',
          sku: 'LAP-DEL-V3501-I5',
          quantity: 1,
          price: 72000,
          total: 72000,
        },
      ],
      subtotal: 72000,
    });

    expect(msg).toContain('All Nepal Delivery');
    expect(msg).toContain('Manthali-1, Devkota Chowk, Ramechhap');
    expect(msg).toContain('Delivery available All Over Nepal');
    expect(msg).toContain('Technical Services in Manthali-1 only');
  });

  it('Verifies product catalog has all search-critical fields', () => {
    const sampleProduct = INITIAL_PRODUCTS[0];
    expect(sampleProduct).toBeDefined();
    expect(sampleProduct.name_en).toBeTruthy();
    expect(sampleProduct.category?.name_en).toBeTruthy();
    expect(sampleProduct.primary_image_url).toBeTruthy();
  });
});
