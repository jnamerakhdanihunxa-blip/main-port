import { describe, it, expect } from 'vitest';
import { productSchema, checkoutSchema, advancePaymentSchema, stockMovementSchema } from '../src/lib/validations';
import { generateWhatsAppMessage, buildWhatsAppOrderUrl } from '../src/lib/whatsapp';
import { INITIAL_PRODUCTS } from '../src/lib/products-data';

describe('18 Critical Business Scenarios & Rules', () => {
  // ---------------------------------------------------------------------------
  // Scenario 3: Product creation without a category MUST be blocked
  // ---------------------------------------------------------------------------
  it('Scenario 3: Product creation without a category is strictly blocked', () => {
    const invalidProduct = {
      name_en: 'Dell Inspiron 15',
      slug: 'dell-inspiron-15',
      sku: 'DEL-INSP-15',
      category_id: '', // Empty category ID
      selling_price: 65000,
      primary_image_url: '/images/image_1024.jpeg',
    };

    const result = productSchema.safeParse(invalidProduct);
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.issues.some((i) => i.path.includes('category_id'))).toBe(true);
    }
  });

  // ---------------------------------------------------------------------------
  // Scenario 4: Product creation with a valid category succeeds
  // ---------------------------------------------------------------------------
  it('Scenario 4: Product creation with a valid category succeeds', () => {
    const validProduct = {
      name_en: 'Dell Inspiron 15',
      slug: 'dell-inspiron-15',
      sku: 'DEL-INSP-15',
      category_id: 'c1000000-0000-0000-0000-000000000001', // Valid UUID
      selling_price: 65000,
      primary_image_url: '/images/image_1024.jpeg',
      specifications: { RAM: '8GB', Storage: '512GB SSD' },
      is_active: true,
    };

    const result = productSchema.safeParse(validProduct);
    expect(result.success).toBe(true);
  });

  // ---------------------------------------------------------------------------
  // Scenario 6: Product filtering and search
  // ---------------------------------------------------------------------------
  it('Scenario 6: Product filtering and search correctly filters products', () => {
    const query = 'camera';
    const matches = INITIAL_PRODUCTS.filter(
      (p) =>
        p.name_en.toLowerCase().includes(query) ||
        p.sku.toLowerCase().includes(query) ||
        (p.category?.name_en.toLowerCase().includes(query) ?? false)
    );

    expect(matches.length).toBeGreaterThan(0);
    expect(matches.every((m) => m.category?.slug === 'cctv-security')).toBe(true);
  });

  // ---------------------------------------------------------------------------
  // Scenario 7: Adding, updating, and removing cart items
  // ---------------------------------------------------------------------------
  it('Scenario 7: Cart calculations correctly compute subtotal and handle updates', () => {
    const mockCart = [
      { id: 'p1', price: 4499, quantity: 2 }, // 8998
      { id: 'p2', price: 68500, quantity: 1 }, // 68500
    ];

    const subtotal = mockCart.reduce((acc, item) => acc + item.price * item.quantity, 0);
    expect(subtotal).toBe(77498);

    // Quantity update
    mockCart[0].quantity = 3;
    const updatedSubtotal = mockCart.reduce((acc, item) => acc + item.price * item.quantity, 0);
    expect(updatedSubtotal).toBe(4499 * 3 + 68500);

    // Removal
    const filteredCart = mockCart.filter((i) => i.id !== 'p1');
    expect(filteredCart.length).toBe(1);
    expect(filteredCart[0].id).toBe('p2');
  });

  // ---------------------------------------------------------------------------
  // Scenario 8: Checkout with unavailable stock is blocked
  // ---------------------------------------------------------------------------
  it('Scenario 8: Checkout validation blocks items when quantity exceeds available stock', () => {
    const availableStock = 5;
    const requestedQuantity = 10;

    const canCheckout = (qty: number, stock: number) => stock > 0 && qty <= stock;
    expect(canCheckout(requestedQuantity, availableStock)).toBe(false);
    expect(canCheckout(3, availableStock)).toBe(true);
  });

  // ---------------------------------------------------------------------------
  // Scenario 9: Duplicate order submission prevention
  // ---------------------------------------------------------------------------
  it('Scenario 9: Orders require a unique order number', () => {
    const existingOrderNumbers = new Set(['NIS-2026-1042']);
    const attemptOrderNumber = 'NIS-2026-1042';

    const isDuplicate = existingOrderNumbers.has(attemptOrderNumber);
    expect(isDuplicate).toBe(true);

    const newOrderNumber = 'NIS-2026-5821';
    expect(existingOrderNumbers.has(newOrderNumber)).toBe(false);
  });

  // ---------------------------------------------------------------------------
  // Scenario 10: WhatsApp message generation contains required template fields
  // ---------------------------------------------------------------------------
  it('Scenario 10: WhatsApp message template contains Order #, SKUs, and Advance Payment instructions', () => {
    const orderData = {
      orderNumber: 'NIS-2026-8821',
      customerName: 'Niraz Sapkota',
      customerPhone: '9854040821',
      deliveryMethod: 'ramechhap_delivery',
      deliveryAddress: 'Manthali-1, Ramechhap',
      municipalityArea: 'Manthali Municipality',
      items: [
        {
          name: 'EZVIZ H8c 2MP Smart WiFi Camera',
          sku: 'CAM-EZ-H8C-2MP',
          quantity: 2,
          price: 4499,
          total: 8998,
        },
      ],
      subtotal: 8998,
    };

    const message = generateWhatsAppMessage(orderData);
    expect(message).toContain('NIS-2026-8821');
    expect(message).toContain('CAM-EZ-H8C-2MP');
    expect(message).toContain('Niraz Sapkota');
    expect(message).toContain('9854040821');
    expect(message).toContain('Rs. 8,998');
    expect(message).toContain('advance payment');

    const url = buildWhatsAppOrderUrl('9854040821', orderData);
    expect(url).toContain('https://wa.me/9779854040821?text=');
    expect(url).toContain(encodeURIComponent('NIS-2026-8821'));
  });

  // ---------------------------------------------------------------------------
  // Scenario 11 & 12: Advance payment recording & balance calculation
  // ---------------------------------------------------------------------------
  it('Scenario 11 & 12: Advance payment cannot exceed balance and accurately updates remaining balance', () => {
    const totalAmount = 50000;
    let advancePaid = 10000;
    let remainingBalance = totalAmount - advancePaid;

    expect(remainingBalance).toBe(40000);

    // Validate overpayment rejection
    const excessPayment = 45000;
    const isPaymentValid = excessPayment <= remainingBalance;
    expect(isPaymentValid).toBe(false);

    // Record valid partial payment
    const validPayment = 20000;
    advancePaid += validPayment;
    remainingBalance = totalAmount - advancePaid;

    expect(advancePaid).toBe(30000);
    expect(remainingBalance).toBe(20000);

    // Final payoff
    advancePaid += 20000;
    remainingBalance = totalAmount - advancePaid;
    expect(remainingBalance).toBe(0);
  });

  // ---------------------------------------------------------------------------
  // Scenario 13: Inventory atomic deduction & negative stock prevention
  // ---------------------------------------------------------------------------
  it('Scenario 13: Inventory movement strictly prevents negative stock', () => {
    let availableQuantity = 4;
    const deduction = 10;

    const applyStockChange = (current: number, change: number) => {
      if (current + change < 0) {
        throw new Error('Negative stock disallowed');
      }
      return current + change;
    };

    expect(() => applyStockChange(availableQuantity, -deduction)).toThrow(
      'Negative stock disallowed'
    );

    // Valid deduction succeeds
    const newStock = applyStockChange(availableQuantity, -3);
    expect(newStock).toBe(1);
  });

  // ---------------------------------------------------------------------------
  // Scenario 17: Missing warranty information leaves no empty placeholder
  // ---------------------------------------------------------------------------
  it('Scenario 17: Product with absent warranty information does not have empty string placeholder', () => {
    const productWithoutWarranty = INITIAL_PRODUCTS.find(
      (p) => p.warranty_info_en === null || p.warranty_info_en === undefined
    );

    expect(productWithoutWarranty).toBeDefined();
    expect(productWithoutWarranty?.warranty_info_en).toBeNull();
  });

  // ---------------------------------------------------------------------------
  // Scenario 18: Empty category listings handle empty states safely
  // ---------------------------------------------------------------------------
  it('Scenario 18: Filtering for an unused category returns 0 items without throwing', () => {
    const nonExistentCategorySlug = 'non-existent-category-slug';
    const matches = INITIAL_PRODUCTS.filter(
      (p) => p.category?.slug === nonExistentCategorySlug
    );

    expect(matches.length).toBe(0);
  });
});
