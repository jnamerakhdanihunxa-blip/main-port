import { describe, it, expect } from 'vitest';

describe('Admin CRUD Operations & Business Integrity Test Suite', () => {
  // 1. Slug auto-generation logic
  const generateSlug = (name: string, customSlug?: string) => {
    if (customSlug?.trim()) return customSlug.trim();
    return name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
  };

  it('Product Slug Generation: Generates URL-safe slugs from product titles', () => {
    expect(generateSlug('EZVIZ H8c 2MP Camera')).toBe('ezviz-h8c-2mp-camera');
    expect(generateSlug('TP-Link Archer C6 AC1200!!')).toBe('tp-link-archer-c6-ac1200');
    expect(generateSlug('Dell Laptop', 'custom-dell-laptop')).toBe('custom-dell-laptop');
  });

  // 2. Product validation logic
  const validateProductCreate = (body: any) => {
    const errors: string[] = [];
    if (!body.name_en?.trim()) errors.push('Product name is required');
    if (!body.category_id?.trim()) errors.push('Category is required');
    if (body.selling_price === undefined || Number(body.selling_price) < 0) {
      errors.push('Selling price must be greater than or equal to 0');
    }
    if (body.discount_price && Number(body.discount_price) > Number(body.selling_price)) {
      errors.push('Discount price cannot exceed selling price');
    }
    return {
      isValid: errors.length === 0,
      errors,
    };
  };

  it('Product Validation: Rejects missing names, negative prices, and discount price > selling price', () => {
    expect(validateProductCreate({}).isValid).toBe(false);
    expect(validateProductCreate({ name_en: 'Test', category_id: 'c-1', selling_price: -100 }).errors).toContain(
      'Selling price must be greater than or equal to 0'
    );
    expect(
      validateProductCreate({
        name_en: 'Test',
        category_id: 'c-1',
        selling_price: 1000,
        discount_price: 1200,
      }).errors
    ).toContain('Discount price cannot exceed selling price');

    expect(
      validateProductCreate({
        name_en: 'Valid Product',
        category_id: 'c-1',
        selling_price: 1000,
        discount_price: 900,
      }).isValid
    ).toBe(true);
  });

  // 3. Atomic stock movement rules
  const processInventoryMovement = (
    currentStock: number,
    change: number,
    type: 'purchase' | 'sale' | 'damaged' | 'return'
  ) => {
    const delta = type === 'purchase' || type === 'return' ? Math.abs(change) : -Math.abs(change);
    if (currentStock + delta < 0) {
      throw new Error(
        `Atomic Stock Rule: Cannot deduct ${Math.abs(change)} units. Current stock is ${currentStock}.`
      );
    }
    return currentStock + delta;
  };

  it('Inventory Movement: Prevents stock from dropping below zero', () => {
    expect(processInventoryMovement(10, 5, 'purchase')).toBe(15);
    expect(processInventoryMovement(10, 4, 'sale')).toBe(6);
    expect(processInventoryMovement(5, 2, 'damaged')).toBe(3);

    // Negative stock deduction attempt
    expect(() => processInventoryMovement(3, 5, 'sale')).toThrow(
      'Atomic Stock Rule: Cannot deduct 5 units. Current stock is 3.'
    );
  });

  // 4. Category deletion guard
  it('Category Deletion Safety: Rejects deletion if products are linked', () => {
    const existingProducts = [
      { id: 'p-1', category_id: 'cat-security' },
      { id: 'p-2', category_id: 'cat-laptops' },
    ];

    const canDeleteCategory = (categoryId: string) => {
      const linked = existingProducts.filter((p) => p.category_id === categoryId);
      if (linked.length > 0) {
        throw new Error(
          `Cannot delete category: ${linked.length} product(s) are linked to it. Please reassign or delete them first.`
        );
      }
      return true;
    };

    expect(() => canDeleteCategory('cat-security')).toThrow(
      'Cannot delete category: 1 product(s) are linked to it.'
    );
    expect(canDeleteCategory('cat-empty-accessories')).toBe(true);
  });
});
