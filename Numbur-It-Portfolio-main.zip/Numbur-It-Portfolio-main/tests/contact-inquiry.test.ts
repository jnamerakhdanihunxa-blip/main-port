import { describe, it, expect } from 'vitest';

describe('Contact & Customer Inquiry Test Suite', () => {
  interface InquiryFormInput {
    name: string;
    phone: string;
    email?: string;
    service?: string;
    message?: string;
  }

  const validateInquiry = (form: InquiryFormInput) => {
    const errors: string[] = [];
    if (!form.name || form.name.trim().length === 0) {
      errors.push('Full name is required');
    }
    const cleanPhone = (form.phone || '').replace(/[^0-9]/g, '');
    if (cleanPhone.length < 9) {
      errors.push('Valid phone number is required (at least 9 digits)');
    }
    return {
      isValid: errors.length === 0,
      errors,
      sanitizedPhone: cleanPhone,
    };
  };

  const generateInquiryWhatsAppUrl = (
    businessNumber: string,
    form: InquiryFormInput
  ) => {
    const validation = validateInquiry(form);
    if (!validation.isValid) {
      throw new Error(`Validation failed: ${validation.errors.join(', ')}`);
    }

    const text = encodeURIComponent(
      `*NEW WEBSITE INQUIRY - NUMBUR iT*\n` +
      `Name: ${form.name.trim()}\n` +
      `Phone: ${validation.sanitizedPhone}\n` +
      `Email: ${form.email?.trim() || 'N/A'}\n` +
      `Service: ${form.service || 'General Inquiry'}\n` +
      `Message: ${form.message?.trim() || 'Interested in your services.'}`
    );

    return `https://wa.me/${businessNumber}?text=${text}`;
  };

  it('Valid Form Submission: Generates correct WhatsApp link with inquiry details', () => {
    const validForm: InquiryFormInput = {
      name: 'Ramesh Thapa',
      phone: '9854040821',
      email: 'ramesh@example.com',
      service: 'CCTV Installation',
      message: 'Need 4 outdoor cameras for my grocery shop in Manthali.',
    };

    const url = generateInquiryWhatsAppUrl('9779854040821', validForm);
    expect(url).toContain('https://wa.me/9779854040821');
    expect(url).toContain('Ramesh%20Thapa');
    expect(url).toContain('CCTV%20Installation');
    expect(url).toContain('9854040821');
  });

  it('Missing Name: Blocks submission and returns appropriate error', () => {
    const invalidForm: InquiryFormInput = {
      name: '',
      phone: '9854040821',
      message: 'Inquiry without name',
    };

    const res = validateInquiry(invalidForm);
    expect(res.isValid).toBe(false);
    expect(res.errors).toContain('Full name is required');
    expect(() => generateInquiryWhatsAppUrl('9779854040821', invalidForm)).toThrow();
  });

  it('Invalid Phone Number: Rejects phone numbers under 9 digits', () => {
    const invalidPhoneForm: InquiryFormInput = {
      name: 'Binod Karki',
      phone: '12345',
      message: 'Short phone test',
    };

    const res = validateInquiry(invalidPhoneForm);
    expect(res.isValid).toBe(false);
    expect(res.errors).toContain('Valid phone number is required (at least 9 digits)');
  });

  it('Phone Number Sanitization: Cleans formatted inputs (spaces, hyphens, prefixes)', () => {
    const formattedPhoneForm: InquiryFormInput = {
      name: 'Sunita Shrestha',
      phone: '+977-985-4040-821',
    };

    const res = validateInquiry(formattedPhoneForm);
    expect(res.isValid).toBe(true);
    expect(res.sanitizedPhone).toBe('9779854040821');
  });
});
