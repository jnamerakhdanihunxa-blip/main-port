import { describe, it, expect } from 'vitest';
import { translations } from '../src/lib/i18n/translations';

describe('Navigation, Routes & Localization Test Suite', () => {
  const publicNavRoutes = [
    { key: 'home', path: '/' },
    { key: 'allProducts', path: '/products' },
    { key: 'categories', path: '/categories' },
    { key: 'services', path: '/services' },
    { key: 'offers', path: '/offers' },
    { key: 'gallery', path: '/gallery' },
    { key: 'about', path: '/about' },
    { key: 'contact', path: '/contact' },
    { key: 'cart', path: '/cart' },
  ];

  it('Navigation Links: Every public navigation destination has valid routing and structure', () => {
    publicNavRoutes.forEach(({ path }) => {
      expect(path.startsWith('/')).toBe(true);
      expect(path.length).toBeGreaterThan(0);
    });
  });

  it('Bilingual Navigation: English and Nepali translation dictionaries have corresponding labels', () => {
    const enNav = translations.en.nav;
    const neNav = translations.ne.nav;

    publicNavRoutes.forEach(({ key }) => {
      const enLabel = (enNav as any)[key];
      const neLabel = (neNav as any)[key];
      expect(enLabel).toBeTruthy();
      expect(neLabel).toBeTruthy();
      expect(typeof enLabel).toBe('string');
      expect(typeof neLabel).toBe('string');
    });
  });

  it('Search Form Query Parameter: Formats search URL accurately with encoding', () => {
    const buildSearchUrl = (query: string) => {
      const trimmed = query.trim();
      if (!trimmed) return '/products';
      return `/products?q=${encodeURIComponent(trimmed)}`;
    };

    expect(buildSearchUrl('CCTV Camera')).toBe('/products?q=CCTV%20Camera');
    expect(buildSearchUrl('  Router Wi-Fi  ')).toBe('/products?q=Router%20Wi-Fi');
    expect(buildSearchUrl('')).toBe('/products');
  });

  it('Category and Product Slug Routing: Validates parameterized routes pattern', () => {
    const generateCategoryPath = (slug: string) => `/categories/${encodeURIComponent(slug)}`;
    const generateProductPath = (slug: string) => `/products/${encodeURIComponent(slug)}`;

    expect(generateCategoryPath('cctv-security')).toBe('/categories/cctv-security');
    expect(generateProductPath('dell-vostro-3501')).toBe('/products/dell-vostro-3501');
  });
});
