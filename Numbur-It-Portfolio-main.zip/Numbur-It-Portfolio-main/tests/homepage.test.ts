import { describe, it, expect } from 'vitest';
import { FALLBACK_BANNERS } from '../src/components/public/HeroSection';
import { AUDITED_SERVICES_FALLBACK } from '../src/components/public/ServicesSection';
import { FALLBACK_CATEGORIES } from '../src/components/public/CategoryGrid';
import { INITIAL_PRODUCTS } from '../src/lib/products-data';
import { buildWhatsAppOrderUrl } from '../src/lib/whatsapp';

describe('Homepage & Core Public Elements Test Suite', () => {
  it('Hero Carousel: Contains active banners with headlines, subheadings, and CTAs', () => {
    expect(FALLBACK_BANNERS.length).toBeGreaterThan(0);
    FALLBACK_BANNERS.forEach((banner) => {
      expect(banner.title_en).toBeTruthy();
      expect(banner.subtitle_en).toBeTruthy();
      expect(banner.cta_link).toBeTruthy();
      expect(banner.cta_text_en).toBeTruthy();
      expect(banner.is_active).toBe(true);
    });
  });

  it('Services Section: Renders verified local services with title and slug', () => {
    expect(AUDITED_SERVICES_FALLBACK.length).toBeGreaterThanOrEqual(10);
    AUDITED_SERVICES_FALLBACK.forEach((service) => {
      expect(service.title_en).toBeTruthy();
      expect(service.slug).toBeTruthy();
      expect(service.is_active).toBe(true);
    });
  });

  it('Categories Grid: Provides categorized hardware and networking verticals', () => {
    expect(FALLBACK_CATEGORIES.length).toBeGreaterThanOrEqual(6);
    const slugs = FALLBACK_CATEGORIES.map((c) => c.slug);
    expect(slugs).toContain('cctv-security');
    expect(slugs).toContain('laptops-computers');
    expect(slugs).toContain('networking-solutions');
  });

  it('Featured & Best Seller Products: Verifies products have valid prices and inventory', () => {
    const featured = INITIAL_PRODUCTS.filter((p) => p.is_featured);
    expect(featured.length).toBeGreaterThan(0);
    featured.forEach((p) => {
      expect(p.selling_price).toBeGreaterThan(0);
      expect(p.name_en).toBeTruthy();
      expect(p.sku).toBeTruthy();
      expect(p.inventory).toBeDefined();
      expect(p.inventory?.available_quantity).toBeGreaterThanOrEqual(0);
    });
  });

  it('WhatsApp CTA: Generates direct WhatsApp chat URLs correctly', () => {
    const defaultNumber = '9779854040821';
    const samplePayload = {
      orderNumber: 'NIS-2026-TEST',
      customerName: 'Test Customer',
      customerPhone: '9854040821',
      deliveryMethod: 'store_pickup' as const,
      deliveryAddress: 'Manthali Bazaar',
      municipalityArea: 'Manthali Municipality',
      items: [
        {
          name: 'CCTV Camera',
          sku: 'CAM-01',
          quantity: 2,
          price: 4500,
          total: 9000,
        },
      ],
      subtotal: 9000,
    };

    const waUrl = buildWhatsAppOrderUrl(defaultNumber, samplePayload);
    expect(waUrl).toContain('https://wa.me/9779854040821');
    expect(waUrl).toContain('NIS-2026-TEST');
    expect(waUrl).toContain('Test%20Customer');
    expect(waUrl).toContain('9%2C000');
  });
});
