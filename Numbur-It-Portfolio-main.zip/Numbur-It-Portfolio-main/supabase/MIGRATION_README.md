# Supabase Database Migration Guide: Website Revision & Feedback Updates

## 1. Migration File Information
- **Target Migration File**: `supabase/migrations/20260923_01_website_feedback_updates.sql`
- **Type**: Non-destructive, incremental, idempotent SQL migration.
- **Previous Migrations Preserved**: `01_schema.sql`, `02_rls_policies.sql`, `03_seed_data.sql` remain completely untouched.

---

## 2. What This Migration Changes
1. **Guest WhatsApp Orders (`public.orders`)**:
   - Drops `NOT NULL` constraint on `customer_id` (`ALTER TABLE public.orders ALTER COLUMN customer_id DROP NOT NULL;`).
   - Adds `customer_email TEXT` and `customer_notes TEXT` to support guest checkout information.
   - Adds an index on `customer_phone` for rapid lookup by store staff.
2. **Account Deactivation Security (`public.profiles`)**:
   - Adds `is_active BOOLEAN NOT NULL DEFAULT true` to `public.profiles`.
   - Prevents deactivated staff/admins from accessing administrative endpoints.
3. **Cloudinary Asset Management (`public.site_banners`)**:
   - Adds `image_public_id TEXT` to `public.site_banners` so old images can be safely replaced or deleted on Cloudinary.
4. **Social Media Links (`public.social_links`)**:
   - Creates a dedicated `social_links` table with fields: `id`, `platform`, `platform_name`, `url`, `icon_name`, `display_order`, `is_active`, `created_at`, `updated_at`.
   - Configures Row-Level Security (RLS) policies allowing public read of active links, and admin-only mutations.
   - Seeds verified initial social links (Facebook, WhatsApp Support, YouTube, Instagram).
5. **Site Settings (`public.site_settings`)**:
   - Seeds default configuration keys (`site_logo_url`, `business_whatsapp_number`, `store_phone`, etc.) safely using `ON CONFLICT (key) DO NOTHING`.
6. **Staff Profiles Seed (`public.staff_profiles`)**:
   - Seeds the audited team profiles (Mr. Niraz Sapkota, Mr. Tikaram, Mr. Rohit Prasad Adhikari, Mrs. Usha Karki) using RFC 4122 compliant hex UUIDs, permanently resolving the PostgreSQL `22P02` syntax error encountered in earlier seed scripts.

---

## 3. Existing Tables Reused
- `public.orders`: Reused for recording pending WhatsApp orders.
- `public.order_items`: Reused for storing server-validated product snapshots.
- `public.profiles`: Reused for Super Admin, Admin, and Staff authentication roles.
- `public.staff_profiles`: Reused for the public staff directory and sliding carousel.
- `public.site_banners`: Reused for the dynamic homepage hero slider.
- `public.site_settings`: Reused for logo branding and business contact configurations.

---

## 4. How to Apply This Migration
You do **NOT** need to re-run any previous migrations! Simply apply only this new file:

1. Open your **Supabase Dashboard** &rarr; Select your project (`lfleuankvzbmqrhvhehp`).
2. Go to the **SQL Editor** on the left menu.
3. Click **New Query**.
4. Copy and paste the entire contents of [`supabase/migrations/20260923_01_website_feedback_updates.sql`](file:///d:/Numbur%20iT-html/supabase/migrations/20260923_01_website_feedback_updates.sql).
5. Click **Run**.
6. The query will output `Success. No rows returned`.

---

## 5. Required Environment Variables
Your existing `.env.local` already has all required keys:
```env
NEXT_PUBLIC_SUPABASE_URL=https://lfleuankvzbmqrhvhehp.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGci...

NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME=ytzmwyvj
CLOUDINARY_API_KEY=395374567288636
CLOUDINARY_API_SECRET=uA_KzZ799O_v2a7g5RkU5i1F9Qo

NEXT_PUBLIC_DEFAULT_WHATSAPP_NUMBER=9779854040821
```
No additional environment variables are required.
