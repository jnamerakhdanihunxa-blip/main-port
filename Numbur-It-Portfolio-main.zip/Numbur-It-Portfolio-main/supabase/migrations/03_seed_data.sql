-- =============================================================================
-- NUMBUR iT SOLUTION - 03_SEED_DATA.SQL
-- Seed Data containing verified business info, categories, services, and staff
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. SITE SETTINGS
-- -----------------------------------------------------------------------------
INSERT INTO public.site_settings (key, value, description) VALUES
('company_name', 'Numbur iT Solution Pvt. Ltd.', 'Official registered company name'),
('tagline_en', 'The Ultimate iT Solution - Your Safety, Our Responsibility', 'Company tagline English'),
('tagline_ne', 'अल्टिमेट आइटी सोलुसन - तपाईंको सुरक्षा, हाम्रो जिम्मेवारी', 'Company tagline Nepali'),
('whatsapp_number', '9779854040821', 'Primary WhatsApp ordering and support number (country code + number)'),
('store_phone', '048540314', 'Landline phone number in Manthali'),
('store_mobile', '9854040821', 'Mobile contact number'),
('store_email', 'numburitsolution1@gmail.com', 'Official business email'),
('store_address_en', 'Manthali-1, Ramechhap, Bagmati Province, Nepal', 'Store physical address in English'),
('store_address_ne', 'मन्थली-१, रामेछाप, बागमती प्रदेश, नेपाल', 'Store physical address in Nepali'),
('business_hours_en', 'Sun - Fri: 9:00 AM - 6:00 PM | Sat: Closed', 'Business hours English'),
('business_hours_ne', 'आइतबार - शुक्रबार: बिहान ९:०० - साँझ ६:०० | शनिबार: बन्द', 'Business hours Nepali'),
('established_bs', '2069 BS', 'Year of establishment in Bikram Sambat'),
('google_maps_url', 'https://www.google.com/maps/place/Numbur+It+Solution+Pvt+Ltd/@27.382878,86.060467,18z/data=!4m14!1m7!3m6!1s0x39ebef247f2e4191:0x637ab4542683ff87!2sNumbur+It+Solution+Pvt+Ltd!8m2!3d27.3828204!4d86.0603895!16s%2Fg%2F11gbfj3pzt!3m5!1s0x39ebef247f2e4191:0x637ab4542683ff87!8m2!3d27.3828204!4d86.0603895!16s%2Fg%2F11gbfj3pzt?hl=en', 'Google Maps link'),
('facebook_url', 'https://www.facebook.com/p/-100057596823175/', 'Official Facebook Page'),
('bank_payment_details', 'Nabil Bank / Global IME Bank / Fonepay QR available upon checkout confirmation', 'Advance payment account details')
ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;

-- -----------------------------------------------------------------------------
-- 2. CATEGORIES
-- -----------------------------------------------------------------------------
INSERT INTO public.categories (id, name_en, name_ne, slug, description_en, description_ne, image_url, display_order, is_active) VALUES
('c1000000-0000-0000-0000-000000000001', 'CCTV & Security Systems', 'सीसीटीभी र सुरक्षा प्रणाली', 'cctv-security', 'High-definition IP, analog, and smart wireless security cameras and NVR/DVR systems.', 'सुरक्षा क्यामेरा, एनभीआर र स्मार्ट निगरानी प्रणालीहरू।', '/images/image_1024.jpeg', 1, true),
('c1000000-0000-0000-0000-000000000002', 'Laptops & Computers', 'ल्यापटप र कम्प्युटर', 'laptops-computers', 'Latest brand new and enterprise-grade laptops, custom desktops, and workstations.', 'ब्रान्डेड ल्यापटप, डेक्सटप र कम्प्युटर उपकरणहरू।', '/images/Dell-Inspiron-3501-i71165G7-8gb-512gb-SSD-11th-15.6_-FHD-2gb-MX330-Win10-Laptop-Copy.jpeg', 2, true),
('c1000000-0000-0000-0000-000000000003', 'Printers & Photocopy Machines', 'प्रिन्टर र फोटोकपी मेसिन', 'printers-copiers', 'Heavy-duty commercial copiers, laser printers, tank printers, and genuine cartridges.', 'कपी मेसिन, लेजर प्रिन्टर र टोनर कार्ट्रिज।', '/images/1712838065032.jpg', 3, true),
('c1000000-0000-0000-0000-000000000004', 'Networking & Internet Solutions', 'नेटवर्किङ र इन्टरनेट', 'networking-solutions', 'High-range enterprise routers, switches, fiber equipment, and access points.', 'राउटर, स्विच र नेटवर्क पूर्वाधार उपकरणहरू।', '/images/424879538_1417216489179631_8263106428903182340_n.jpg', 4, true),
('c1000000-0000-0000-0000-000000000005', 'Power Backup & Inverters', 'पावर ब्याकअप र इन्भर्टर', 'power-backup', 'Online UPS systems, heavy-duty inverters, and tubular batteries for uninterrupted power.', 'अनलाइन यूपीएस र पावर ब्याकअप प्रणाली।', '/images/D41BF0CE-470D-43C7-9122-3ECA4D9003AB.jpeg', 5, true),
('c1000000-0000-0000-0000-000000000006', 'Office Automation & Attendance', 'कार्यालय अटोमेसन र हाजिरी मेसिन', 'office-automation', 'Biometric fingerprint/facial attendance machines, intercom PBX, and note counters.', 'डिजिटल हाजिरी, इन्टरकम र नोट गन्ने मेसिन।', '/images/gff.jpg', 6, true)
ON CONFLICT (id) DO NOTHING;

-- -----------------------------------------------------------------------------
-- 3. BRANDS
-- -----------------------------------------------------------------------------
INSERT INTO public.brands (id, name, slug, logo_url, is_active) VALUES
('b1000000-0000-0000-0000-000000000001', 'Dell', 'dell', null, true),
('b1000000-0000-0000-0000-000000000002', 'HP', 'hp', null, true),
('b1000000-0000-0000-0000-000000000003', 'EZVIZ', 'ezviz', null, true),
('b1000000-0000-0000-0000-000000000004', 'Hikvision', 'hikvision', null, true),
('b1000000-0000-0000-0000-000000000005', 'Dahua', 'dahua', null, true),
('b1000000-0000-0000-0000-000000000006', 'Canon', 'canon', null, true),
('b1000000-0000-0000-0000-000000000007', 'Epson', 'epson', null, true),
('b1000000-0000-0000-0000-000000000008', 'TP-Link', 'tp-link', null, true)
ON CONFLICT (id) DO NOTHING;

-- -----------------------------------------------------------------------------
-- 4. STAFF PROFILES (Audited Real Team Members)
-- -----------------------------------------------------------------------------
INSERT INTO public.staff_profiles (id, name, designation, department, bio_en, bio_ne, photo_url, public_contact_phone, public_contact_email, public_address, display_order, is_public) VALUES
('s1000000-0000-0000-0000-000000000001', 'Mr. Niraz Sapkota', 'Owner & Co-founder', 'Executive Management', 'Founder of Numbur iT Solution Pvt. Ltd. Leading IT infrastructure development, enterprise hardware supplies, and customer satisfaction across Ramechhap since 2069 BS.', 'नम्बुर आइटी सोलुसनका संस्थापक। २०६९ सालदेखि रामेछाप जिल्लामा सूचना प्रविधि विस्तारमा क्रियाशील।', '/images/506722803_10236807670281858_2944426464058802766_n.jpg', '9854040821', 'numburitsolution1@gmail.com', 'Khimti-7, Ramechhap', 1, true),
('s1000000-0000-0000-0000-000000000002', 'Mr. Tikaram', 'Co-sub founder & Head Accountant', 'Finance & Administration', 'Overseeing financial administration, accounting operations, supplier settlements, and commercial billing.', 'कम्पनीको आर्थिक प्रशासन तथा लेखा व्यवस्थापनको जिम्मेवारी।', '/images/1712838089451.jpg', '9861561229', null, 'Sindhuli', 2, true),
('s1000000-0000-0000-0000-000000000003', 'Mr. Rohit Prasad Adhikari', 'IT Technician & Technical Lead', 'Technical Department', 'Expert hardware diagnostics, CCTV surveillance architecture, network installation, and on-site client technical troubleshooting.', 'हार्डवेयर मर्मत, सीसीटीभी क्यामेरा इन्स्टलेसन र नेटवर्किङ प्राविधिक विशेषज्ञ।', '/images/file_00000000d41881fa8ed3c19064ad1f40.png', '9846141110', 'rohitprasadadhikari11@gmail.com', 'Mithila Mun-11, Dhanusha', 3, true),
('s1000000-0000-0000-0000-000000000004', 'Mrs. Usha Karki', 'Accountant', 'Accountant Department', 'Handling customer invoices, store accounts reconciliation, order advance payments verification, and client reception.', 'ग्राहक बिलिङ, इनभ्वाइसिङ र स्टोर एकाउन्टिङ व्यवस्थापन।', '/images/493683117_2093993891113820_3924779006062972537_n.jpg', '9765990808', null, 'Manthali-2, Ramechhap', 4, true)
ON CONFLICT (id) DO NOTHING;

-- -----------------------------------------------------------------------------
-- 5. SERVICES
-- -----------------------------------------------------------------------------
INSERT INTO public.services (id, title_en, title_ne, slug, icon_name, short_desc_en, short_desc_ne, full_desc_en, full_desc_ne, display_order, is_active) VALUES
('v1000000-0000-0000-0000-000000000001', 'CCTV Surveillance & Security', 'सीसीटीभी निगरानी तथा सुरक्षा', 'cctv-surveillance', 'ShieldCheck', 'Professional CCTV installation for homes, offices, retail shops, courtyards, and institutional premises.', 'घर, कार्यालय, पसल तथा विभिन्न संस्थाका लागि अत्याधुनिक सीसीटीभी क्यामेरा जडान र मर्मत।', 'We provide end-to-end video surveillance systems including IP cameras, wireless WiFi cameras, NVR/DVR setups, remote mobile viewing configuration, and preventive maintenance. Serving Ramechhap for over 10 years.', 'हामीले १० वर्षभन्दा बढी समयदेखि रामेछाप तथा आसपासका क्षेत्रमा उच्च गुणस्तरका सीसीटीभी प्रणाली जडान गर्दै आएका छौं।', 1, true),
('v1000000-0000-0000-0000-000000000002', 'Computer & Laptop Repair', 'कम्प्युटर तथा ल्यापटप मर्मत', 'laptop-pc-repair', 'Laptop', 'Complete chip-level hardware repair, OS setup, SSD upgrades, and motherboard troubleshooting.', 'सबै प्रकारका ल्यापटप र कम्प्युटरको चिप-लेभल मर्मत, अपग्रेड र विन्डोज सफ्टवेयर व्यवस्थापन।', 'Certified repair services for Dell, HP, Lenovo, and custom PCs. Services include screen replacement, keyboard repair, SSD/RAM acceleration, thermal servicing, and data recovery.', 'विश्वसनीय र छिटो मर्मत सेवा। कम्प्युटर ढिलो हुने, डिस्प्ले नआउने समस्याहरूको दक्ष प्राविधिकद्वारा समाधान।', 2, true),
('v1000000-0000-0000-0000-000000000003', 'Printer & Photocopier Maintenance', 'प्रिन्टर तथा फोटोकपी सेवा', 'printer-maintenance', 'Printer', 'Commercial photocopy machine setup, laser cartridge refill, head alignment, and preventive maintenance.', 'प्रिन्टर मर्मत, टोनर रिफिल तथा फोटोकपी मेसिनको नियमित सर्भिसिङ।', 'Official support for Canon, Epson, and commercial photocopiers. We supply genuine cartridges, replacement rollers, and troubleshooting for duplex printing and paper jams.', 'अफिस तथा व्यवसायका लागि आवश्यक पर्ने प्रिन्टिङ उपकरणको भरपर्दो सर्भिस।', 3, true),
('v1000000-0000-0000-0000-000000000004', 'Networking & Internet Infrastructure', 'नेटवर्किङ तथा इन्टरनेट पूर्वाधार', 'networking-infrastructure', 'Network', 'Structured LAN cabling, high-performance mesh WiFi, fiber optic splicing, and router configuration.', 'कार्यालय तथा संस्थागत भवनहरूमा उच्च गतिको सुरक्षित इन्टरनेट तथा नेटवर्क व्यवस्थापन।', 'Designing and implementing robust local area networks (LAN), multi-floor enterprise access points, firewall security, and server connections.', 'स्थानीय तथा संस्थागत स्तरमा भरपर्दो नेटवर्किङ समाधान।', 4, true),
('v1000000-0000-0000-0000-000000000005', 'Biometric Attendance & Access Control', 'डिजिटल हाजिरी तथा बायोमेट्रिक प्रणाली', 'biometric-attendance', 'Fingerprint', 'Digital fingerprint, facial recognition, and RFID attendance solutions with automated reporting.', 'डिजिटल फिंगरप्रिन्ट र फेस रिकग्निसन हाजिरी मेसिन जडान तथा सफ्टवेयर सेटअप।', 'Modernize workforce time tracking with biometric devices that generate automated attendance and leave reports for government offices, schools, and private enterprises.', 'कर्मचारीहरूको उपस्थिति सुरक्षित र पारदर्शी बनाउन आधुनिक हाजिरी प्रणाली।', 5, true),
('v1000000-0000-0000-0000-000000000006', 'Intercom & EPABX Systems', 'इन्टरकम तथा टेलिफोन प्रणाली', 'intercom-systems', 'PhoneCall', 'Internal communication telephone wiring, PBX exchanges, and wireless intercom setups.', 'अफिस तथा होटलहरूका लागि आन्तरिक टेलिफोन तथा इन्टरकम व्यवस्थापन।', 'Cost-effective internal voice communication networks for hotels, hospitals, multi-story offices, and residences.', 'कार्यालयभित्र सजिलो कुराकानीका लागि अत्याधुनिक इन्टरकम नेटवर्क।', 6, true),
('v1000000-0000-0000-0000-000000000007', 'Power Backup & Inverter Systems', 'पावर ब्याकअप तथा इन्भर्टर', 'power-backup-solutions', 'Zap', 'Industrial online UPS, solar hybrid inverters, and high-capacity battery solutions for uninterrupted power.', 'लोडसेडिङबाट सुरक्षित रहन अनलाइन यूपीएस र इन्भर्टर जडान सेवा।', 'Protect your sensitive electronics and mission-critical servers from power surges, voltage fluctuations, and blackouts.', 'कम्प्युटर तथा उपकरणहरूलाई बिजुलीको उतारचढावबाट जोगाउन भरपर्दो ब्याकअप।', 7, true),
('v1000000-0000-0000-0000-000000000008', 'Digital LED Sign Boards', 'डिजिटल एलईडी सूचना बोर्ड', 'digital-led-boards', 'Monitor', 'Custom programmable LED scrolling signboards, notice boards, and commercial displays.', 'पसल तथा कार्यालयका लागि आकर्षक डिजिटल एलईडी बोर्ड निर्माण तथा प्रोग्रामिङ।', 'Enhance your business visibility with vibrant, weather-resistant outdoor and indoor programmable LED display boards.', 'व्यावसायिक प्रचारप्रसारका लागि उच्च गुणस्तरका डिजिटल डिस्प्लेहरू।', 8, true),
('v1000000-0000-0000-0000-000000000009', 'Projector & AV Presentation Setup', 'प्रोजेक्टर तथा अडियो-भिजुअल सेटअप', 'projector-av-systems', 'Tv', 'Conference room projector mounting, motorized screens, and audio-visual meeting setups.', 'बैठक तथा सम्मेलन कक्षका लागि प्रोजेक्टर र साउन्ड सिस्टम जडान।', 'Equip conference rooms, schools, and meeting halls with clear projection equipment and calibrated acoustic sound systems.', 'उत्कृष्ट दृश्य र श्रव्य अनुभवका लागि आधुनिक अडियो-भिडियो प्रणाली।', 9, true),
('v1000000-0000-0000-0000-000000000010', 'Note Counting & Counterfeit Detection', 'नोट गन्ने मेसिन तथा नक्कली नोट पहिचान', 'note-counting-machines', 'Coins', 'Heavy-duty automatic currency counters with UV/MG magnetic fraud detection.', 'बैंक तथा वित्तीय संस्थाका लागि नक्कली नोट पत्ता लगाउने उच्च गतिको नोट काउन्टिङ मेसिन।', 'Reliable currency counting machines designed for cooperatives, businesses, and banking counters in Ramechhap.', 'पैसा गन्ने र नक्कली नोट तुरुन्त पत्ता लगाउने भरपर्दो मेसिन।', 10, true),
('v1000000-0000-0000-0000-000000000011', 'On-Site Home & Office Visit Support', 'घर तथा कार्यालयमा अन-साइट सेवा', 'onsite-support', 'Home', 'Mobile technician visits to diagnose hardware, CCTV cabling, and networking at your location.', 'तपाईंको घर वा कार्यालयमै दक्ष प्राविधिक पुगेर समस्या समाधान गर्ने सेवा।', 'We send trained technicians directly to your home or office anywhere with road vehicle access across Ramechhap.', 'भौतिक रूपमा उपस्थित भएरै कम्प्युटर तथा उपकरणहरूको मर्मत सेवा।', 11, true),
('v1000000-0000-0000-0000-000000000012', 'Remote Desk Support & Software Setup', 'रिमोट डेस्क सपोर्ट तथा सफ्टवेयर समाधान', 'remote-desk-support', 'Headphones', 'Fast remote desktop assistance for software installation, driver fixing, virus removal, and billing setup.', 'इन्टरनेटमार्फत तत्काल कम्प्युटर समस्या समाधान गर्ने रिमोट सपोर्ट सेवा।', 'Get instant support from our technicians via AnyDesk/TeamViewer without leaving your home or office.', 'सफ्टवेयर र सिस्टमका समस्या तत्कालै अनलाइनबाटै समाधान।', 12, true)
ON CONFLICT (id) DO NOTHING;

-- -----------------------------------------------------------------------------
-- 6. SITE BANNERS (Hero & Promotional)
-- -----------------------------------------------------------------------------
INSERT INTO public.site_banners (id, title_en, title_ne, subtitle_en, subtitle_ne, cta_text_en, cta_text_ne, cta_link, image_url, banner_type, display_order, is_active) VALUES
('banner-1', 'The Ultimate iT Solution is Numbur iT Solution', 'अल्टिमेट आइटी सोलुसन - नम्बुर आइटी सोलुसन', 'Serving Manthali, Ramechhap and surrounding communities since 2069 BS with genuine hardware, CCTV security, and expert service.', '२०६९ सालदेखि रामेछापमा कम्प्युटर, ल्यापटप, प्रिन्टर तथा सीसीटीभी क्यामेराको भरपर्दो सेवा।', 'Explore Products', 'सामानहरू हेर्नुहोस्', '/products', '/images/gff.jpg', 'hero', 1, true),
('banner-2', 'Your Safety, Our Responsibility', 'तपाईंको सुरक्षा, हाम्रो जिम्मेवारी', 'Complete CCTV surveillance packages for homes, commercial complexes, and government offices at competitive prices.', 'घर, पसल तथा कार्यालयका लागि विभिन्न ब्रान्डका सीसीटीभी क्यामेरा सुलभ मूल्यमा उपलब्ध छ।', 'View CCTV Systems', 'सीसीटीभी हेर्नुहोस्', '/categories/cctv-security', '/images/image_1024.jpeg', 'hero', 2, true),
('banner-3', 'Your Hope, Our Trust', 'तपाईंको आशा, हाम्रो विश्वास', 'Prompt on-site support, genuine warranty, and dependable IT infrastructure solutions.', 'भरपर्दो वारेन्टी, गुणस्तरीय प्रविधि र छिटो छरितो मर्मत सेवा।', 'Contact Our Team', 'सम्पर्क गर्नुहोस्', '/contact', '/images/D41BF0CE-470D-43C7-9122-3ECA4D9003AB.jpeg', 'hero', 3, true)
ON CONFLICT (id) DO NOTHING;

-- -----------------------------------------------------------------------------
-- 7. INITIAL DYNAMIC PRODUCTS & INVENTORY SEED
-- -----------------------------------------------------------------------------
-- Product 1: EZVIZ Smart Camera
INSERT INTO public.products (
  id, name_en, name_ne, slug, sku, category_id, brand_id, 
  selling_price, cost_price, discount_price, 
  primary_image_url, short_desc_en, short_desc_ne, full_desc_en, full_desc_ne, 
  specifications, warranty_info_en, warranty_info_ne, 
  is_featured, is_bestseller, is_new_arrival, is_active, 
  seo_title, seo_description
) VALUES (
  'p1000000-0000-0000-0000-000000000001',
  'EZVIZ H8c 2MP Smart WiFi Pan/Tilt Outdoor Camera',
  'इजेडभिआइजेड H8c २ एमपी स्मार्ट वाईफाई क्यामेरा',
  'ezviz-h8c-2mp-smart-wifi-outdoor-camera',
  'CAM-EZ-H8C-2MP',
  'c1000000-0000-0000-0000-000000000001',
  'b1000000-0000-0000-0000-000000000003',
  4800.00, 3800.00, 4499.00,
  '/images/image_1024.jpeg',
  '360-degree motorized pan & tilt coverage, AI human shape detection, and color night vision.',
  '३६० डिग्री प्यान-टिल्ट, एआई ह्युमन डिटेक्सन र रंगीन नाइट भिजनसहितको स्मार्ट क्यामेरा।',
  'The EZVIZ H8c inherits core outdoor surveillance technologies from EZVIZs award-winning camera series to bring compact, all-round motorized 360-degree protection to your home or store in Ramechhap. Featuring crisp 1080p video, two-way audio, and active defense strobe lights.',
  'इजेडभिआइजेड H8c क्यामेराले ३६० डिग्री सुरक्षा प्रदान गर्दछ। यसमा १०८०पि भिडियो, दुईतर्फी अडियो, र रातिको समयमा पनि रंगीन दृश्य रेकर्ड गर्ने सुविधा छ।',
  '{"Resolution": "1080p FHD (1920 x 1080)", "Field of View": "350° Horizontal, 80° Vertical", "Night Vision": "Color Night Vision up to 30 meters", "Storage": "MicroSD slot up to 512GB & Cloud", "Weatherproof": "IP65 Weatherproof Design", "Connectivity": "2.4GHz Wi-Fi and RJ45 Ethernet"}'::jsonb,
  '1 Year Brand Replacement Warranty',
  '१ वर्ष ब्रान्ड वारेन्टी',
  true, true, true, true,
  'Buy EZVIZ H8c Outdoor Smart WiFi Camera in Ramechhap | Numbur iT',
  'Order genuine EZVIZ H8c outdoor security camera in Manthali Ramechhap. High definition 1080p, night vision, and mobile live viewing.'
) ON CONFLICT (id) DO NOTHING;

-- Product 2: Dell Vostro 3501 Core i5 Laptop
INSERT INTO public.products (
  id, name_en, name_ne, slug, sku, category_id, brand_id, 
  selling_price, cost_price, discount_price, 
  primary_image_url, short_desc_en, short_desc_ne, full_desc_en, full_desc_ne, 
  specifications, warranty_info_en, warranty_info_ne, 
  is_featured, is_bestseller, is_new_arrival, is_active, 
  seo_title, seo_description
) VALUES (
  'p1000000-0000-0000-0000-000000000002',
  'Dell Vostro 3501 15.6" FHD Core i5 11th Gen',
  'डेल भोस्ट्रो ३५०१ १५.६ इन्च कोर आई५ ल्यापटप',
  'dell-vostro-3501-core-i5-11th-gen',
  'LAP-DEL-V3501-I5',
  'c1000000-0000-0000-0000-000000000002',
  'b1000000-0000-0000-0000-000000000001',
  72000.00, 64000.00, 68500.00,
  '/images/Dell-Inspiron-3501-i71165G7-8gb-512gb-SSD-11th-15.6_-FHD-2gb-MX330-Win10-Laptop-Copy.jpeg',
  'Intel Core i5 11th Gen, 8GB DDR4 RAM, 512GB NVMe SSD, and crisp 15.6-inch anti-glare display.',
  'इन्टेल कोर आई५ ११औं जेनेरेसन, ८ जीबी र्‍याम, ५१२ जीबी एसएसडी र १५.६ इन्च एफएचडी स्क्रिन।',
  'Designed for small businesses, offices, and students in Ramechhap. The Dell Vostro 3501 delivers fast boot times with its 512GB NVMe SSD, rich productivity with a numeric keypad, and long battery life.',
  'रामेछापका कार्यालय, विद्यार्थी तथा व्यवसायीका लागि उत्कृष्ट कार्यक्षमता भएको डेल भोस्ट्रो ल्यापटप।',
  '{"Processor": "Intel Core i5-1135G7 (Up to 4.2 GHz)", "Memory": "8GB DDR4 3200MHz (Upgradeable)", "Storage": "512GB M.2 PCIe NVMe SSD", "Display": "15.6-inch FHD (1920 x 1080) Anti-glare", "Graphics": "Intel Iris Xe Graphics", "Operating System": "Windows 11 Genuine", "Ports": "USB 3.2 Gen 1, HDMI 1.4, SD Card reader, RJ-45"}'::jsonb,
  '1 Year Comprehensive Hardware Warranty',
  '१ वर्ष पूर्ण हार्डवेयर वारेन्टी',
  true, true, false, true,
  'Dell Vostro 3501 Laptop Price in Ramechhap Nepal | Numbur iT',
  'Buy official Dell Vostro 3501 Core i5 laptop in Manthali Ramechhap. 1 Year warranty and local service support.'
) ON CONFLICT (id) DO NOTHING;

-- Product 3: TP-Link Gigabit Wireless Router
INSERT INTO public.products (
  id, name_en, name_ne, slug, sku, category_id, brand_id, 
  selling_price, cost_price, discount_price, 
  primary_image_url, short_desc_en, short_desc_ne, full_desc_en, full_desc_ne, 
  specifications, warranty_info_en, warranty_info_ne, 
  is_featured, is_bestseller, is_new_arrival, is_active, 
  seo_title, seo_description
) VALUES (
  'p1000000-0000-0000-0000-000000000003',
  'TP-Link Archer C6 AC1200 MU-MIMO Gigabit Wi-Fi Router',
  'टीपी-लिंक आर्चर सी६ गिगाबिट वाइफाइ राउटर',
  'tp-link-archer-c6-ac1200-gigabit-router',
  'NET-TPL-AC1200-C6',
  'c1000000-0000-0000-0000-000000000004',
  'b1000000-0000-0000-0000-000000000008',
  4200.00, 3200.00, 3750.00,
  '/images/424879538_1417216489179631_8263106428903182340_n.jpg',
  'Dual-band Wi-Fi up to 1200 Mbps with 4 external antennas and gigabit WAN/LAN ports.',
  'डुअल ब्यान्ड १२०० एमबीपीएस वाइफाइ र ४ वटा बाह्य एन्टेना भएको उच्च गतिको राउटर।',
  'Creates a reliable and blazing-fast network powered by 802.11ac Wi-Fi technology. The 2.4GHz band delivers speeds up to 300Mbps, while the 5GHz band delivers up to 867Mbps for lag-free HD streaming and office connectivity.',
  'घर तथा अफिसमा इन्टरनेटको स्पिड बढाउन र सबै कोठामा बलियो वाइफाइ सिग्नल पुर्‍याउन उपयोगी।',
  '{"Speed": "300 Mbps on 2.4 GHz + 867 Mbps on 5 GHz", "Antennas": "4 Fixed High-Gain Antennas", "Ethernet Ports": "1 Gigabit WAN + 4 Gigabit LAN", "Security": "WPA3 Latest Wireless Security", "Modes": "Router Mode, Access Point Mode"}'::jsonb,
  '1 Year Replacement Warranty',
  '१ वर्ष वारेन्टी',
  false, true, true, true,
  'TP-Link Archer C6 Gigabit Router in Ramechhap | Numbur iT',
  'Buy high speed dual-band TP-Link Archer C6 Wi-Fi router in Manthali Ramechhap with warranty.'
) ON CONFLICT (id) DO NOTHING;

-- Initial Inventory for Seed Products
INSERT INTO public.inventory (id, product_id, total_purchased, available_quantity, sold_quantity, damaged_quantity, low_stock_threshold) VALUES
('i1000000-0000-0000-0000-000000000001', 'p1000000-0000-0000-0000-000000000001', 15, 12, 3, 0, 3),
('i1000000-0000-0000-0000-000000000002', 'p1000000-0000-0000-0000-000000000002', 8, 6, 2, 0, 2),
('i1000000-0000-0000-0000-000000000003', 'p1000000-0000-0000-0000-000000000003', 25, 20, 5, 0, 5)
ON CONFLICT (product_id) DO NOTHING;
