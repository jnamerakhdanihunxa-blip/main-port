-- =============================================================================
-- NUMBUR iT SOLUTION - 02_RLS_POLICIES.SQL
-- Row Level Security (RLS) Policies for Supabase
-- =============================================================================

-- Enable Row Level Security on all sensitive tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.brands ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gallery_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_banners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- -----------------------------------------------------------------------------
-- Helper functions for Role-Based Access Control
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.get_current_user_role()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$;

CREATE OR REPLACE FUNCTION public.is_staff_or_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() 
    AND role IN ('staff', 'admin', 'super_admin')
  );
$$;

CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  );
$$;

-- -----------------------------------------------------------------------------
-- 1. PROFILES POLICIES
-- -----------------------------------------------------------------------------
-- Customers can view only their own profile
CREATE POLICY "Users can view own profile" 
ON public.profiles FOR SELECT 
USING (auth.uid() = id);

-- Customers can update only their own profile
CREATE POLICY "Users can update own profile" 
ON public.profiles FOR UPDATE 
USING (auth.uid() = id);

-- Staff and Admin can view customer profiles for CRM / fulfillment
CREATE POLICY "Staff and admin can view profiles" 
ON public.profiles FOR SELECT 
USING (public.is_staff_or_admin());

-- System / trigger can insert profiles upon signup
CREATE POLICY "Users can insert own profile" 
ON public.profiles FOR INSERT 
WITH CHECK (auth.uid() = id);

-- -----------------------------------------------------------------------------
-- 2. STAFF PROFILES POLICIES
-- -----------------------------------------------------------------------------
-- Anyone can view public staff profiles
CREATE POLICY "Public can view active staff" 
ON public.staff_profiles FOR SELECT 
USING (is_public = true);

-- Staff/Admin can view all staff profiles (including hidden)
CREATE POLICY "Staff can view all staff profiles" 
ON public.staff_profiles FOR SELECT 
USING (public.is_staff_or_admin());

-- Only Admins can modify staff directory
CREATE POLICY "Admins can manage staff profiles" 
ON public.staff_profiles FOR ALL 
USING (public.is_admin());

-- -----------------------------------------------------------------------------
-- 3. CATEGORIES & BRANDS POLICIES
-- -----------------------------------------------------------------------------
-- Public can view active categories
CREATE POLICY "Public can view active categories" 
ON public.categories FOR SELECT 
USING (is_active = true);

-- Staff/Admin can view all categories
CREATE POLICY "Staff can view all categories" 
ON public.categories FOR SELECT 
USING (public.is_staff_or_admin());

-- Staff/Admin can manage categories
CREATE POLICY "Staff can manage categories" 
ON public.categories FOR ALL 
USING (public.is_staff_or_admin());

-- Public can view active brands
CREATE POLICY "Public can view active brands" 
ON public.brands FOR SELECT 
USING (is_active = true);

-- Staff/Admin can manage brands
CREATE POLICY "Staff can manage brands" 
ON public.brands FOR ALL 
USING (public.is_staff_or_admin());

-- -----------------------------------------------------------------------------
-- 4. PRODUCTS POLICIES
-- -----------------------------------------------------------------------------
-- Public can view active products
CREATE POLICY "Public can view active products" 
ON public.products FOR SELECT 
USING (is_active = true);

-- Staff/Admin can view all products
CREATE POLICY "Staff can view all products" 
ON public.products FOR SELECT 
USING (public.is_staff_or_admin());

-- Staff/Admin can manage products
CREATE POLICY "Staff can manage products" 
ON public.products FOR ALL 
USING (public.is_staff_or_admin());

-- -----------------------------------------------------------------------------
-- 5. INVENTORY & MOVEMENTS POLICIES (Admin/Staff ONLY - Public NO access)
-- -----------------------------------------------------------------------------
CREATE POLICY "Staff can view inventory" 
ON public.inventory FOR SELECT 
USING (public.is_staff_or_admin());

CREATE POLICY "Staff can manage inventory" 
ON public.inventory FOR ALL 
USING (public.is_staff_or_admin());

CREATE POLICY "Staff can view inventory movements" 
ON public.inventory_movements FOR SELECT 
USING (public.is_staff_or_admin());

CREATE POLICY "Staff can insert inventory movements" 
ON public.inventory_movements FOR INSERT 
WITH CHECK (public.is_staff_or_admin());

-- -----------------------------------------------------------------------------
-- 6. ORDERS & ORDER ITEMS POLICIES (Strict customer privacy)
-- -----------------------------------------------------------------------------
-- Customers can only view their own orders
CREATE POLICY "Customers can view own orders" 
ON public.orders FOR SELECT 
USING (auth.uid() = customer_id);

-- Customers can create an order for themselves
CREATE POLICY "Customers can insert own orders" 
ON public.orders FOR INSERT 
WITH CHECK (auth.uid() = customer_id);

-- Staff/Admin can view all orders
CREATE POLICY "Staff can view all orders" 
ON public.orders FOR SELECT 
USING (public.is_staff_or_admin());

-- Staff/Admin can update orders (status, notes)
CREATE POLICY "Staff can update orders" 
ON public.orders FOR UPDATE 
USING (public.is_staff_or_admin());

-- Order items: customers view only items for their own orders
CREATE POLICY "Customers can view own order items" 
ON public.order_items FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.orders 
    WHERE orders.id = order_items.order_id 
    AND orders.customer_id = auth.uid()
  )
);

-- Customers can insert order items for their own newly created order
CREATE POLICY "Customers can insert own order items" 
ON public.order_items FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.orders 
    WHERE orders.id = order_items.order_id 
    AND orders.customer_id = auth.uid()
  )
);

-- Staff/Admin can view and manage all order items
CREATE POLICY "Staff can manage order items" 
ON public.order_items FOR ALL 
USING (public.is_staff_or_admin());

-- -----------------------------------------------------------------------------
-- 7. PAYMENTS & ORDER STATUS HISTORY
-- -----------------------------------------------------------------------------
-- Customers can view payment records for their own orders
CREATE POLICY "Customers can view own order payments" 
ON public.payments FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.orders 
    WHERE orders.id = payments.order_id 
    AND orders.customer_id = auth.uid()
  )
);

-- Staff/Admin can record and view payments
CREATE POLICY "Staff can manage payments" 
ON public.payments FOR ALL 
USING (public.is_staff_or_admin());

-- Order status history: customers can view tracking history of their own orders
CREATE POLICY "Customers can view own status history" 
ON public.order_status_history FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.orders 
    WHERE orders.id = order_status_history.order_id 
    AND orders.customer_id = auth.uid()
  )
);

-- Staff/Admin can insert and view status history
CREATE POLICY "Staff can manage order status history" 
ON public.order_status_history FOR ALL 
USING (public.is_staff_or_admin());

-- -----------------------------------------------------------------------------
-- 8. CMS: SERVICES, GALLERY, BANNERS, SETTINGS
-- -----------------------------------------------------------------------------
-- Public read active CMS items
CREATE POLICY "Public can view active services" ON public.services FOR SELECT USING (is_active = true);
CREATE POLICY "Staff can manage services" ON public.services FOR ALL USING (public.is_staff_or_admin());

CREATE POLICY "Public can view active gallery" ON public.gallery_items FOR SELECT USING (is_active = true);
CREATE POLICY "Staff can manage gallery" ON public.gallery_items FOR ALL USING (public.is_staff_or_admin());

CREATE POLICY "Public can view active banners" ON public.site_banners FOR SELECT USING (is_active = true);
CREATE POLICY "Staff can manage banners" ON public.site_banners FOR ALL USING (public.is_staff_or_admin());

CREATE POLICY "Public can read site settings" ON public.site_settings FOR SELECT USING (true);
CREATE POLICY "Admins can manage site settings" ON public.site_settings FOR ALL USING (public.is_admin());

-- -----------------------------------------------------------------------------
-- 9. AUDIT LOGS (Admin ONLY)
-- -----------------------------------------------------------------------------
CREATE POLICY "Admins can view audit logs" 
ON public.audit_logs FOR SELECT 
USING (public.is_admin());
