-- =============================================================================
-- NUMBUR iT SOLUTION - 20260923_01_website_feedback_updates.sql
-- Incremental Schema Updates for Customer Account Removal, Guest WhatsApp Checkout,
-- Social Links Management, Branding, and Staff Deactivation Security
-- =============================================================================

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- -----------------------------------------------------------------------------
-- 1. ORDERS TABLE ADJUSTMENTS (Support Guest WhatsApp Checkout)
-- -----------------------------------------------------------------------------
-- Allow customer_id to be NULL so orders can be placed by guest customers without an auth account
DO $$ 
BEGIN
  ALTER TABLE public.orders ALTER COLUMN customer_id DROP NOT NULL;
EXCEPTION
  WHEN others THEN NULL;
END $$;

-- Add optional customer email and customer order notes if not already present
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_email TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS customer_notes TEXT;

-- Index for searching orders by customer phone number
CREATE INDEX IF NOT EXISTS idx_orders_customer_phone ON public.orders(customer_phone);

-- -----------------------------------------------------------------------------
-- 2. PROFILES TABLE ADJUSTMENT (Account Deactivation Support)
-- -----------------------------------------------------------------------------
-- Allow deactivating staff or admin accounts without deleting user records
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_active BOOLEAN NOT NULL DEFAULT true;
CREATE INDEX IF NOT EXISTS idx_profiles_active ON public.profiles(is_active);

-- -----------------------------------------------------------------------------
-- 3. SITE BANNERS TABLE ADJUSTMENT (Cloudinary Asset Tracking)
-- -----------------------------------------------------------------------------
-- Store Cloudinary public ID for clean asset deletion/replacement
ALTER TABLE public.site_banners ADD COLUMN IF NOT EXISTS image_public_id TEXT;

-- -----------------------------------------------------------------------------
-- 4. SOCIAL MEDIA LINKS TABLE
-- -----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.social_links (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  platform TEXT NOT NULL, -- e.g. 'facebook', 'instagram', 'youtube', 'tiktok', 'linkedin', 'whatsapp', 'other'
  platform_name TEXT NOT NULL,
  url TEXT NOT NULL,
  icon_name TEXT DEFAULT 'Globe',
  display_order INTEGER NOT NULL DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_social_links_active ON public.social_links(is_active, display_order);

-- Enable RLS on social_links
ALTER TABLE public.social_links ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they already exist to avoid errors upon re-run
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Public can view active social links" ON public.social_links;
  DROP POLICY IF EXISTS "Staff and admin can view all social links" ON public.social_links;
  DROP POLICY IF EXISTS "Admins can manage social links" ON public.social_links;
EXCEPTION
  WHEN others THEN NULL;
END $$;

-- Policy: Public can view active social links
CREATE POLICY "Public can view active social links"
ON public.social_links FOR SELECT
USING (is_active = true);

-- Policy: Staff and Admin can view all social links (including inactive)
CREATE POLICY "Staff and admin can view all social links"
ON public.social_links FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() 
    AND role IN ('staff', 'admin', 'super_admin')
  )
);

-- Policy: Admin & Super Admin can manage social links
CREATE POLICY "Admins can manage social links"
ON public.social_links FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  )
);

-- -----------------------------------------------------------------------------
-- 5. INITIAL SEED FOR SOCIAL LINKS (Idempotent)
-- -----------------------------------------------------------------------------
INSERT INTO public.social_links (platform, platform_name, url, icon_name, display_order, is_active)
SELECT 'facebook', 'Facebook', 'https://www.facebook.com/p/-100057596823175/', 'Facebook', 1, true
WHERE NOT EXISTS (SELECT 1 FROM public.social_links WHERE platform = 'facebook');

INSERT INTO public.social_links (platform, platform_name, url, icon_name, display_order, is_active)
SELECT 'whatsapp', 'WhatsApp Support', 'https://wa.me/9779854040821', 'MessageCircle', 2, true
WHERE NOT EXISTS (SELECT 1 FROM public.social_links WHERE platform = 'whatsapp');

INSERT INTO public.social_links (platform, platform_name, url, icon_name, display_order, is_active)
SELECT 'youtube', 'YouTube Channel', 'https://www.youtube.com', 'Youtube', 3, true
WHERE NOT EXISTS (SELECT 1 FROM public.social_links WHERE platform = 'youtube');

INSERT INTO public.social_links (platform, platform_name, url, icon_name, display_order, is_active)
SELECT 'instagram', 'Instagram', 'https://www.instagram.com', 'Instagram', 4, true
WHERE NOT EXISTS (SELECT 1 FROM public.social_links WHERE platform = 'instagram');

INSERT INTO public.social_links (platform, platform_name, url, icon_name, display_order, is_active)
SELECT 'tiktok', 'TikTok', 'https://www.tiktok.com', 'Video', 5, false
WHERE NOT EXISTS (SELECT 1 FROM public.social_links WHERE platform = 'tiktok');

INSERT INTO public.social_links (platform, platform_name, url, icon_name, display_order, is_active)
SELECT 'linkedin', 'LinkedIn', 'https://www.linkedin.com', 'Linkedin', 6, false
WHERE NOT EXISTS (SELECT 1 FROM public.social_links WHERE platform = 'linkedin');

-- -----------------------------------------------------------------------------
-- 6. DEFAULT SITE SETTINGS (Idempotent)
-- -----------------------------------------------------------------------------
INSERT INTO public.site_settings (key, value, description)
VALUES 
  ('site_logo_url', '', 'Primary brand logo URL uploaded via Cloudinary'),
  ('site_logo_public_id', '', 'Cloudinary asset public ID for brand logo'),
  ('business_whatsapp_number', '9779854040821', 'Primary WhatsApp ordering number for Numbur iT'),
  ('store_phone', '048540314', 'Primary landline office telephone in Manthali-1'),
  ('store_secondary_phone', '9854040821', 'Secondary mobile / executive hotline'),
  ('store_email', 'numburitsolution1@gmail.com', 'Official customer support email'),
  ('store_address_en', 'Manthali-1, Ramechhap, Bagmati Province, Nepal', 'Storefront physical address in English'),
  ('store_address_ne', 'मन्थली-१, रामेछाप, बागमती प्रदेश, नेपाल', 'Storefront physical address in Nepali'),
  ('business_hours_en', 'Sun - Fri: 9:00 AM - 6:00 PM | Sat: Closed', 'Operating business hours in English'),
  ('advance_payment_info', 'Fonepay QR / eSewa: 9854040821 | Nabil Bank / Global IME Bank', 'Payment reconciliation instruction for orders')
ON CONFLICT (key) DO NOTHING;

-- -----------------------------------------------------------------------------
-- 7. AUDITED STAFF PROFILES SEED (RFC 4122 Valid UUIDs - Resolves 03_seed_data.sql 22P02 error)
-- -----------------------------------------------------------------------------
INSERT INTO public.staff_profiles (
  id, name, designation, department, bio_en, bio_ne, photo_url, public_contact_phone, public_contact_email, public_address, display_order, is_public
) VALUES
  ('a1000000-0000-0000-0000-000000000001', 'Mr. Niraz Sapkota', 'Owner & Co-founder', 'Executive Management', 'Founder of Numbur iT Solution Pvt. Ltd. Leading IT infrastructure development, enterprise hardware supplies, and customer satisfaction across Ramechhap since 2069 BS.', 'नम्बुर आइटी सोलुसनका संस्थापक। २०६९ सालदेखि रामेछाप जिल्लामा सूचना प्रविधि विस्तारमा क्रियाशील।', '', '9854040821', 'numburitsolution1@gmail.com', 'Khimti-7, Ramechhap', 1, true),
  ('a1000000-0000-0000-0000-000000000002', 'Mr. Tikaram', 'Co-sub founder & Head Accountant', 'Finance & Administration', 'Overseeing financial administration, accounting operations, supplier settlements, and commercial billing.', 'कम्पनीको आर्थिक प्रशासन तथा लेखा व्यवस्थापनको जिम्मेवारी।', '', '9861561229', NULL, 'Sindhuli', 2, true),
  ('a1000000-0000-0000-0000-000000000003', 'Mr. Rohit Prasad Adhikari', 'IT Technician & Technical Lead', 'Technical Department', 'Expert hardware diagnostics, CCTV surveillance architecture, network installation, and on-site client technical troubleshooting.', 'हार्डवेयर मर्मत, सीसीटीभी क्यामेरा इन्स्टलेसन र नेटवर्किङ प्राविधिक विशेषज्ञ।', '', '9846141110', 'rohitprasadadhikari11@gmail.com', 'Mithila Mun-11, Dhanusha', 3, true),
  ('a1000000-0000-0000-0000-000000000004', 'Mrs. Usha Karki', 'Accountant', 'Accountant Department', 'Handling customer invoices, store accounts reconciliation, order advance payments verification, and client reception.', 'ग्राहक बिलिङ, इनभ्वाइसिङ र स्टोर एकाउन्टिङ व्यवस्थापन।', '', '9765990808', NULL, 'Manthali-2, Ramechhap', 4, true)
ON CONFLICT (id) DO NOTHING;

